#!/usr/bin/env node
/*
 * The engine is a parameter, and stays one — in bare Node, no browser.
 *
 *   node tests/verify-engine.js
 *
 * The app's target device is an iPad, so the engine that matters most is
 * WebKit; every suite nonetheless launched Chromium, thirty-four times over,
 * because each was copied from the one before it. tests/_engine.js made that
 * a flag. This is what stops it drifting back: the reason all thirty-four
 * hardcoded Blink was never a decision, it was the path of least resistance,
 * and the next suite written will take the same path unless something
 * objects.
 *
 * So this asserts a property of the test suite itself rather than of the app.
 * That is unusual here and deliberate — it is the only check in the project
 * whose subject is the project's own discipline, and it needs no browser and
 * no build, which means CI can actually run it.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const { blankComments } = require('./_source.js');

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
const head = t => console.log('\n── ' + t + ' ──');

const TESTS = path.join(__dirname);
const ROOT = path.join(__dirname, '..');
const E = require('./_engine.js');

/* Read fresh each time: engineName() reads process.env at call time on
   purpose, so a suite spawned with a different SYSTOLE_ENGINE gets it without
   the module being reloaded. */
const withEnv = (value, fn) => {
  const had = Object.prototype.hasOwnProperty.call(process.env, 'SYSTOLE_ENGINE');
  const prev = process.env.SYSTOLE_ENGINE;
  if (value === undefined) delete process.env.SYSTOLE_ENGINE;
  else process.env.SYSTOLE_ENGINE = value;
  try { return fn(); } finally {
    if (had) process.env.SYSTOLE_ENGINE = prev; else delete process.env.SYSTOLE_ENGINE;
  }
};
const threw = fn => { try { fn(); return null; } catch (e) { return e.message; } };

head('the default is unchanged — `npm test` still means Chromium');
ok('no SYSTOLE_ENGINE resolves to chromium', withEnv(undefined, () => E.engineName()) === 'chromium');
ok('an empty SYSTOLE_ENGINE resolves to chromium too, not to ""',
   withEnv('', () => E.engineName()) === 'chromium');
ok('DEFAULT_ENGINE is the one the suites were written against', E.DEFAULT_ENGINE === 'chromium');

head('and asking for another engine actually changes the answer');
ok('webkit is selectable', withEnv('webkit', () => E.engineName()) === 'webkit');
ok('firefox is selectable', withEnv('firefox', () => E.engineName()) === 'firefox');
ok('case and stray whitespace are forgiven, because a shell adds both',
   withEnv('  WebKit \n', () => E.engineName()) === 'webkit');

head('a name that is not an engine fails loudly, before any browser starts');
{
  const msg = withEnv('webkti', () => threw(() => E.engineName()));
  ok('a typo throws rather than falling back to chromium', msg !== null);
  ok('and the message names what was asked for', !!msg && msg.includes('webkti'), msg || '(no throw)');
  ok('and lists what would have worked', !!msg && msg.includes('webkit') && msg.includes('firefox'));
  /* Silently defaulting is the failure mode worth naming: a run that reports
     "all green" having quietly tested the engine you were trying to leave is
     worse than no run at all. */
  ok('safari is rejected — Playwright has no such browser type',
     withEnv('safari', () => threw(() => E.engineName())) !== null);
}

head('Chromium-only launch flags do not travel to engines that would choke');
{
  const args = { args: ['--enable-precise-memory-info'] };
  ok('chromium keeps its flags', (E.launchOptions(args, 'chromium').args || []).length === 1);
  ok('webkit is handed none', E.launchOptions(args, 'webkit').args === undefined);
  ok('firefox is handed none', E.launchOptions(args, 'firefox').args === undefined);
  ok('and everything else is passed through untouched',
     E.launchOptions({ args: ['--x'], headless: false, timeout: 5 }, 'webkit').headless === false);
  ok('the caller’s own options object is not mutated — it may be a shared constant',
     (E.launchOptions(args, 'webkit'), Array.isArray(args.args) && args.args.length === 1));
  ok('no options at all is not an error', JSON.stringify(E.launchOptions(undefined, 'webkit')) === '{}');
}

head('every browser suite goes through the helper, none launches an engine itself');
{
  const suites = fs.readdirSync(TESTS).filter(f => /^verify-.*\.js$/.test(f)).sort();
  ok('there are suites to check at all', suites.length > 30, `${suites.length} found`);

  const direct = [], unwired = [];
  for (const f of suites) {
    const src = fs.readFileSync(path.join(TESTS, f), 'utf8');
    /* Comments are stripped, and the scan is then anchored to the start of a
       line with no quote before the call. Two suites discuss Chromium in
       prose, and this file names the very call it forbids in its own PASS
       label — so a bare substring search fails on its own documentation. It
       did, on the first run. Stripping string literals with a regex failed
       too, and more interestingly: regex literals elsewhere in this file
       contain apostrophes, which puts quote-pairing out of phase and lets the
       label through anyway. You cannot lex JavaScript with a regular
       expression. But a real call sits in statement position with no quote to
       its left on the line, and a mention always has one — a distinction that
       needs no lexer. */
    /* Blanked rather than collapsed. This replaced a whole multi-line comment
       with ONE space, which joins the code before it to the code after it —
       and every pattern below is ^-anchored with /m, so a merged line can hide
       a real launch() or invent one. */
    const code = blankComments(src);
    if (/^[^'"`\n]*\b(?:chromium|webkit|firefox)\.launch\(/m.test(code)) direct.push(f);
    /* A suite that uses a browser must get it from here. One that does not
       (the pure-arithmetic suites, this one included) is not required to
       require anything. */
    const usesBrowser = /^[^'"`\n]*require\(\s*'playwright'\s*\)/m.test(code)
                     || /^[^'"`\n]*\blaunch\(/m.test(code);
    if (usesBrowser && !/require\(\s*'\.\/_engine(?:\.js)?'\s*\)/.test(code)) unwired.push(f);
  }
  ok('no suite calls chromium.launch() / webkit.launch() directly',
     direct.length === 0, direct.join(', ') || 'none');

  /* THE THIRD SHARED THING, AND THE ONE THAT COSTS A BROWSER RUN TO FIND.
     onScreen(page, 'home') with no marker waits on S.screen — which the
     navigation helpers set BEFORE calling render(). render hands renderNow to
     startViewTransition on a screen change, and the browser runs that
     callback only after capturing the old state, so the state flips and the
     wait returns while the render has not happened. Whatever the test reads
     next is the PREVIOUS screen's, and it reports that as an app bug.

     verify-focus did exactly this and blamed focus mode for two failures the
     app did not have. Every other call site in the tree already passed a
     marker, so this costs nothing to keep and would have turned a 20-minute
     browser run into a parse. If a call ever genuinely needs no marker, this
     going red is the place to say why. */
  const unmarked = [];
  for (const f of suites) {
    const code = blankComments(fs.readFileSync(path.join(TESTS, f), 'utf8'));
    /* Two arguments and a closing paren: a third would be the opts object
       that carries the marker. */
    if (/\bonScreen\(\s*[A-Za-z_$][\w$]*\s*,\s*(['"])[^'"]*\1\s*\)/.test(code)) unmarked.push(f);
  }
  ok('every onScreen() names a marker, so the wait is the render and not S.screen',
     unmarked.length === 0, unmarked.join(', ') || 'none');

  /* THE SAME RULE, ABOUT A DIFFERENT SHARED THING. Reading this repository's
     source as text requires blanking its comments first, because the files
     explain themselves at length and those explanations QUOTE the patterns
     being hunted — a scan that reads comments finds the paragraph warning
     about the bug and reports it as the bug. That happened three times in one
     day, in three different files, twice to the person who had just written
     the paragraph, which is precisely the shape of thing this suite exists to
     stop: one helper, not five local copies drifting apart. Two of the five
     already had: one stripped comments (shifting every index after) and one
     collapsed them to a single space (merging lines under ^-anchored /m). */
  const rolled = [];
  for (const f of suites.concat(fs.readdirSync(TESTS).filter(n => /^_.*\.js$/.test(n)))) {
    if (f === '_source.js') continue;
    const src = fs.readFileSync(path.join(TESTS, f), 'utf8');
    /* Scanned on the BLANKED copy, which is the rule applying to itself: the
       paragraph above quotes what it hunts for, and reading it would report
       this very check as a violation.

       NO OTHER EXEMPTION. This used to skip any file whose text mentioned
       _source anywhere, comments included, on the theory that a file using
       the shared helper is not rolling its own. This file both uses it and
       rolled its own, a stripper of the kind that drifted, and passed. Only
       _source.js itself may hold a blanker. What is matched is the
       block-comment shape, a lazy [\s\S] run up to the closing star-slash; a
       copy that handled only // comments would not be seen. */
    if (/\[\\s\\S\]\*\?\\\*\\\//.test(blankComments(src))) rolled.push(f);
  }
  ok('no suite rolls its own comment blanker — it is in tests/_source.js',
     rolled.length === 0, rolled.join(', ') || 'none');
  ok('no suite requires playwright behind the helper’s back',
     unwired.length === 0, unwired.join(', ') || 'none');
}

head('the shared comment blanker blanks comments, and only comments');
{
  /* Every scan in this file reads tests/_source.js's blanked copy, and so do
     a dozen other suites, so a hole in it is a hole in all of them at once —
     and none of them can see it, because a scan shown less code simply finds
     less. It had one. A slash-star inside a string (the provider route glob
     the chat suites stub with) opened a "comment" that ran to the next real
     one's close; _source.js has what that hid.

     Each fixture is listed with the comments it holds, and what must come back
     is the fixture with exactly those turned to spaces. */
  const blankOut = (src, comments) => {
    let out = src, from = 0;
    for (const c of comments) {
      const at = out.indexOf(c, from);
      if (at < 0) throw new Error('fixture comment not in its fixture: ' + JSON.stringify(c));
      out = out.slice(0, at) + c.replace(/[^\n]/g, ' ') + out.slice(at + c.length);
      from = at + c.length;
    }
    return out;
  };
  /* The contract every caller leans on: blanked, not stripped. */
  const keepsShape = (src, out) => {
    if (typeof out !== 'string' || out.length !== src.length) return false;
    for (let k = 0; k < src.length; k++) if ((src[k] === '\n') !== (out[k] === '\n')) return false;
    return true;
  };
  const FIXTURES = [
    ['a slash-star inside a quoted string opens no comment, so the line after it is still read',
     "page.route('**/x/**', r => {});\nkeep('x');\n/* c */", ['/* c */']],
    ['nor inside a double-quoted one, and a // inside a string is not a comment either',
     'const g = "**/*.js", u = \'a // b\';\nkeep(g, u);\n/* c */', ['/* c */']],
    ['a template literal is text, and a comment inside its ${…} is still a comment',
     'const t = `a /* b ${ x /* real */ + `in ${ "**/" } ner` } // c`;\ndone(t);\n// tail', ['/* real */', '// tail']],
    ['a regular expression is not a comment, even one holding a slash-star',
     'const re = /[/*]/g, sl = /\\/\\//;\nkeep(re, sl);\n/* c */', ['/* c */']],
    ['a slash-star inside a // comment opens nothing',
     '// globs like **/*.js\nconst kept = 1;\n/* c */', ['// globs like **/*.js', '/* c */']],
    ['a comment across lines is blanked with its line breaks kept, and the code after it is read',
     'a = 1; /* one\ntwo */ b = 2;\n', ['/* one\ntwo */']],
    ['a / after a name divides, so the backtick after it opens a template of its own',
     'const h = a / 2 + `/`;\nkeep(h);\n/* c */\nconst t = `x`;', ['/* c */']],
    /* Not JavaScript: callers hand it the HTML template and CSS too. */
    ['an apostrophe in prose is not a string, so a comment after it is still found',
     "<p>Don't panic</p> /* a */\nx = 'b';", ['/* a */']],
    ['a backtick that never closes is not a template, so a comment after it is still found',
     '<p>one ` tick</p> /* b */\n', ['/* b */']],
    ['a // straight after a colon is a URL written in markup, not a comment',
     '<a href=https://x.org/y>z</a> // c', ['// c']],
    ['a / after a % in CSS divides, so a comment later on its line is still found',
     'a { border-radius: 50% / 10%; /* oval */ }', ['/* oval */']],
  ];
  for (const [label, src, comments] of FIXTURES) {
    const got = blankComments(src), want = blankOut(src, comments);
    ok(label, got === want, got === want ? '' : JSON.stringify(got));
  }

  /* And on the real thing. Every .js file in the tree that compiles must still
     compile once blanked: blanking part of a string, or the code after a
     slash-star that was not a comment, leaves a file that does not. The two
     regular expressions this replaced failed that on 37 files, this one among
     them once its fixtures were written. What it cannot see is a comment left
     standing, which compiles too; the fixtures above are for that. */
  const vm = require('vm');
  const corpus = [];
  const walk = dir => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) walk(p); else if (e.name.endsWith('.js')) corpus.push(p);
    }
  };
  ['tests', 'scripts', 'tools', 'src']
    .forEach(d => walk(path.join(ROOT, d)));
  const compiles = code => {
    try { vm.compileFunction(code.replace(/^#!.*/, ''), ['exports', 'require', 'module', '__filename', '__dirname']); return true; }
    catch (e) { return false; }
  };
  let compiled = 0;
  const broken = [], misshapen = [];
  for (const f of corpus) {
    const src = fs.readFileSync(f, 'utf8'), out = blankComments(src);
    if (!keepsShape(src, out)) misshapen.push(path.relative(ROOT, f));
    if (!compiles(src)) continue;            // an ES module: nothing to hold it to
    compiled++;
    if (!compiles(out)) broken.push(path.relative(ROOT, f));
  }
  /* Vacuity guard: "none fails to compile" is also what a corpus of nothing
     returns, and what a compile that never ran returns. */
  ok('there is a corpus to blank', compiled > 250, `${compiled} of ${corpus.length} .js files compile as they stand`);
  ok('every .js file in the tree that compiles still compiles once blanked',
     broken.length === 0, broken.length ? `${broken.length}: ${broken.slice(0, 8).join(', ')}` : 'none');
  ok('and every one keeps its length and its line breaks',
     misshapen.length === 0, misshapen.length ? `${misshapen.length}: ${misshapen.slice(0, 8).join(', ')}` : `${corpus.length} files`);

  /* The page, not only its scripts. verify-stats, verify-heartbake-pure and
     verify-icons-pure blank app/systole.html whole, and the blanker carries
     what it reads in the markup into the script after it: tried on a copy, a
     stray backtick in prose opened a template that the first script's
     backtick closed, and a slash-star in prose opened a comment that a
     script's comment closed. Either way the script read differently, and
     every scan of it with it. So each inline script must come out of the
     whole page exactly as it comes out alone. */
  const page = fs.readFileSync(path.join(ROOT, 'app', 'systole.html'), 'utf8');
  const wholePage = blankComments(page);
  let inline = 0;
  const leaked = [];
  /* An end tag is </script then anything up to >, as a browser reads it:
     `</script >` ends a script too, and a pattern that wanted `</script>`
     exactly would run that script on into the next one's. */
  for (const m of page.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\b[^>]*>/gi)) {
    const at = m.index + m[0].indexOf('>') + 1, body = m[1];
    if (!body.trim()) continue;
    inline++;
    if (wholePage.slice(at, at + body.length) !== blankComments(body)) {
      leaked.push(`the script at line ${page.slice(0, at).split('\n').length}`);
    }
  }
  /* Vacuity guard: no script found would leak nothing too. */
  ok('the app template has inline scripts to compare', inline > 0, `${inline} found`);
  ok('and each blanks the same inside the page as alone, so nothing in the markup reaches it',
     leaked.length === 0, leaked.join(', ') || 'none');
}

head('the runner can actually be told which engine to use');
{
  const v = fs.readFileSync(path.join(ROOT, 'scripts', 'verify.js'), 'utf8');
  /* --engine takes a value, so it has to be excluded from the positional
     scan. Without this the build path silently becomes the string "webkit"
     and the run dies on "No build at .../webkit" — which is a confusing way
     to be told about an argv bug. */
  ok('--engine is registered as a flag that takes a value', /VALUED\s*=\s*\[[^\]]*'--engine'/.test(v));
  /* THE TWO ENTRY POINTS HAVE TO AGREE ON WHICH BROWSER THIS IS.
     A single suite run directly reads SYSTOLE_ENGINE from the environment; the
     runner used to read only --engine and then hand every child an explicit
     SYSTOLE_ENGINE of its own, so the same variable set in the same shell was
     silently overwritten with chromium. `SYSTOLE_ENGINE=webkit node
     scripts/verify.js` gave a full green chromium run that read as a WebKit
     one — and nobody re-reads a green summary. */
  ok('the runner takes SYSTOLE_ENGINE as its default, so the two entry points cannot disagree',
     /opt\('--engine',\s*process\.env\.SYSTOLE_ENGINE\s*\|\|\s*DEFAULT_ENGINE\)/.test(v));
  ok('and an explicit --engine still wins over it, because a flag is a decision for this run',
     /opt\('--engine',/.test(v) && v.indexOf("opt('--engine',") < v.indexOf('process.env.SYSTOLE_ENGINE'));
  ok('and the choice reaches the suites through the environment',
     (v.match(/SYSTOLE_ENGINE:\s*ENGINE/g) || []).length >= 2,
     `${(v.match(/SYSTOLE_ENGINE:\s*ENGINE/g) || []).length} spawn site(s)`);
  ok('the split-build run gets it too, not just the file-path suites',
     /verify-pwa\.js[\s\S]{0,400}SYSTOLE_ENGINE/.test(v));
  ok('an unusable engine name stops the run instead of starting thirty-four browsers',
     /ENGINES\.includes\(ENGINE\)/.test(v));
}

head('the public-browser job exercises every engine without weakening the iPad gate');
{
  const { jobBody } = require('../scripts/test-public.js');
  const job = jobBody(fs.readFileSync(path.join(ROOT, '.github/workflows/verify.yml'), 'utf8'), 'public-browser') || '';
  const entries = [...job.matchAll(/^\s*- engine: (\w+)\s*\n\s+label: (\w+)\s*$/gm)]
    .map(m => [m[1], m[2]]);
  /* Firefox left CI to save a runner on every push; it stays an engine here
     (ENGINES, "firefox is selectable" above), for a run by hand. */
  ok('Chromium and WebKit keep their own named CI entries, and Firefox is not run there',
     JSON.stringify(entries) === JSON.stringify([
       ['chromium', 'Chromium'], ['webkit', 'WebKit']
     ]), JSON.stringify(entries));
  ok('an engine failure cannot cancel the other engine runs', /fail-fast:\s*false\b/.test(job));
  ok('the matrix engine reaches the test helper',
     /SYSTOLE_ENGINE:\s*\$\{\{\s*matrix\.engine\s*\}\}/.test(job));
  const version = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).devDependencies.playwright;
  const image = (job.match(/^\s*image:\s*(\S+)/m) || [])[1] || '';
  const at = job.indexOf('- name: verify the preinstalled pinned browser can render');
  const end = job.indexOf('\n      - ', at + 1);
  const probe = at >= 0 && end > at ? blankComments(job.slice(at, end)) : '';
  // An installed image is not proof a browser can run. Keep the matching
  // package version and immutable digest, plus an actual shared-engine render
  // and a failing exit when the browser is missing or its page does not render.
  ok('CI uses pinned dependencies, a matching immutable browser image and a rendering probe',
     /^\s*run:\s*npm ci\s*$/m.test(job)
     && image.startsWith('mcr.microsoft.com/playwright:v' + version + '-noble@sha256:')
     && /^[a-f0-9]{64}$/.test(image.split('@sha256:')[1] || '')
     && /^\s*options:[^\n]*--user\s+1001\b/m.test(job)
     && /require\('\.\/tests\/_engine'\)/.test(probe) && /await launch\(\)/.test(probe)
     && /await page\.setContent\(/.test(probe)
     && /if \(await page\.title\(\) !== 'Browser ready'\) throw/.test(probe)
     && /process\.exit\(1\)/.test(probe));
  const suites = job.split(/\n      - /).filter(step => /run:\s*node tests\/verify-/.test(step));
  ok('every browser suite still runs after an earlier suite fails',
     suites.length > 0 && suites.every(step => /if:\s*\$\{\{\s*!cancelled\(\)\s*\}\}/.test(step)));
}

head('console noise the engine makes, told apart from noise the app makes');
{
  /* THE SAME COPY-PASTE, ONE LEVEL UP. Twenty-five suites each carried
     /GroupMarker|GL Driver|swiftshader/, for exactly the reason all of them
     called chromium.launch(): the one before it did. */
  /* This file is excluded and has to be: the assertion below names the pattern
     it is looking for, so scanning itself would always find it. Same exception
     the engine scan above already makes for the two suites that discuss
     Chromium in prose. */
  const browserSuites = fs.readdirSync(TESTS)
    .filter(f => /^verify-.*\.js$/.test(f) && f !== 'verify-engine.js').sort();
  const inlined = browserSuites.filter(f => /GroupMarker/.test(fs.readFileSync(path.join(TESTS, f), 'utf8')));
  ok('every browser suite routes its console filter through the helper',
     inlined.length === 0, inlined.join(', ') || `${browserSuites.length} suites, none inline it`);

  ok('driver chatter is noise on every engine',
     E.isEngineNoise('GroupMarker not set', 'chromium')
     && E.isEngineNoise('swiftshader fallback', 'webkit'));
  ok('an application error is never noise',
     !E.isEngineNoise('TypeError: x is not a function', 'chromium')
     && !E.isEngineNoise('TypeError: x is not a function', 'webkit'));

  /* The measured asymmetry, asserted so it cannot quietly become symmetric.
     On a blank page with no application code, twenty contexts created and
     released one at a time: WebKit warns four times whatever the page does,
     Chromium warns zero once they are released. So the message is a browser
     property on one engine and a real regression detector on the other, and
     the helper has to keep telling those apart. */
  const capWarning = 'There are too many active WebGL contexts on this page, the oldest context will be lost.';
  ok('the context-cap notice is tolerated on WebKit, where no page can prevent it',
     E.isEngineNoise(capWarning, 'webkit'));
  ok('and stays a hard failure on Chromium, where releasing contexts does silence it',
     !E.isEngineNoise(capWarning, 'chromium'));

  /* The cap's other message, and the same asymmetry for the same reason. Past
     sixteen contexts WebKit evicts on its own, and releasing an evicted one
     logs INVALID_OPERATION — not an exception, so nothing in the page can catch
     it. The app has one loseContext() call site and it is guarded twice over;
     eight cycles produce none of these. Chromium returns released slots, never
     reaches the cap, and so a message like this there means something real. */
  const lostMsg = 'WebGL: INVALID_OPERATION: loseContext: context already lost';
  ok('releasing a context WebKit already evicted is tolerated there',
     E.isEngineNoise(lostMsg, 'webkit'));
  ok('and stays a hard failure on Chromium, which never reaches the cap',
     !E.isEngineNoise(lostMsg, 'chromium'));
  /* The guard that message is about, asserted in the module rather than
     remembered: isContextLost() alone is not enough on WebKit. */
  const h3d = fs.readFileSync(path.join(ROOT, 'src', 'core', 'heart3d.js'), 'utf8');
  ok('and the one place that releases a context checks more than isContextLost()',
     /isContextLost\(\)[\s\S]{0,80}getParameter\(gl\.VERSION\)/.test(h3d));
}

head('a run reported from somewhere else says where it came from');
{
  const v = fs.readFileSync(path.join(ROOT, 'scripts', 'verify.js'), 'utf8');
  /* WHY THIS EXISTS. A WebKit run came back as one line — "1335 checks across
     49 suites … 17 suites failing: apex, polish, splash, …" — and the only way
     to learn that it had been run against a three-day-old checkout was to
     notice that 49 was not 51 and do the subtraction. The summary looked
     exactly like a current run. Two properties fix that, and neither is
     something the reader should have to supply:

       - the run states its own branch and commit, so a stale tree is legible
         in the output rather than deducible from a count;
       - the failures are written to a file, so reporting a run is sending one
         file instead of scrolling a terminal and pasting the last line.

     Both are asserted against scripts/verify.js's text, as everything else in
     this block is: the alternative is spawning a full run to make one fail,
     which costs a browser and fifteen minutes to test a console.log. */
  ok('a failing run writes the failing suites out in full, not just their names',
     /function writeFailLog\(\)/.test(v) && /last-run\.log/.test(v));
  /* Printed, not silently written: a file nobody is told about is a file
     nobody sends. The check is that writeFailLog()'s return value — the path —
     reaches a console.log, rather than that some particular sentence does. */
  ok('and says on the console where it put them',
     /console\.log\([^\n]*writeFailLog\(\)/.test(v));
  ok('the run names its own branch and commit',
     /function provenance\(\)/.test(v)
     && /rev-parse --abbrev-ref HEAD/.test(v) && /rev-parse --short HEAD/.test(v));
  ok('and admits to uncommitted changes, which are the other way a run is not what it says',
     /git status --porcelain/.test(v));
  /* Provenance on the green line too. A green run from a stale tree is the
     more dangerous of the two: nobody re-reads a summary that says green. */
  /* Compared as the expression each line prints, not as the literal
     provenance(): since the 2026-10-08 record it is asked once, into
     STARTED_ON, and both lines print that. */
  const greenSays = (v.match(/all green[^\n]{0,40}?\$\{([^}]+)\}/) || [])[1];
  const failSays = (v.match(/checkout: \$\{([^}]+)\}/) || [])[1];
  ok('a green run carries the same provenance as a failing one',
     !!greenSays && greenSays === failSays && /^(provenance\(\)|STARTED_ON)$/.test(greenSays), `${greenSays} / ${failSays}`);
  ok('the log header names the engine and the build it tested, not only the code',
     /engine\s+\$\{ENGINE\}/.test(v) && /statSync\(TARGET\)/.test(v));
  /* The transcript quotes suite output verbatim, and suite output quotes note
     titles and stem text out of the licensed corpus. It is a local diagnostic
     and must never become a commit. */
  const ignored = fs.readFileSync(path.join(ROOT, '.gitignore'), 'utf8');
  ok('and the transcript is gitignored, because suite output quotes licensed content',
     /^tests\/last-run\.log\s*$/m.test(ignored));
}

head('the tools the suites need are pinned, and named before they are missed');
{
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const dev = pkg.devDependencies || {};
  /* PINNED, NOT RANGED. A suite that measures a browser is measuring a specific
     browser: "^1.63.0" makes a green run mean "green on whatever shipped this
     week", which is not a claim anybody can act on later. */
  ok('playwright is a devDependency', !!dev.playwright, dev.playwright || 'absent');
  ok('and pinned to one exact version', /^\d+\.\d+\.\d+$/.test(dev.playwright || ''), dev.playwright || '');
  /* ts-fsrs generates tests/fixtures/fsrs-oracle.json and is used for nothing
     else. The fixture is committed, so verify-oracle runs without it — but the
     version that produced the fixture has to be recorded somewhere a person can
     find, and the fixture names it too. */
  ok('ts-fsrs is a devDependency, pinned', /^\d+\.\d+\.\d+$/.test(dev['ts-fsrs'] || ''), dev['ts-fsrs'] || 'absent');
  /* axe-core is the rule engine verify-a11y runs in each screen. Pinned for the same reason as the browser: a rule set that
     moves under the suite makes a green run mean nothing in particular. */
  ok('axe-core is a devDependency, pinned', /^\d+\.\d+\.\d+$/.test(dev['axe-core'] || ''), dev['axe-core'] || 'absent');
  const fx = JSON.parse(fs.readFileSync(path.join(TESTS, 'fixtures', 'fsrs-oracle.json'), 'utf8'));
  ok('and it is the version the committed oracle was generated with',
     fx.generator && fx.generator.version === dev['ts-fsrs'],
     `${fx.generator && fx.generator.version} in the fixture, ${dev['ts-fsrs']} in package.json`);
  /* The transitive tree, so "the same versions" survives a reinstall. */
  const lockPath = path.join(ROOT, 'package-lock.json');
  ok('a lockfile is committed', fs.existsSync(lockPath));
  if (fs.existsSync(lockPath)) {
    const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
    const pkgs = lock.packages || {};
    ok('and it pins the same playwright the manifest asks for',
       pkgs['node_modules/playwright'] && pkgs['node_modules/playwright'].version === dev.playwright,
       (pkgs['node_modules/playwright'] || {}).version || 'not in the lockfile');
    ok('down to playwright-core, which is what actually drives the browser',
       !!(pkgs['node_modules/playwright-core'] || {}).version,
       (pkgs['node_modules/playwright-core'] || {}).version || 'not in the lockfile');
  }

  /* NOTHING ELSE IS INSTALLED FOR THE TESTS. chai and mocha were added once
     and no suite loaded either (the suites carry their own ok()), yet `npm ci`
     fetched their 26 packages in each CI job that installs, the self-hosted
     runner that holds the licensed export among them, while package.json and
     docs/BUILD.md went on naming two tools. A tool a suite needs is added to
     NAMED with the line that says what it is for. The list is written here and
     not read from package.json, because the defect is that file growing. Every
     dependency field is read: a tool moved to "dependencies" is not out of
     reach of this. */
  const NAMED = ['playwright', 'ts-fsrs', 'axe-core'];
  const declared = ['dependencies', 'devDependencies', 'optionalDependencies', 'peerDependencies']
    .flatMap(k => Object.keys(pkg[k] || {}).map(n => (k === 'devDependencies' ? n : `${n} (${k})`)));
  const strays = declared.filter(n => !NAMED.includes(n));
  ok('and no other tool is installed for them: each is another package every npm ci fetches and trusts',
     !strays.length, strays.length ? `${strays.join(', ')}; named: ${NAMED.join(', ')}` : NAMED.join(', '));

  /* THE NODE MINIMUM IS ONE FACT, STATED IN FOUR PLACES. package.json says
     ">=22". docs/BUILD.md said "Node 18+" and the Codespaces image pulled
     Node 20 until a reader found both; scripts/doctor.js reads package.json,
     so a Codespace built from that image would fail the doctor's Node line
     at its first session. AGENTS.md, the line every session reads first, said
     22 and was right; it is held with the rest so that it stays so. The prose
     and the image follow the manifest. Each check fails when it cannot read
     its claim, so a reworded line is a failure to fix here and not a pass that
     measured nothing. */
  const need = +((String((pkg.engines || {}).node || '').match(/(\d+)/) || [])[1] || 0);
  ok('package.json declares a Node minimum', need > 0, (pkg.engines || {}).node || 'no engines.node');
  const said = /\*\*Node (\d+)\+\*\*/.exec(fs.readFileSync(path.join(ROOT, 'docs', 'BUILD.md'), 'utf8'));
  ok('docs/BUILD.md names that minimum, not an older one', !!said && +said[1] === need,
     said ? `BUILD.md says ${said[1]}+, package.json wants ${need}` : 'no "**Node N+**" line in docs/BUILD.md');
  const told = /Use Node (\d+) or newer/.exec(fs.readFileSync(path.join(ROOT, 'AGENTS.md'), 'utf8'));
  ok('and AGENTS.md, which every session reads first, says the same', !!told && +told[1] === need,
     told ? `AGENTS.md says ${told[1]}, package.json wants ${need}` : 'no "Use Node N or newer" in AGENTS.md');
  const dcFile = path.join(ROOT, '.devcontainer', 'devcontainer.json');
  const dcText = fs.existsSync(dcFile) ? fs.readFileSync(dcFile, 'utf8') : null;
  const image = dcText === null ? null : /javascript-node:(?:\d+-)?(\d+)\b/.exec(dcText);
  ok('and no Codespaces image runs an older Node', need > 0 && (dcText === null || (!!image && +image[1] >= need)),
     dcText === null ? 'no .devcontainer, so no image' : image ? `image Node ${image[1]}, package.json wants ${need}` : 'no javascript-node:<major> image in devcontainer.json');

  /* AN ENGINE THE HARNESS ACCEPTS IS NOT AN ENGINE THAT IS INSTALLED. firefox
     is in ENGINES and is not provisioned everywhere; without a check the run
     spawns every suite, each fails identically on a missing executable, and
     fifteen minutes later says one thing once. */
  const v = fs.readFileSync(path.join(ROOT, 'scripts', 'verify.js'), 'utf8');
  ok('the runner checks the browser exists before spawning a single suite',
     /executablePath\(\)/.test(v) && /npx playwright install/.test(v));
}

head('a suite pointed at a URL either runs whole or does not run');
{
  /* WHY THIS IS ANCHORED TO NAMES. scripts/verify.js can now be given a served
     build instead of a file, and it asks tests/_targets.js which suites that
     is safe for. A classifier checked only against its own logic proves
     nothing — so the anchors below are suites whose behaviour against a URL
     was OBSERVED, and the classifier has to agree with what happened:

       apex          threw ENOENT opening 'http://localhost:8141/index.html'
       splash-heart  finished GREEN with 8 checks where it has 14
       keys          threw ENOENT — it has no URL guard at all
       type          path.resolve made '/home/user/drnerd/http:/localhost:8141/…'
       home, physio, stage0, pearl   ran and reported in full

     splash-heart is the one that matters. The other three failed loudly, which
     is survivable; it passed, with six checks missing, which is not. Any
     rewrite of the matching that readmits it fails here. */
  const T = require('./_targets.js');

  const MUST_NOT = {
    apex: 'reads its target from disk after building the page URL',
    splash: 'the same',
    'splash-heart': 'the same, and it goes GREEN with 8 of 14 checks when it happens',
    keys: 'no URL guard — path.resolve mangles the URL',
    type: 'the same',
  };
  const MUST = ['home', 'physio', 'stage0', 'pearl', 'layout', 'theme'];

  for (const [name, why] of Object.entries(MUST_NOT)) {
    const v = T.classify(name);
    ok(`${name} is not offered a URL — ${why}`, v.capable === false, v.reason || 'classified capable');
  }
  for (const name of MUST) {
    const v = T.classify(name);
    ok(`${name} can be run against a served build`, v.capable === true, v.reason);
  }

  /* The guard alone is not the test, and this is the check that says so: all
     three of the observed failures DO carry `^https?:`. A classifier that
     looked only for it would call them capable. */
  const guarded = ['apex', 'splash', 'splash-heart'].filter(n =>
    /\^https\?:/.test(fs.readFileSync(path.join(TESTS, `verify-${n}.js`), 'utf8')));
  ok('and the three that cannot are excluded despite carrying the URL guard',
     guarded.length === 3, `${guarded.length} of 3 carry it`);

  /* Vacuity guard. If the source matching stops finding anything — a renamed
     variable, a reformat — every suite would come back "takes no target
     argument", every URL run would skip everything, and each check above would
     still pass because they assert incapability for five of them. */
  const all = T.allSuiteNames();
  const capable = all.filter(T.takesUrl);
  ok('the classifier still finds suites of both kinds', capable.length > 20 && capable.length < all.length,
     `${capable.length} capable of ${all.length}`);
  /* The precise risk is the ARGV pattern silently failing to match: a suite
     that DOES bind process.argv[2] but whose binding this cannot see comes
     back "takes no target argument", which reads like the pure-logic suites
     that genuinely take none. So the two are told apart by the source itself
     rather than by a list of names — a suite that mentions process.argv[2]
     must have been parsed. Read through the shared blanker: this used to
     strip comments with a pair of regular expressions of its own. */
  const mentionsArgv = all.filter(n =>
    /process\.argv\[2\]/.test(blankComments(fs.readFileSync(path.join(TESTS, `verify-${n}.js`), 'utf8'))));
  const unparsed = mentionsArgv.filter(n => T.classify(n).reason === 'takes no target argument');
  ok('every suite that binds a target argument was understood to bind one',
     unparsed.length === 0, unparsed.join(', ') || `${mentionsArgv.length} parsed, none missed`);

  /* The runner has to actually consult it. The classifier being right is no
     use if verify.js keeps its own copy of the question. */
  const v = fs.readFileSync(path.join(ROOT, 'scripts', 'verify.js'), 'utf8');
  ok('the runner asks _targets.js rather than matching for itself',
     /require\([^)]*_targets\.js[^)]*\)/.test(v) && !/function takesUrl/.test(v));
  ok('and names what it skipped instead of quietly running fewer suites',
     /urlIncapable/.test(v) && /cannot take a URL/.test(v));
}

head('no suite waits inside a page that may not survive the wait');
{
  /* TWICE IN ONE EVENING, in two suites, from the same shape:

         const settle = ms => page.evaluate(m => new Promise(r => setTimeout(r, m)), ms);
         await page.evaluate(() => new Promise(r => setTimeout(r, 500)));

     An evaluate whose entire body is a timer holds an execution context open
     in the page for the whole pause. If anything navigates or the page goes
     away in that window — and on the served build the app can navigate on its
     own, since the service worker reloads when a new one takes over — the
     wait fails, and the failure is reported as a failure OF THE WAIT:

         verify-resume      Execution context was destroyed, most likely
                            because of a navigation
         verify-heartreuse  Target page, context or browser has been closed
                            at settle (verify-heartreuse.js:84)

     Neither described what happened. One pointed at a navigation that was
     incidental and the other named the sleep as the victim. Both are
     page.waitForTimeout now, which runs in the driver, cannot be destroyed by
     anything the page does, and reports the page's death as the page's death.

     SCOPED TO SLEEP-ONLY EVALUATES on purpose. An evaluate that does real work
     AND waits has to run in the page — the work does — and moving it is not
     possible, only splitting it is. Those are left alone. What this refuses is
     the case where the evaluate exists ONLY to pass time, which never needs to
     be in the page and has now cost two debugging sessions. */
  /* THE RESOLVER PASSED STRAIGHT TO setTimeout, and nothing else — a
     backreference, so `new Promise(r => setTimeout(r, 800))` matches and
     `new Promise(r => setTimeout(() => r({ … }), 1200))` does not. The second
     is a wait that then READS something, which has to be in the page because
     the reading does. The first version of this check lacked the
     backreference and called verify-pwa:138 a violation on that basis — a
     check whose comment said "with nothing else to do" flagging something
     that had plenty. Narrowed to what it claims. */
  const SLEEP_ONLY = /\.evaluate\(\s*(?:async\s*)?(?:\([^)]*\)|\w+)\s*=>\s*new Promise\(\s*(\w+)\s*=>\s*setTimeout\(\s*\1\s*,/;
  const suites = fs.readdirSync(TESTS).filter(n => /^verify-.+\.js$/.test(n));
  const sleeping = [];
  let evaluates = 0;
  for (const f of suites) {
    const src = blankComments(fs.readFileSync(path.join(TESTS, f), 'utf8'));
    evaluates += (src.match(/\.evaluate\(/g) || []).length;
    /* Newlines collapsed, because the two real instances were written across
       one line and across two, and a line-by-line scan found only one. */
    const flat = src.replace(/\s+/g, ' ');
    if (SLEEP_ONLY.test(flat)) sleeping.push(f);
  }
  /* Vacuity guard: "count the sleeping evaluates and expect none" is also what
     a scan that found no evaluates at all returns. */
  ok('there are evaluates to check', evaluates > 200, `${evaluates} across ${suites.length} suites`);
  ok('and none of them is a sleep with nothing else to do',
     sleeping.length === 0, sleeping.join(', ') || 'none');
}

head('a reload is not a boot, and the split build is why');
{
  /* WHAT THIS CATCHES, found in verify-theme and not by reading it.
     page.reload() resolves on a navigation event — `load`, or worse
     `domcontentloaded`. In the SINGLE FILE that is close enough to "the app is
     running", because every line of it is inline and has executed by then. In
     the SPLIT BUILD it is not: index.html's loader fetches
     content/questions.json and only THEN injects app.js, so both events fire
     long before a single application symbol exists.

     verify-theme reloaded with `domcontentloaded`, read the pre-paint
     attributes — which is the point of that section and correct — and then
     carried straight on into a section that needs the app. Against the single
     file it passed for years. Against the served build it died with

         page.evaluate: ReferenceError: Can't find variable: setTheme

     which reads like a missing function and is a missing WAIT. That is the
     same shape as the four races tests/_render.js was written for.

     THE RULE IS "WAIT FOR SOMETHING", deliberately loose. Every other reload in
     the repository already does: booted(), a waitForFunction naming an app
     global, a waitForSelector, a locator's waitFor(), or a poll on `typeof S`.
     Requiring booted() specifically would have flagged five suites that are
     already correct — verify-splash reloads with `commit` precisely to catch
     the page BEFORE the app, and being made to wait for it would destroy the
     check. So the guard asks only that something between the reload and the
     next read is capable of being false before the app is up. It has no
     exemption list because it needs none.

     ANY PAGE, NOT ONLY ONE NAMED page. This matched `await page.reload(`
     alone, so a reload on p, r, p2 or other was never examined: twelve of the
     thirty-three at c6f12d9, the Memorizer suites' and verify-lab's among
     them, while the label said "every one of them". The second check below
     fails if the scan ever again sees reloads on `page` alone.

     A SLEEP IS NOT A WAIT. waitForTimeout passed, because it begins with
     waitFor; a fixed sleep cannot be false before the app is up, which is
     the whole of the rule. */
  const RELOAD = /await\s+([\w$.]+)\.reload\s*\(/;
  const WAITS = /booted\s*\(|waitFor(?!Timeout\b)[A-Za-z]*\s*\(|typeof\s+[A-Za-z_$]/;
  const suites = fs.readdirSync(TESTS).filter(n => /^verify-.+\.js$/.test(n));
  let reloads = 0;
  const blind = [], receivers = {};
  for (const f of suites) {
    const lines = blankComments(fs.readFileSync(path.join(TESTS, f), 'utf8')).split('\n');
    lines.forEach((l, i) => {
      const m = RELOAD.exec(l);
      if (!m) return;
      reloads++;
      receivers[m[1]] = (receivers[m[1]] || 0) + 1;
      /* AS FAR AS THE NEXT SECTION, not a fixed handful of lines. A reload
         may legitimately be followed by reads that must happen BEFORE the app
         is back — verify-theme reads the pre-paint attributes, verify-splash
         catches the splash — and the wait then comes after those. A six-line
         window called verify-theme's own fix a violation. The section is the
         real boundary: whatever a reload sets up, it sets up for the checks
         under the same heading.

         And FROM THE RELOAD ITSELF, not from the next line. Six reloads wait
         on their own line — `await r.reload(); await r.waitForFunction(…)` —
         and a window that began on the following line called five of them
         blind the moment their receivers were looked at; the sixth passed
         only by borrowing the next reload's wait. */
      let end = i + 1;
      while (end < lines.length && !/^\s*head\s*\(/.test(lines[end]) && end - i < 60) end++;
      const after = [l.slice(m.index + m[0].length)].concat(lines.slice(i + 1, end)).join('\n');
      if (!WAITS.test(after)) blind.push(`${f}:${i + 1}`);
    });
  }
  /* Vacuity guard: "count the blind reloads and expect none" is also what a
     scan that found no reloads at all returns. */
  ok('there are reloads to check', reloads >= 8, `${reloads} across ${suites.length} suites`);
  ok('and they include reloads on page variables not named page',
     Object.keys(receivers).some(r => r !== 'page'),
     Object.entries(receivers).map(([r, n]) => `${r} ${n}`).join(', ') || 'none');
  ok('and every one of them waits for something afterwards',
     blind.length === 0, blind.join(', ') || 'none');
}

/* ────────────────────────────────────────────────────────────────────────────
 * A SUITE THAT DIES MUST BE ABLE TO SAY SO.
 *
 * tests/_deathnote.js prints what the page said before a suite died. It is
 * two lines to install and it is the only evidence there is when a browser
 * takes a page down — "Target page, context or browser has been closed" names
 * the survivor, never the cause. All 46 browser suites now carry one, and
 * this keeps the forty-seventh from being written without one.
 *
 * The other two checks here are both mistakes I made during the rollout, and
 * neither is visible to `node --check`:
 *
 *   · LISTENERS ABOVE THE PAGE. verify-type.js creates a page per viewport
 *     inside a loop; my listeners went on above the loop, naming a `page`
 *     that did not exist yet. That is a ReferenceError thrown from inside the
 *     handler for the crash you were trying to diagnose — the diagnostic
 *     fails exactly when it is needed. The cure is shape, not vigilance:
 *     watch() RETURNS the page, so `watch(await browser.newPage(…), events)`
 *     has no way to be written out of order. So the rule checked is that the
 *     creation and the watch are the same expression.
 *
 *   · A CATCH THAT SWALLOWS THE NOTE. Four suites ended with
 *     `})().catch(e => { console.error(e); process.exit(1); })`. A catch
 *     HANDLES the rejection, so process.on('unhandledRejection') never fires
 *     and the note never prints — a suite that looks instrumented and is not.
 *     They now pass the note's own emitter, which also moves the exception
 *     off stderr; scripts/verify.js concatenates the two pipes in no
 *     guaranteed order, and that has already cut one note in half.
 */
{
  head('every browser suite can say how it died');
  const suites = fs.readdirSync(TESTS).filter(f => /^verify-.*\.js$/.test(f)).sort();
  const browserSuites = [], noNote = [], splitWatch = [], swallowed = [];
  let watches = 0;
  for (const f of suites) {
    const code = blankComments(fs.readFileSync(path.join(TESTS, f), 'utf8'));
    /* The same test _engine.js's own guard uses, and for the same reason:
       this file discusses launch() in prose, so the scan is anchored to a
       line with no quote before the call. */
    if (!/^[^'"`\n]*\blaunch\(/m.test(code)) continue;
    browserSuites.push(f);
    if (!/require\(\s*'\.\/_deathnote(?:\.js)?'\s*\)/.test(code) || !/\bonDeath\s*\(/.test(code)) {
      noNote.push(f);
      continue;
    }
    /* Every watch() must wrap the creation. `watch(await X.newPage(…), …)` is
       the only form in which the listeners cannot precede the page. */
    for (const m of code.matchAll(/\bwatch\s*\(/g)) {
      watches++;
      const line = code.slice(code.lastIndexOf('\n', m.index) + 1,
                             (code.indexOf('\n', m.index) + 1 || code.length) - 1);
      /* The context may be awaited inside the page's own creation —
         `watch(await (await browser.newContext()).newPage(), …)` — which is
         still ONE expression and still cannot be written out of order. The
         first version of this required newPage() to follow the await
         directly and failed four honest call sites. What is actually being
         asserted is that the creation is an ARGUMENT to watch(), so that is
         what is matched. */
      if (!/\bwatch\s*\(\s*await\s[^;]*\bnewPage\s*\(/.test(line)) {
        splitWatch.push(`${f}: ${line.trim().slice(0, 60)}`);
      }
    }
    /* The tail. A handler that is not the emitter returned by onDeath() eats
       the rejection before the process ever sees it. */
    /* The WHOLE tail, not one line of it. The first version matched a
       .catch whose argument fit on one line, so a handler written across
       four — `.catch(e => {\n console.error(...); process.exit(1);\n})` —
       swallowed the note just as surely and passed: verify-echo did exactly
       that for a day. Anchored to the end of the file, not the end of a line,
       and the argument may span lines. */
    const tail = /\}\)\(\)\s*\.catch\s*\(([\s\S]*)\)\s*;?\s*$/.exec(code);
    if (tail && !/^\s*\w+\s*$/.test(tail[1])) swallowed.push(`${f}: .catch(${tail[1].trim().slice(0, 40)})`);
  }
  /* Vacuity guards, both directions. "No suite is missing a note" is also
     what a scan that found no suites returns, and "no watch() is split" is
     what a scan that found no watch() calls returns. */
  ok('there are browser suites to check', browserSuites.length >= 40, `${browserSuites.length} found`);
  ok('and watch() calls among them', watches >= 40, `${watches} found`);
  ok('every browser suite installs a death note',
     noNote.length === 0, noNote.join(', ') || 'none');
  ok('every watch() wraps the page creation, so no listener can precede its page',
     splitWatch.length === 0, splitWatch.join(' | ') || 'none');
  ok('no suite ends with a catch that would swallow the note',
     swallowed.length === 0, swallowed.join(' | ') || 'none');
}

/* ────────────────────────────────────────────────────────────────────────────
 * NO SUITE SPAWNS npm BY ITS BARE NAME.
 *
 * On Windows npm, npx, yarn and pnpm are .cmd shims, not executables. Since
 * Node 20.12 (CVE-2024-27980) spawnSync/execFileSync REFUSE to launch a .cmd
 * without shell:true — status null, no output, no error most callers look at.
 * On Linux and macOS the same call resolves a shell script and works.
 *
 * So this is a defect that cannot fail on the machine most of this was
 * written on, and it shipped: tests/verify-release.js spawned 'npm' whenever
 * npm_execpath was unset, which is every run of
 *
 *     node scripts/verify.js build/systole.html
 *
 * since nothing sets that variable outside an `npm run`. It passed here and
 * failed on the owner's laptop, inside a 22-minute full run, for a reason
 * that had nothing to do with the release gate it was checking.
 *
 * The cure is to run npm's own JavaScript entry point with process.execPath:
 * no shell, no .cmd, no PATH lookup, and the same two lines on both
 * platforms.
 *
 * NOT A BAN ON SPAWNING. git is spawned by name in several places and stays
 * that way — git.exe is a real executable and Node launches it fine. Only the
 * npm family are shims, so only they are named here.
 */
{
  head('no suite spawns a tool Windows only has as a .cmd shim');
  const suites = fs.readdirSync(TESTS).filter(f => /^verify-.*\.js$/.test(f)).sort();
  const SHIMS = /\b(?:spawnSync|spawn|execFileSync|execFile)\s*\(\s*['"](npm|npx|yarn|pnpm)['"]/;
  const bare = [];
  let spawns = 0;
  for (const f of suites) {
    const code = blankComments(fs.readFileSync(path.join(TESTS, f), 'utf8'));
    for (const line of code.split('\n')) {
      if (/\b(?:spawnSync|spawn|execFileSync|execFile)\s*\(/.test(line)) spawns++;
      const m = SHIMS.exec(line);
      if (m) bare.push(`${f}: ${m[1]}`);
    }
  }
  /* Vacuity guard: "no suite spawns npm by name" is also what a scan that
     found no spawns at all returns. */
  ok('there are spawns to check', spawns >= 5, `${spawns} across ${suites.length} suites`);
  ok('and none of them names npm, npx, yarn or pnpm directly',
     bare.length === 0, bare.join(', ') || 'none');
  /* The other half: the suite that DOES drive npm must resolve its JS entry
     point rather than trusting PATH. Checked by name because there is exactly
     one, and if a second appears this line is where it will be noticed. */
  const rel = blankComments(fs.readFileSync(path.join(TESTS, 'verify-release.js'), 'utf8'));
  ok('the one suite that drives npm runs its entry point with this node',
     /spawnSync\(process\.execPath, \[npmCli, 'run'/.test(rel));
  ok('and says so rather than comparing two nulls when it cannot find it',
     /!!npmCli, npmCli \|\| 'not found/.test(rel));
}

head('no waitForFunction predicate returns a Promise, which it never awaits');
{
  /* page.waitForFunction treats a returned Promise as truthy and stops on the
     first poll (tests/_render.js, above resolved(), has the measurement). Four
     waits in verify-memorizer were MemStore.get(…).then(…) and waited for
     nothing. Narrow on purpose: it catches an async predicate, and an arrow
     whose expression body is a call chain ending in .then(, new Promise or
     fetch( — the shapes that were there. A block body that returns a Promise
     is not caught. */
  const PROMISE_PRED = /waitForFunction\(\s*(?:async\b|(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>\s*(?:new\s+Promise\b|fetch\(|[\w$.]+\([^()]*\)\s*\.then\())/;
  ok('the scan recognises the shape it hunts', PROMISE_PRED.test("p.waitForFunction(id => MemStore.get('docs', id).then(d => d.ok), x, T)") &&
     PROMISE_PRED.test('p.waitForFunction(async () => 1)') && !PROMISE_PRED.test("p.waitForFunction(() => document.querySelector('#x'), null, T)"));
  /* Two files hold the shape on purpose, as data: verify-render runs the trap
     to prove it is real, and this file tests the scan on samples. */
  const EXEMPT = ['verify-render.js', 'verify-engine.js'];
  const bad = fs.readdirSync(TESTS).filter(n => /^verify-.+\.js$/.test(n) && !EXEMPT.includes(n))
    .filter(f => PROMISE_PRED.test(blankComments(fs.readFileSync(path.join(TESTS, f), 'utf8'))));
  ok('no suite passes waitForFunction a predicate that returns a Promise — resolved() in tests/_render.js awaits one', bad.length === 0, bad.join(', ') || 'none');
}

head('one WebKit page error is engine noise, and only that one');
{
  const err = (first, frame) => ({ message: 'x', stack: first + '\n    at ' + frame + ' (https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/legacy/build/pdf.min.js:22:1)' });
  const pdfw = err('Cannot load blob:http://localhost:8137/0a1b due to access control checks.', '_initialize') ;
  pdfw.stack += '\n    at PDFWorker (pdf.min.js:22:2)';
  ok('pdf.js\u2019s refused blob: worker on WebKit is noise', E.isEngineNoiseError(pdfw, 'webkit') === true);
  ok('the same error on Chromium is still an error', E.isEngineNoiseError(pdfw, 'chromium') === false);
  const other = err('Cannot load blob:http://localhost:8137/0a1b due to access control checks.', 'loadFigure');
  ok('the same sentence from code that is not pdf.js\u2019s worker is still an error', E.isEngineNoiseError(other, 'webkit') === false);
  const near = err('Cannot load blob:http://localhost:8137/0a1b due to access control checks. And more', '_initialize');
  near.stack += '\n    at PDFWorker (pdf.min.js:22:2)';
  ok('a different message from the same place is still an error', E.isEngineNoiseError(near, 'webkit') === false);
  /* And watch() applies it: a stand-in page, its pageerror handler fired by hand. */
  const { watch } = require('./_deathnote.js');
  const fire = (engine, e) => withEnv(engine, () => {
    const on = {}, events = [], errors = [];
    watch({ on: (k, f) => { on[k] = f; } }, events, 't', errors);
    on.pageerror(e);
    return { events, errors };
  });
  const wk = fire('webkit', pdfw);
  ok('watch() files it as an event, not an error, on WebKit', wk.errors.length === 0 && wk.events.length === 1 && /engine notice \(not counted\)/.test(wk.events[0]), JSON.stringify(wk));
  const cr = fire('chromium', pdfw), ot = fire('webkit', other);
  ok('and counts it on Chromium, and counts every other error on WebKit', cr.errors.length === 1 && ot.errors.length === 1, JSON.stringify({ cr: cr.errors, ot: ot.errors }));
}

head('clipboard permissions are asked for by engine, never by a Chromium-only name');
{
  ok('chromium is granted read and write', JSON.stringify(E.clipboardPermissions('chromium')) === '["clipboard-read","clipboard-write"]');
  ok('webkit is never asked for clipboard-write, which it refuses outright',
     JSON.stringify(E.clipboardPermissions('webkit')) === '["clipboard-read"]', JSON.stringify(E.clipboardPermissions('webkit')));
  ok('firefox is asked for neither', E.clipboardPermissions('firefox').length === 0);
  /* The rule, held across every suite: a permission list that names a
     clipboard permission outright is a Chromium list, and it kills the
     context on WebKit. */
  const hard = fs.readdirSync(TESTS).filter(n => /^verify-.+\.js$/.test(n))
    .filter(f => /permissions\s*:\s*\[[^\]]*clipboard-/.test(blankComments(fs.readFileSync(path.join(TESTS, f), 'utf8'))));
  ok('no suite writes a clipboard permission into a context itself', hard.length === 0, hard.join(', ') || 'none');
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
