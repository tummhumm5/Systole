#!/usr/bin/env node
/*
 * Behavioural checks for durable memory.
 *
 *   NODE_PATH=$(npm root -g) node tests/verify-memory.js /path/to/patched.html
 *
 * The claim this suite defends: Apex still knows you next time. That breaks in
 * quiet ways — a store that saves but is never sent, a block that reaches one
 * provider and not another, a grounded mode that silently drops it, a summariser
 * that fires once per question instead of once per sitting and burns the free
 * tier. So the important checks here intercept the real outbound request and
 * read the body, the same discipline verify-stage3 and verify-gemini use for
 * vision: state that looks right in localStorage proves nothing about what the
 * model was actually told.
 */
'use strict';
const fs = require('fs');
const http = require('http');
const path = require('path');
const { launch, isEngineNoise, routablePage } = require('./_engine');
const { booted, settled } = require('./_render.js');
const { onDeath } = require('./_deathnote.js');
const { systemText, turns, toolResults } = require('./_wire');

const target = process.argv[2];
if (!target) { console.error('usage: node tests/verify-memory.js <patched.html>'); process.exit(1); }
const URL = /^https?:\/\//.test(target) ? target : 'file://' + path.resolve(target);

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };
const flat = t => String(t || '').replace(/\s+/g, ' ');

const GEM_SSE = 'data: {"candidates":[{"content":{"role":"model","parts":[{"text":"Noted."}]}}]}\n\n';

/* What the summariser's one-shot call returns. Three lines plus a blank and a
   bullet, because a model will not reliably hand back clean output. */
const SUMMARY = 'Sits the boards in October 2026.\n- Confuses constriction with restriction.\n\nPrefers mechanism before trials.';

(async () => {
  const browser = await launch();
  const page = await routablePage(browser, { viewport: { width: 1280, height: 950 } });
  /* Hoisted so the death note can read them — this suite dies on WebKit
     against the served build, and the check that reports console errors is
     the one check a death never reaches. See tests/_deathnote.js. */
  const errors = [];
  const events = [];
  page.on('crash', () => events.push('the browser CRASHED the page'));
  page.on('close', () => events.push('the page closed'));
  page.on('requestfailed', r => {
    const why = (r.failure() || {}).errorText || '';
    if (why) events.push(`request failed: ${String(r.url()).slice(-50)} — ${why}`);
  });
  /* Installed once the arrays exist. A crash and a close are different
     diagnoses and Playwright reports both as "Target page, context or
     browser has been closed" on the next call; only the event says which. */
  onDeath(() => ({ section, checks: passed + failed, errors,
                   events: events.length ? events.join(', ') : 'none' }));
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !isEngineNoise(m.text())) errors.push(m.text()); });

  /* Gemini only. A capture for the retired Mistral route stayed here after
     nothing could reach it, and a check counted it: an array that can only be
     empty passes every "no call was made" asked of it. */
  const gem = [];
  await page.route('**/generativelanguage.googleapis.com/**', route => {
    const url = route.request().url();
    let b = null; try { b = JSON.parse(route.request().postData() || '{}'); } catch (_) {}
    gem.push({ url, body: b });
    if (/\/v1beta\/models(\?|$)/.test(url)) {
      route.fulfill({ status: 200, headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ models: [{ name: 'models/gemini-9.9-flash', displayName: 'G',
          supportedGenerationMethods: ['generateContent', 'countTokens'] }] }) });
      return;
    }
    if (/:streamGenerateContent/.test(url)) {
      route.fulfill({ status: 200, headers: { 'content-type': 'text/event-stream' }, body: GEM_SSE });
      return;
    }
    route.fulfill({ status: 200, headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ candidates: [{ content: { parts: [{ text: SUMMARY }] } }] }) });
  });
  /* Hosted: a served build with no key typed calls Gemini through this site's
     /api/apex/gemini/ route, where the Worker holds the key. Matched on the
     path, whatever origin serves the page. Until the hosted section at the end
     turns answers on, a call here gets what Cloudflare Access sends a lapsed
     session, 200 and a sign-in page, so the app has nothing to keep and nothing
     leaves the test. Before that section only a served target makes one (the
     no-key case in the summariser section); the single file makes none. */
  const hosted = [];
  let hostedAnswers = false;
  await page.route(u => u.pathname.startsWith('/api/apex/gemini/'), route => {
    hosted.push({ url: route.request().url(), method: route.request().method() });
    if (!hostedAnswers) {
      route.fulfill({ status: 200, headers: { 'content-type': 'text/html' }, body: '<!doctype html><title>Sign in</title>' });
      return;
    }
    route.fulfill({ status: 200, headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ candidates: [{ content: { parts: [{ text: SUMMARY }] } }] }) });
  });

  await page.goto(URL, { waitUntil: 'load', timeout: 200000 });
  await booted(page);
  await page.waitForTimeout(900);

  const seed = () => page.evaluate(() => {
    Memory.clear();
    Memory.add('Sitting the ABIM boards in October 2026.', 'fact');
    Memory.add('Keeps reading constrictive pericarditis as restrictive cardiomyopathy.', 'gap');
    Memory.add('Wants the mechanism before the trial.', 'preference');
  });

  head('the store');
  const store = await page.evaluate(() => {
    Memory.clear();
    const empty = Memory.build();
    const a = Memory.add('Sitting the boards in October 2026.', 'fact');
    const dupe = Memory.add('  sitting THE boards in October 2026!!  ', 'fact');
    const blank = Memory.add('   ', 'fact');
    const bad = Memory.add('Something odd.', 'not-a-kind');
    const b = Memory.add('Second-year fellow.', 'fact');
    const afterAdds = Memory.count();               // a, bad, b — dupe and blank added nothing
    const newest = Memory.all()[0].text;
    const removed = Memory.remove(b.id);
    const afterRemove = Memory.count();
    return { empty, count: afterAdds, dupeSame: dupe && dupe.id === a.id,
             blank, badKind: bad && bad.kind, newest,
             removed, afterRemove, removeMissing: Memory.remove('nope') };
  });
  ok('an empty store contributes nothing to the prompt', store.empty === '', JSON.stringify(store.empty));
  ok('the same thing said twice is one memory, not two',
     store.dupeSame && store.count === 3, 'same record: ' + store.dupeSame + ', count ' + store.count);
  ok('an empty memory is refused', store.blank === null);
  ok('an unknown kind falls back to fact rather than creating a new bucket', store.badKind === 'fact', store.badKind);
  ok('newest is first even within the same millisecond', store.newest === 'Second-year fellow.', store.newest);
  ok('remove works', store.removed === true && store.afterRemove === 2, 'left ' + store.afterRemove);
  ok('removing something absent reports false rather than throwing', store.removeMissing === false);

  head('the cap decays session summaries first');
  const capped = await page.evaluate(() => {
    Memory.clear();
    const keep = Memory.add('Sits boards in October.', 'fact');
    for (let i = 0; i < Memory.MAX + 20; i++) Memory.add('Session note number ' + i + '.', 'session');
    return { count: Memory.count(), max: Memory.MAX,
             keptTheFact: Memory.all().some(m => m.id === keep.id),
             oldestSessionGone: !Memory.all().some(m => m.text === 'Session note number 0.'),
             newestSessionKept: Memory.all().some(m => m.text === 'Session note number ' + (Memory.MAX + 19) + '.') };
  });
  ok('the store stays at its cap', capped.count === capped.max, capped.count + '/' + capped.max);
  ok('a fact the fellow shaped survives a flood of auto-summaries', capped.keptTheFact);
  ok('the oldest session summary is what gets dropped', capped.oldestSessionGone);
  ok('the newest session summary is kept', capped.newestSessionKept);

  head('the block itself');
  await seed();
  const block = await page.evaluate(() => Memory.build());
  ok('it is headed so the model knows what it is', /WHAT YOU ALREADY KNOW ABOUT THIS FELLOW/.test(block));
  ok('it tells the model not to recite it back', /do not recite it back/i.test(block));
  ok('every line carries an id the forget tool can name', (block.match(/\[m[a-z0-9]+\]/g) || []).length === 3,
     JSON.stringify((block.match(/\[m[a-z0-9]+\]/g) || [])));
  ok('the kinds are grouped, not run together', /About them:/.test(block) && /How they want to be taught:/.test(block));
  ok('it stays within a sane prompt budget', block.length < 1600, block.length + ' chars');

  head('it survives a reload — the whole point');
  await page.reload({ waitUntil: 'load', timeout: 200000 });
  await page.waitForFunction(() => typeof S !== 'undefined' && typeof Memory !== 'undefined', null, { timeout: 120000 });
  await page.waitForTimeout(600);
  const survived = await page.evaluate(() => ({ n: Memory.count(), has: /October 2026/.test(Memory.build()) }));
  ok('memories are still there after a reload', survived.n === 3 && survived.has, 'count ' + survived.n);

  const ask = async (provider) => {
    gem.length = 0;
    await page.evaluate(async (provider) => {
      AI.provider = provider;
      AI.gemini = { key: 'AQ.test', model: 'gemini-9.9-flash' };
      const q = ALL_Q.find(x => !x.bad);
      jumpTo(q.id);
      const sh = document.getElementById('shell');
      if (!sh.classList.contains('ai-open')) toggleAI();
      buildAI();
      fire('why is this the answer?');
    }, provider);
    await page.waitForTimeout(1500);
    return (gem.find(g => /:streamGenerateContent/.test(g.url)) || {}).body;
  };

  /* THIS SECTION USED TO RUN TWICE, once per provider, and the point of the
     pair was the claim in the second heading: memory is injected with NO
     per-provider code. That claim needed two providers to demonstrate and
     cannot be demonstrated with one, so the Mistral half retires with the
     provider rather than being restated against the same wire twice — which
     would look like coverage and prove nothing. */
  head('it actually reaches the model');
  const gReq = await ask('gemini');
  const gSys = flat(((gReq && gReq.systemInstruction || {}).parts || []).map(p => p.text || '').join('\n'));
  ok('a request was made', !!gReq);
  ok('the memory block is in the systemInstruction', /WHAT YOU ALREADY KNOW ABOUT THIS FELLOW/.test(gSys));
  ok('the actual memory text is there', /boards in October 2026/.test(gSys));

  head('grounded mode keeps it — it is who you teach, not what you teach from');
  gem.length = 0;
  await page.evaluate(async () => {
    AI.provider = 'gemini';
    AI_GROUNDED = true;
    const q = ALL_Q.find(x => !x.bad);
    jumpTo(q.id); buildAI();
    fire('what do my notes say?');
  });
  await page.waitForTimeout(1500);
  const gReq2 = (gem.find(g => /:streamGenerateContent/.test(g.url)) || {}).body;
  const gSys2 = flat(systemText(gReq2));
  ok('grounded mode is genuinely on', /GROUNDED MODE IS ON/.test(gSys2));
  ok('memory is still present in grounded mode', /WHAT YOU ALREADY KNOW ABOUT THIS FELLOW/.test(gSys2));
  ok('and the commentary is still withheld, so grounding was not weakened',
     !/OFFICIAL ACC COMMENTARY/.test(gSys2));
  await page.evaluate(() => { AI_GROUNDED = false; });

  head('the tools');
  const tools = await page.evaluate(() => {
    Memory.clear();
    const declared = TOOLS.filter(t => t.name === 'remember' || t.name === 'forget').map(t => t.name);
    const r = runTool('remember', { text: 'Sits the boards in October.', kind: 'fact' });
    const afterRemember = Memory.count();
    const id = Memory.all()[0].id;
    const f = runTool('forget', { id });
    const afterForget = Memory.count();
    const fMissing = runTool('forget', { id: 'nope' });
    const rEmpty = runTool('remember', { text: '   ' });
    return { declared, saved: /Kept as \[/.test(r.result), count: afterRemember,
             forgot: /Forgotten/.test(f.result), gone: afterForget,
             missingHandled: /No memory has that id/.test(fMissing.result),
             emptyHandled: /Nothing to remember/.test(rEmpty.result),
             labels: [TOOL_LABEL.remember, TOOL_LABEL.forget, TOOL_LABEL.start_review_session] };
  });
  ok('both tools are declared to the model', tools.declared.length === 2, tools.declared.join(', '));
  ok('remember stores, and reports the id back so forget can name it', tools.saved && tools.count === 1);
  ok('forget removes', tools.forgot && tools.gone === 0);
  ok('forgetting something absent does not lie about success', tools.missingHandled);
  ok('remembering nothing is refused rather than stored blank', tools.emptyHandled);
  ok('the tool chips are labelled, including the review session that never was',
     tools.labels.every(Boolean), JSON.stringify(tools.labels));

  head('the panel');
  await seed();
  /* render() runs through startViewTransition when the screen changes, so the
     new DOM is not there on the next line — wait for the cards, not a timer. */
  await page.evaluate(() => goMemory());
  /* The cards only, not a wait on the screen: S.screen === 'memory' is what the first check below
     asserts, and waiting for it would leave that check nothing to catch (found in review of #180). */
  await settled(page, () => document.querySelectorAll('.ref-card').length > 0, { label: "the memory screen's cards" });
  const panel = await page.evaluate(() => ({
    screen: S.screen,
    cards: document.querySelectorAll('.ref-card').length,
    groups: [...document.querySelectorAll('.section-label')].map(x => x.textContent),
    hasForgetAll: /Forget everything/.test(document.body.textContent),
  }));
  ok('it is a screen of its own, like the note library', panel.screen === 'memory');
  ok('every memory is shown', panel.cards === 3, panel.cards + ' cards');
  ok('they are grouped by kind', panel.groups.length === 3, panel.groups.join(' | '));
  ok('there is a way to forget everything', panel.hasForgetAll);

  const before = await page.evaluate(() => {
    window.confirm = () => true;
    const n = Memory.count();
    document.querySelector('.ref-card .chip').click();
    return n;
  });
  await page.waitForFunction(() => document.querySelectorAll('.ref-card').length === 2, null, { timeout: 5000 })
    .catch(() => {});
  const deleted = await page.evaluate(() => ({
    after: Memory.count(), stillOnScreen: document.querySelectorAll('.ref-card').length }));
  ok('Delete removes one and re-renders', deleted.after === before - 1 && deleted.stillOnScreen === 2,
     `${before} → ${deleted.after}, ${deleted.stillOnScreen} shown`);

  head('the session summariser');
  await page.evaluate(() => {
    Memory.clear();
    AI.provider = 'gemini'; AI_GROUNDED = false;
    S.sessionCorrect = 14; S.sessionTotal = 20;
    sessionSummarised = false;
  });
  gem.length = 0;
  await page.evaluate(() => summariseSession());
  await page.waitForTimeout(900);
  const summ = await page.evaluate(() => ({ n: Memory.count(),
    kinds: [...new Set(Memory.all().map(m => m.kind))],
    texts: Memory.all().map(m => m.text) }));
  /* oneShot goes to :generateContent, the streamed turns to
     :streamGenerateContent — so the URL is what tells them apart on this wire,
     where the old one carried a `stream` flag in the body. */
  const oneShot = gem.filter(g => /:generateContent/.test(g.url)).map(g => g.body);
  ok('exactly one non-streaming call was made', oneShot.length === 1, oneShot.length + ' call(s)');
  ok('it is small — this runs unasked, on a free tier',
     oneShot[0] && (oneShot[0].generationConfig || {}).maxOutputTokens <= 400,
     oneShot[0] && String((oneShot[0].generationConfig || {}).maxOutputTokens));
  ok('it carries no tools, so it cannot wander off', oneShot[0] && !oneShot[0].tools);
  ok('at most three memories are kept from one sitting', summ.n > 0 && summ.n <= 3, String(summ.n));
  ok('they are filed as session summaries', summ.kinds.length === 1 && summ.kinds[0] === 'session', summ.kinds.join(','));
  ok('list punctuation is stripped from the model output',
     summ.texts.every(t => !/^[-•*\d.]/.test(t)), JSON.stringify(summ.texts));

  /* Counted on the wire the summariser uses. This read the Mistral capture,
     which nothing has called since that provider was retired, so it was always
     empty and passed with the sessionSummarised guard deleted. "Exactly one
     non-streaming call was made", above, is what shows this capture sees a
     one-shot call at all. */
  gem.length = 0;
  await page.evaluate(() => summariseSession());
  await page.waitForTimeout(500);
  const again = gem.filter(g => /:generateContent/.test(g.url)).length;
  ok('it will not fire twice for one sitting', again === 0, again + ' more call(s)');

  const thin = await page.evaluate(async () => {
    Memory.clear();
    CHATS = {}; saveJSON(AI_CHAT, CHATS);
    S.sessionCorrect = 1; S.sessionTotal = 2; sessionSummarised = false;
    await summariseSession();
    return Memory.count();
  });
  ok('a two-question session is not worth an API call', thin === 0, String(thin));

  const survivesError = await page.evaluate(async () => {
    Memory.clear();
    S.sessionCorrect = 9; S.sessionTotal = 12; sessionSummarised = false;
    /* No key. In the single file nothing can host the call; served, no key
       means hosted, and the hosted route above answers as a lapsed sign-in
       does. Either way there is nothing to keep, which is all this measures.
       That the single file makes no call at all is held only by the console
       check at the end, and only on Chromium, which refuses a fetch of a
       file: URL and logs it. Other engines were not checked. */
    AI.gemini = { key: '', model: 'gemini-9.9-flash' };
    let threw = false;
    try { await summariseSession(); } catch (_) { threw = true; }
    AI.gemini = { key: 'AQ.test', model: 'gemini-9.9-flash' };
    return { threw, n: Memory.count() };
  });
  ok('a summariser that cannot run fails silently rather than breaking the screen',
     !survivesError.threw && survivesError.n === 0);

  head('backup round trip');
  const backup = await page.evaluate(() => {
    Memory.clear();
    Memory.add('Sits the boards in October.', 'fact');
    Memory.add('Mixes up constriction and restriction.', 'gap');
    const exported = { mem: Memory.all() };
    Memory.clear();
    const afterWipe = Memory.count();
    Memory.replaceAll(exported.mem);
    return { afterWipe, restored: Memory.count(), text: Memory.build() };
  });
  ok('memory is wiped by a clear, as expected', backup.afterWipe === 0);
  ok('and comes back from a backup', backup.restored === 2 && /boards in October/.test(backup.text));

  /* HOSTED, which is how the app is deployed. A served build with no key typed
     sends its Gemini calls through /api/apex/gemini/ (apexHosted, gemUrl), and
     the panel has opened straight into a conversation there since hosting
     arrived. The summariser's two guards, in summariseSession and oneShot,
     stopped at "no key" all the same, so in the default deployment it never
     kept a note; either guard alone turns both checks below red. A single
     file is never hosted, since file: has no server, so given one this serves
     the same build from disk on 127.0.0.1, a fresh origin each run; given a
     URL, the page is served already. The build and its sign-in probe manifest
     are served, and /api/apex/gemini/ never reaches this server: the route
     above answers it. A server of its own, not route.fulfill, which hands the
     browser the whole body in one message: the real build is 92 MB, and the
     page closed under it (the owner's full run died here, 45 checks in, while
     CI's 5 MB build passed). Last, because it leaves the page on that origin. */
  head('hosted: no key typed, and the sitting is still summarised');
  let hostServer = null;
  if (!/^https?:\/\//.test(target)) {
    const built = path.resolve(target);
    hostServer = http.createServer((req, res) => {
      // Match a signed-in deployment: the new cache-bypassing session probe
      // needs the same manifest endpoint as the PWA. It is not a relay call.
      if (req.url.split('?')[0] === '/manifest.webmanifest') {
        res.writeHead(200, { 'content-type': 'application/manifest+json' });
        res.end(JSON.stringify({ name: 'Systole', start_url: './' })); return;
      }
      // Chromium may ask for its default icon on this fresh HTTP origin.
      // This fixture serves only the app; give the optional icon an empty response.
      if (req.url.split('?')[0] === '/favicon.ico') { res.writeHead(204); res.end(); return; }
      if (req.url.split('?')[0] !== '/systole.html') { res.writeHead(404); res.end(); return; }
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      fs.createReadStream(built).pipe(res);
    });
    await new Promise(r => hostServer.listen(0, '127.0.0.1', r));
    await page.goto(`http://127.0.0.1:${hostServer.address().port}/systole.html`, { waitUntil: 'load', timeout: 200000 });
    await booted(page);
  }
  /* But a summary is a call nobody asked for, so hosted it waits until this
     site's relay has answered one that was asked for. Served with no Worker
     behind it (scripts/serve.js on a LAN, docs/IPAD.md) the relay is a 404,
     which every sitting would otherwise send and the browser log. This origin
     is fresh, so nothing has answered here yet; and Access's sign-in page, all
     a lapsed session gets, is not the relay answering. */
  hosted.length = 0; gem.length = 0; hostedAnswers = false;
  const unasked = await page.evaluate(async () => {
    Memory.clear();
    AI.provider = 'gemini';
    AI.gemini = { key: '', model: 'gemini-9.9-flash' };
    const listed = await geminiModels('');
    S.sessionCorrect = 14; S.sessionTotal = 20; sessionSummarised = false;
    await summariseSession();
    return { lapsed: listed.error === APEX_LAPSED, known: relayKnown(), n: Memory.count() };
  });
  const sentBefore = hosted.filter(h => /\/api\/apex\/gemini\/generate\?/.test(h.url)).length;
  ok('(so far the relay has sent only Access\'s sign-in page, to a models call)',
     unasked.lapsed && hosted.length === 1, `${hosted.length} relay calls, lapsed ${unasked.lapsed}`);
  ok('which is not the relay answering, so the sitting\'s summary is not sent',
     !unasked.known && sentBefore === 0 && unasked.n === 0, JSON.stringify(Object.assign({ sentBefore }, unasked)));

  hostedAnswers = true;
  const marked = await page.evaluate(async () => { await geminiModels(''); return relayKnown(); });
  ok('(a models call the fellow makes is answered by the relay)', marked === true);
  hosted.length = 0; gem.length = 0;
  const hostedRun = await page.evaluate(async () => {
    Memory.clear();
    S.sessionCorrect = 14; S.sessionTotal = 20; sessionSummarised = false;
    const wasHosted = apexHosted();
    await summariseSession();
    return { wasHosted, n: Memory.count() };
  });
  hostedAnswers = false;
  const viaSite = hosted.filter(h => h.method === 'POST' && /\/api\/apex\/gemini\/generate\?/.test(h.url));
  ok('its one call goes through this site', viaSite.length === 1,
     `${viaSite.length} to /api/apex/gemini/generate, ${gem.length} to Google, apexHosted() ${hostedRun.wasHosted}`);
  ok('and what comes back is kept', hostedRun.n > 0, hostedRun.n + ' kept');

  head('regression');
  ok('no console or page errors across the whole run', errors.length === 0, errors.slice(0, 3).join(' | '));

  if (hostServer) hostServer.close();
  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
