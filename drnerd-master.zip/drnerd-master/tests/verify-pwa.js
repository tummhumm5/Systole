#!/usr/bin/env node
/*
 * Stage 1 checks — did splitting content from code actually buy what it was
 * supposed to buy?
 *
 *   node scripts/serve.js 8123 &
 *   NODE_PATH=$(npm root -g) node tests/verify-pwa.js http://localhost:8123/index.html [single-file.html]
 *
 * Pass the independent single-file build to verify content completeness and
 * measure heap/shell comparisons. Synthetic URL-only runs regenerate their
 * expectations from the fixture generator; other runs require that source.
 *
 * The claims under test are the three Stage 1 was justified by: the shell is
 * small, figures are fetched on demand instead of all held in memory, and the
 * thing works offline once installed.
 */
'use strict';
const path = require('path');
const fs = require('fs');
const { splitBank, readStaging } = require('./_olderbank.js');
const { launch, heapUsedBytes, engineName } = require('./_engine');
const { onDeath, watch } = require('./_deathnote.js');
const { booted, resolved, settled } = require('./_render.js');
const SYN = require('../scripts/synthetic-export.js');
const { originTransport } = require('./_origintransport.js');

// A retry navigation can temporarily have no body. That is not a failed
// mismatch detector: keep polling until the rendered message can be read.
function mixedPairNotice() {
  return !!document.body && /updated while it was opening/i.test(document.body.innerText || '');
}

const target = process.argv[2];
const baseline = process.argv[3];
if (!target || !/^https?:\/\//.test(target)) {
  console.error('usage: node tests/verify-pwa.js <http url> [single-file.html]');
  process.exit(1);
}
const ORIGIN = new URL(target).origin;
/* Expected counts come from a separate input, never from the bank under test
   or its extraction manifest: the same dropped data could corrupt both. */
const sourceBank = baseline ? JSON.parse(fs.readFileSync(baseline, 'utf8').match(/const ALL_Q=(\[[\s\S]*?\]);\n/)[1]) : null;
let expectedFigures;

let passed = 0, failed = 0, unmeasured = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
/* A THIRD OUTCOME, FOR CLAIMS THIS ENGINE CANNOT WEIGH. The heap section needs
   a heap profiler, which only Chromium has. Failing it on WebKit would call
   the app broken over a missing instrument; passing it would report a budget
   nobody checked. Both are lies, and the second is the worse one because it
   reads as coverage. So it is neither — printed, counted, and named in the
   summary, where a shrinking check count is visible rather than silent. */
const unmeasurable = (label, why) => {
  unmeasured++;
  console.log('  ----  ' + label + '  → not measurable here: ' + why);
};

/* Both sources are independent of extraction. A URL-only private run cannot
   certify completeness without an independent input, so refuse that claim. */
const expectedBank = async synthetic => {
  let counts, from;
  if (sourceBank) {
    counts = { questions: sourceBank.length, figures: sourceBank.reduce((n,q)=>n+(q.img||0),0) };
    from = 'the independent single-file source';
  } else if (synthetic) {
    const { bank, imgs } = SYN.syntheticBank();
    counts = { questions: bank.length, figures: Object.values(imgs).reduce((n,images)=>n+images.length,0) };
    from = 'the independent synthetic generator';
  } else { throw new Error('Content completeness needs the independent single-file source as the second argument.'); }
  return { synthetic, questions: counts.questions, figures: counts.figures,
    from };
};
/* The figure's own type, from its name: the extractor writes .webp, .png and
   .jpg alike, and the AI path must send each as what it is. */
const MIME = { webp: 'image/webp', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg' };
const mimeOf = name => MIME[String(name).split('.').pop().toLowerCase()] || null;
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };
const kb = b => (b / 1024).toFixed(0) + ' KB';
const mb = b => (b / 1048576).toFixed(1) + ' MB';

async function heapAfterBoot(page, url) {
  await page.goto(url, { waitUntil: 'load', timeout: 200000 });
  await booted(page);
  await page.waitForTimeout(2500);
  /* null where the engine cannot measure a heap, NOT zero. Reading
     performance.memory directly gave `undefined` on WebKit, which became 0,
     which is under every budget — so the check reported green on the one
     engine where it had measured nothing at all. */
  return heapUsedBytes(page);
}

(async () => {
  const BANK = await expectedBank((await (await fetch(ORIGIN + '/content/questions.json')).text()).includes(SYN.MARK));
  console.log(`  bank: ${BANK.synthetic ? 'synthetic' : 'not synthetic'} — expecting ${BANK.questions} questions, ${BANK.figures} figures (${BANK.from})`);
  const browser = await launch({ args: ['--enable-precise-memory-info'] });
  /* Twelve pages across nine contexts, and the ones that matter most when this
     suite dies are the offline and update sections — where "Target page,
     context or browser has been closed" is exactly what a deliberate close
     and a crash both look like. Each page is tagged with the section that
     opened it, because "the page closed" twelve times over says nothing. See
     tests/_deathnote.js. */
  const errors = [], events = [];
  onDeath(() => ({ section, checks: passed + failed, errors,
                   events: events.length ? events.join(', ') : 'none' }));

  head('the shell no longer carries the content');
  {
    const shellHtml = await (await fetch(target)).text();
    const appJs = await (await fetch(ORIGIN + '/app.js')).text();
    ok('no inline question bank in the document', !shellHtml.includes('const ALL_Q=['));
    ok('no inline figure blob in the document', !shellHtml.includes('const IMGS={'));
    ok('no base64 image payload anywhere in the shell',
       !/data:image\/(webp|png|jpeg);base64,[A-Za-z0-9+/]{500}/.test(shellHtml + appJs));
    /* The four woff2 faces are inlined in the single-file build, where one
       file that works offline cannot reference a sibling. Here they are their
       own immutable, separately-cacheable files: 250 KB of base64 the browser
       no longer parses before it can apply a rule. */
    ok('no base64 font payload in the shell either',
       !/data:font\/woff2;base64,/.test(shellHtml + appJs));
    const faces = [...shellHtml.matchAll(/@font-face\{[^}]*src:url\((fonts\/[^)]+)\)/g)].map(m => m[1]);
    ok('every face points at a file of its own', faces.length === 4, faces.join(', '));
    const served = await Promise.all(faces.map(async f => {
      const r = await fetch(new URL(f, target).href);
      return r.ok && +r.headers.get('content-length') > 5000;
    }));
    ok('and every one of those files is actually served', served.every(Boolean),
       `${served.filter(Boolean).length}/${faces.length}`);
    const shellBytes = Buffer.byteLength(shellHtml) + Buffer.byteLength(appJs);
    /* WHAT THIS BUDGET NOW MEASURES, AND WHY IT CHANGED.

       For most of this project the cap was on uncompressed bytes: 800 KB to
       catch a megabyte of inlined base64 heart scan, then 640 once the fonts
       came out, then 680, then 700. Each raise bought 3-6% of headroom, so
       each one bound again within a handful of changes — and the way changes
       kept paying their way was by deleting their own comments, twice down to
       a margin under a hundred bytes. That is not a budget working. That is a
       budget being satisfied by removing the documentation this codebase is
       largely made of, which is the wrong variable to optimise.

       The deeper problem is that nobody downloads uncompressed bytes. The
       last raise left 4.1 KB of margin on 700 KB — a tripwire, not a budget —
       while the figure a device actually fetches was 225 KB and had never
       been measured. Comments are close to free once compressed, so the cap
       was taxing the one thing it should not have.

       So it measures what is transferred. Gzip at a pinned level rather than
       whatever a server negotiates: it is deterministic, it does not move
       when a CDN changes its settings, and it is an honest UPPER BOUND —
       Cloudflare serves brotli to anything that will take it, which is
       186 KB against gzip's 225 KB here. A budget that binds on gzip has
       already been cleared for the compression the device really gets.

       The cap is 280 KB against today's real 225 KB. That is 24% of headroom,
       chosen against the history above rather than as a round number: 3-6%
       is what produced four raises in as many weeks. 55 KB of gzipped
       headroom is on the order of 165 KB of source — room for several real
       features, and far more than the whole adoption plan asks for.

       ONE PREMISE ABOVE WAS WRONG, AND THE BUDGET IS UNCHANGED. "Comments are
       close to free once compressed" was never measured. It was at 7947642:
       comments were 76 of the 149 KB src/'s modules gzip to, and the shell had
       reached 287 KB with no change to blame — each feature paid its way, and
       its documentation rode along into every download. build-pwa now ships
       src/'s modules without their comments (scripts/strip-comments.js,
       guarded by tests/verify-stripcomments-pure.js); the source and the
       single-file build keep every one. So the conclusion stands — do not
       delete comments to fit — for a different reason: they no longer ship.

       The uncompressed figure is still reported, because it is not
       meaningless — it drives parse and compile time on the device. It is
       simply not the thing a download budget should be denominated in. */
    const gzip = buf => require('zlib').gzipSync(buf, { level: 6 }).length;
    const wireBytes = gzip(Buffer.from(shellHtml)) + gzip(Buffer.from(appJs));
    // Owner-approved Observatory allowance: 288 KiB, up 2.86% from 280 KiB.
    // Measured before redundant markup removal: 287,785 bytes. This budget
    // concerns transfer only; rendering and accessibility checks stay separate.
    ok('the shell transfers under 288 KB', wireBytes < 288 * 1024,
       `${kb(wireBytes)} gzipped, from ${kb(shellBytes)} on disk`);

  }

  if (baseline) {
    const gzip = b => require('zlib').gzipSync(b).length;
    const before = gzip(fs.readFileSync(baseline));
    const wire = gzip(Buffer.from(await (await fetch(target)).text())) + gzip(Buffer.from(await (await fetch(ORIGIN + '/app.js')).text()));
    ok('compressed shell transfers fewer bytes than the source', wire < before);
  }

  head('the library arrives late, and the home screen notices');
  /* The single-file build has REF inline; here it is fetched, so the first
     paint happens without it. That silently cost the home screen its pearl —
     the card was absent, and nothing asked for it again. */
  {
  const page = watch(await browser.newPage({ viewport: { width: 900, height: 1000 } }), events, 'late library', errors);
  await page.goto(target, { waitUntil: 'load', timeout: 200000 });
  await booted(page);
  const late = await page.evaluate(() => new Promise(r => setTimeout(() => r({
    refs: typeof REF !== 'undefined' ? REF.length : -1,
    pearls: typeof pearlAll === 'function' ? pearlAll().length : -1,
    card: !!document.getElementById('pearlCard'),
    rungsOrProse: document.querySelectorAll('.pearl-step').length ||
                  (document.querySelector('.pearl-body') ? 1 : 0),
    notesDoor: [...document.querySelectorAll('.door')]
      .map(d => d.textContent.replace(/\s+/g, ' ').trim())
      .find(t => /^Notes/.test(t)) || '',
  }), 2500)));
  ok('the reference seed is fetched and applied', late.refs > 100, String(late.refs));
  ok('and yields pearls', late.pearls > 40, String(late.pearls));
  ok('the pearl card is repainted onto the home screen', late.card);
  ok('with its sentence set', late.rungsOrProse > 0, String(late.rungsOrProse));
  ok('and the Notes door counts what arrived', /\d+ references/.test(late.notesDoor), late.notesDoor);
  await page.close();
  }

  head('the scanned heart is on the home screen, with its credit');
  /* "Realistic Human Heart" by neshallads is CC BY 4.0: the credit is the
     condition of using it, so the scan on screen without the credit is a
     licensing failure, not a cosmetic one. The split build ships it beside the
     app and the hero loads it after the first paint (heroLoadScan). */
  {
    const sw = await (await fetch(new URL('sw.js', target).href)).text();
    const files = ['heart-scan.json', 'heart-scan.bin', 'base.webp', 'normal.webp', 'mr.webp'];
    ok('the service worker keeps the scan for offline use', files.every(f => sw.includes(`'heart-scan/${f}'`) || sw.includes(`"heart-scan/${f}"`)),
       files.filter(f => !sw.includes(`heart-scan/${f}`)).join(', ') || 'all five');
    const man = await (await fetch(new URL('heart-scan/heart-scan.json', target).href)).json().catch(() => null);
    ok('its manifest is served and names a CC BY licence and an author',
       !!man && /CC-BY/i.test(man.credit && man.credit.license || '') && !!(man.credit && man.credit.author),
       man ? `${man.credit && man.credit.author}; ${man.credit && man.credit.license}` : 'not served');
    const page = watch(await browser.newPage({ viewport: { width: 1180, height: 820 } }), events, 'scanned heart', errors);
    await page.goto(target, { waitUntil: 'load', timeout: 200000 });
    await booted(page);
    // Home opens with the real 3D view, including its model menu.
    /* Polled, not waited for: whether the scan arrives is the claim. */
    const model = await page.evaluate(() => new Promise(r => {
      const t0 = Date.now();
      (function poll() {
        const m = typeof heroHeart3d !== 'undefined' && heroHeart3d ? heroHeart3d.model() : 'no heart';
        if (m === 'scan' || Date.now() - t0 > 45000) return r(m);
        setTimeout(poll, 250);
      })();
    }));
    ok('the hero draws the scan', model === 'scan', model);
    /* The credit is one tap away: an info button among the hero's tools,
       shown while the scan is drawn, which opens the full credit in place. */
    const inHero = sel => {
      const el = document.querySelector(sel);
      if (!el) return false;
      const b = el.getBoundingClientRect(), hero = document.querySelector('.hero-live').getBoundingClientRect();
      const cs = getComputedStyle(el);
      return !el.hidden && b.width > 0 && b.height > 0 && cs.visibility !== 'hidden' && +cs.opacity > 0.5 &&
        b.top >= hero.top && b.bottom <= hero.bottom && b.left >= hero.left && b.right <= hero.right;
    };
    /* Round five: the credit is in the heart's menu, which a tap on the heart opens. */
    const button = await page.evaluate(`(() => { document.getElementById('heroHeartBtn').click(); return (${inHero})('#heroCreditBtn'); })()`);
    ok('a tap on the heart opens its menu, and the credit is in it, inside the hero, while the scan is drawn', button);
    const credit = await page.evaluate(`(() => {
      document.getElementById('heroCreditBtn').click();
      const el = document.getElementById('heroScanCredit');
      return { text: el.textContent.replace(/\\s+/g, ' ').trim(), seen: (${inHero})('#heroScanCredit'),
               expanded: document.getElementById('heroCreditBtn').getAttribute('aria-expanded'),
               links: [...el.querySelectorAll('a')].map(a => a.getAttribute('href')) };
    })()`);
    ok('pressing it shows the credit, inside the hero', credit.seen && credit.expanded === 'true', credit.text);
    ok('it names the work, the author and the licence',
       /Realistic Human Heart/.test(credit.text) && /neshallads/.test(credit.text) && /CC BY 4\.0/.test(credit.text));
    ok('and links the source and the licence', !!man && credit.links.includes(man.credit.source) &&
       credit.links.includes('https://creativecommons.org/licenses/by/4.0/'), credit.links.join(' '));
    const back = await page.evaluate(() => {
      heroHeart3d.setModel('procedural'); paintHeroScanCredit();
      return { credit: document.getElementById('heroScanCredit').hidden, button: document.getElementById('heroCreditBtn').hidden };
    });
    ok('the credit and its button go when the scan does', back.credit === true && back.button === true, JSON.stringify(back));
    await page.close();
  }

  head('the faces the first layout uses are preloaded, and fetched once');
  /* build-pwa preloads the upright faces so the first layout has them, rather
     than asking the operating system for fallbacks and laying out again when
     they land. A preload that does not match the font request (no crossorigin,
     wrong type) is worse than none: the face downloads twice. So this counts
     the requests, and asks the browser how each one was started. */
  {
  const page = watch(await browser.newPage({ viewport: { width: 900, height: 1000 } }), events, 'font preload', errors);
  const asked = {};
  page.on('request', r => { const m = /\/fonts\/([^/?#]+\.woff2)/.exec(r.url()); if (m) asked[m[1]] = (asked[m[1]] || 0) + 1; });
  await page.goto(target, { waitUntil: 'load', timeout: 200000 });
  await booted(page);
  const how = await page.evaluate(() => performance.getEntriesByType('resource')
    .filter(e => /\/fonts\/[^/]+\.woff2/.test(e.name))
    .map(e => [e.name.split('/fonts/')[1], e.initiatorType]));
  const UPRIGHT = ['dm-sans.woff2', 'dm-serif-display.woff2', 'jetbrains-mono.woff2'];
  ok('each upright face is requested exactly once', UPRIGHT.every(n => asked[n] === 1), JSON.stringify(asked));
  ok('and the browser started each from the preload link', UPRIGHT.every(n => how.some(([f, i]) => f === n && i === 'link')),
     JSON.stringify(how));
  await page.close();
  }

  head('the Worker ships with the site, and the site still serves');
  {
    const w = await (await fetch(new URL('_worker.js', target).href)).text();
    /* Pages ignores a functions/ directory on dashboard direct upload, which is
       how this is deployed. A _worker.js at the root IS honoured, so the Worker
       has to be a file in dist/ like everything else. */
    ok('_worker.js is in the upload', w.length > 500, `${w.length} bytes`);
    /* In advanced mode the Worker owns every request to the project. Without
       this line it does not break the API — it 404s the whole app. */
    ok('and it hands everything that is not the API back to the site',
       /env\.ASSETS\.fetch\(request\)/.test(w));
    ok('the API path is the only thing it intercepts',
       /pathname\.startsWith\('\/api\/apex\/'\)/.test(w));
    /* A secret in the bundle would defeat the entire exercise. */
    ok('no key is baked into it — it reads one from the environment',
       /env\.GEMINI_API_KEY/.test(w) && !/AIza[0-9A-Za-z_\-]{20}/.test(w) && !/AQ\.[0-9A-Za-z_\-]{20}/.test(w));
    const sw = await (await fetch(new URL('sw.js', target).href)).text();
    /* The model list is a GET, and a cached model list outlives the key that
       produced it. */
    ok('and the service worker never caches the API',
       /pathname\.startsWith\('\/api\/apex\/'\)\s*\)\s*return;/.test(sw.replace(/\s+/g, ' ')) ||
       /\/api\/apex\//.test(sw), 'bypass present');
  }

  head('a sign-in page is never written into a cache');
  {
    /* THE FAILURE THIS DEFENDS AGAINST. Cloudflare Access with a lapsed session
       answers 200 OK and an HTML sign-in page for any URL. res.ok is true. The
       service worker used to cache on res.ok alone, so one lapsed session while
       the shell was being refreshed in the background would write the login page
       into the precache AS app.js — permanently, on a device that then launches
       offline into a blank screen.

       The real sw.js is loaded and its keepable() run against fabricated
       responses. No browser: a service worker is a module with a fetch handler,
       the same shape verify-worker.js drives, and there is no way to make a
       local server return a Cloudflare login page anyway. */
    const swSrc = await (await fetch(new URL('sw.js', target).href)).text();
    const res = (ct, ok = true, type = 'basic') =>
      ({ ok, type, headers: { get: h => (h.toLowerCase() === 'content-type' ? ct : null) } });
    const req = u => ({ url: ORIGIN + u });
    let keepable;
    try {
      keepable = new Function('URL', swSrc.slice(swSrc.indexOf('function keepable')) + '\nreturn keepable;')(URL);
    } catch (err) { keepable = null; }
    ok('the worker has a keepable() gate at all', typeof keepable === 'function',
       typeof keepable);
    if (typeof keepable === 'function') {
      ok('a sign-in page is not cached as app.js',
         keepable(req('/app.js'), res('text/html; charset=utf-8')) === false);
      ok('nor as a figure',
         keepable(req('/content/figures/f001.webp'), res('text/html; charset=utf-8')) === false);
      ok('nor as questions.json',
         keepable(req('/content/questions.json'), res('text/html; charset=utf-8')) === false);
      ok('a figure that is not an image is not a figure',
         keepable(req('/content/figures/f001.webp'), res('application/json')) === false);
      ok('a real figure is kept',
         keepable(req('/content/figures/f001.webp'), res('image/webp')) === true);
      ok('real code is kept',
         keepable(req('/app.js'), res('text/javascript')) === true);
      ok('the document itself is still allowed to be HTML',
         keepable(req('/index.html'), res('text/html; charset=utf-8')) === true &&
         keepable(req('/'), res('text/html; charset=utf-8')) === true);
      ok('a font with no content-type at all is still kept — absence is not a login page',
         keepable(req('/fonts/dm-sans.woff2'), res(null)) === true);
      ok('an error is never cached', keepable(req('/app.js'), res('text/javascript', false)) === false);
      ok('and neither is an opaque cross-origin response',
         keepable(req('/app.js'), res('text/javascript', true, 'opaque')) === false);
    }
    /* Counting `if (keepable(...))` rather than every mention, because the
       function's own declaration matches the bare name too. */
    const calls = (swSrc.match(/if \(keepable\(req, res\)\)/g) || []).length;
    ok('both cache writes go through it, not through res.ok',
       !/if \(res\.ok\) c\.put/.test(swSrc) && calls === 2, calls + ' call sites');

    /* THE WRITE MUST OUTLIVE respondWith's OWN PROMISE. Once the function
       handling a fetch event returns its response, that promise settles, and
       nothing else is telling the browser this worker still has work
       in-flight — c.put() started but not yet finished is exactly the kind
       of work a terminated worker drops silently. iOS Safari evicts service
       workers more aggressively than desktop browsers, and this app is built
       for an iPad: a figure that renders once and is never actually
       persisted for offline use is a real, not theoretical, failure mode
       here. Both call sites — figures and the shell's background refresh —
       must wrap their cache write in e.waitUntil(), not call it bare. */
    const waitUntilWrites = (swSrc.match(/e\.waitUntil\(c\.put\(req, res\.clone\(\)\)\)/g) || []).length;
    ok('both cache writes are kept alive with e.waitUntil, not fired and forgotten',
       waitUntilWrites === 2, waitUntilWrites + ' of 2 wrapped');

    /* INSTALL IS THE PATH THAT MATTERED, and it was the one without the check.
       cache.addAll() stores whatever comes back, so a Cloudflare Access
       sign-in page — 200 OK, text/html, for any URL — became app.js in the
       precache permanently, and the device then launched offline into a blank
       screen. Exactly the failure the comment above it describes, on the one
       path it had not been applied to. */
    ok('install no longer trusts addAll with the critical shell',
       !/addAll\(PRECACHE\)/.test(swSrc));
    ok('and screens every precached response through keepable first',
       /keepable\(req, res\) \? res : null/.test(swSrc));
    ok('refusing the whole install rather than caching a sign-in page',
       /precache refused/.test(swSrc));

    /* Offline, a navigation that misses used to resolve to undefined —
       respondWith(undefined) is a dead page, which is "the app will not open"
       rather than "the app opens from cache". */
    ok('a shell lookup ignores the query string Access appends',
       (swSrc.match(/ignoreSearch: true/g) || []).length >= 2);
    ok('and a missed navigation falls back to the cached shell',
       /req\.mode === 'navigate'/.test(swSrc) && /c\.match\('index\.html'/.test(swSrc));
  }

  head('an update does not leave old code running against new content');
  {
    /* THE SKEW THIS DEFENDS AGAINST. sw.js calls skipWaiting on install and
       clients.claim on activate, so a new worker takes control of a page that
       is still running the app.js it parsed at launch — and then serves it new
       content. On an iPad a home-screen app is rarely killed, so that pairing
       can persist for weeks.

       It only became reachable when the shell and figure caches were versioned
       separately: before that sw.js was byte-identical across code changes and
       the browser never saw an update at all. */
    const shell = await (await fetch(target)).text();
    ok('the page listens for the worker taking over',
       /addEventListener\(\s*['"]controllerchange['"]/.test(shell), 'controllerchange handler');
    ok('and reloads when it does', /controllerchange[\s\S]{0,600}location\.reload\(\)/.test(shell));
    /* Two guards, and both matter. */
    ok('but not on the first install, when there was nothing stale to replace',
       /hadController/.test(shell) && /if\(!hadController\)/.test(shell.replace(/\s/g, '')),
       'first-install guard');
    ok('and never twice, so a reload cannot loop',
       /sessionStorage[\s\S]{0,200}swreloaded/.test(shell), 'one-shot guard');
    ok('the guard is per-tab storage, since a reload discards variables',
       /sessionStorage\.setItem\(\s*['"]accsap12\.swreloaded['"]/.test(shell));
  }

  head('an update reaches an installed app, without costing the figures');
  {
    const sw = await (await fetch(new URL('sw.js', target).href)).text();
    const contentV = (/const CONTENT_V\s*=\s*'([^']+)'/.exec(sw) || [])[1];
    const shellV = (/const SHELL_V\s*=\s*'([^']+)'/.exec(sw) || [])[1];
    /* Both cache names were keyed on content/manifest.json's sourceDigest,
       and with a content/ left over from an earlier extraction every change to
       the app's own code produced a byte-identical sw.js. The browser saw no
       new worker, never re-primed the shell cache, and an installed app went
       on serving old code. */
    ok('the shell is versioned by its own bytes', !!shellV && shellV !== contentV,
       `shell ${shellV}, content ${contentV}`);
    ok('the shell cache is keyed on the shell version',
       new RegExp(`SHELL\\s*=\\s*'accsap-shell-'\\s*\\+\\s*SHELL_V`).test(sw));
    /* And the content cache is NOT. Rekeying it on a code change would throw
       away the 408 figures the fellow pressed a button to download — 19 MB
       re-fetched because a stylesheet moved. It was called FIGS and held only
       /content/figures/; it is called CONTENT and holds all of /content/,
       because the two large JSON files were falling through to the shell.
       tests/verify-cachebuckets.js is where that routing is checked; here it
       is only the key that matters. This reads the name, not what CONTENT_V
       is made from: it passed while CONTENT_V was the whole build's digest.
       tests/verify-swupdate-pure.js builds twice and compares. */
    ok('but the content cache is keyed on CONTENT_V',
       new RegExp(`CONTENT\\s*=\\s*'accsap-content-'\\s*\\+\\s*CONTENT_V`).test(sw));
  }

  head('the split build evaluates no fetched code');
  {
    /* The splash animation used to be a Lottie player fetched as text and run
       with (0, eval) — the one place in the product where launching involved
       evaluating text pulled off the network. Beyond the injection surface,
       that is the construct that makes a meaningful Content-Security-Policy
       unadoptable later. The player is gone entirely now (the splash heart is
       a photograph), so the claim is simply that nothing brought eval back. */
    const idx = await (await fetch(ORIGIN + '/index.html')).text();
    ok('index.html contains no eval of fetched text', !/\(\s*0\s*,\s*eval\s*\)|\beval\s*\(/.test(idx),
       (idx.match(/.{0,40}eval.{0,40}/) || [''])[0]);
    const app = await (await fetch(ORIGIN + '/app.js')).text();
    ok('and app.js does not eval either', !/\(\s*0\s*,\s*eval\s*\)/.test(app));

    /* THE SPLASH HEART IS FETCHED, NOT INLINED — IN BOTH FILES. This replaces
       the old "the player is loaded as a script instead" check, and it guards
       a regression that already happened once: heroart-patch read the picture
       out of the splash markup, where at that point in the chain it was still a
       data: URI, so a second 57 KB base64 copy was ending up in app.js. Base64
       of an already-compressed WebP does not gzip, and the shell went from
       229 KB transferred to 276 against a 280 KB budget. Nothing visible would
       have broken — it would just have been slower, permanently. */
    const heartRef = (idx.match(/content\/splash-heart\/heart-([0-9a-f]{12})\.webp/) || [])[0];
    ok('the splash heart is referenced as a file, not inlined', !!heartRef, heartRef || 'no content/splash-heart/heart-<digest>.webp in index.html');
    const inlined = ((idx + app).match(/data:image\/webp;base64,/g) || []).length;
    ok('and neither the shell nor the app code carries a copy of it as base64',
       inlined === 0, `${inlined} inline WebP data: URI(s)`);
    const heart = heartRef ? await fetch(ORIGIN + '/' + heartRef) : { status: 'not requested' };
    ok('and that file is actually served', heart.status === 200, String(heart.status));
    /* NAMED BY ITS OWN BYTES. The content cache's version leaves this file out
       (build-pwa.js contentVersion), which is right only while a new picture
       is a new name: under a fixed one, a device would keep the old picture.
       So the name is held to a digest of what is served under it. */
    const heartBytes = heart.status === 200 ? Buffer.from(await heart.arrayBuffer()) : null;
    const heartDigest = heartBytes && require('crypto').createHash('sha256').update(heartBytes).digest('hex').slice(0, 12);
    ok('and its name is a digest of the bytes served under it, so a new picture is a new name',
       !!heartDigest && heartRef.indexOf('heart-' + heartDigest + '.webp') > 0, `${heartRef} / ${heartDigest}`);
  }

  head('content is served intact');
  {
    const qs = await (await fetch(ORIGIN + '/content/questions.json')).json();
    /* The export's part is held to the export's own totals; a merged older
       bank is held to the staging it came from — see tests/_olderbank.js. */
    const bank = splitBank(qs, q => (q.figs ? q.figs.length : 0), readStaging());
    const expected = BANK;
    expectedFigures = expected.figures;
    ok('every question from the independent source is present', Number.isInteger(expected.questions) && qs.length === expected.questions, String(qs.length));
    if (sourceBank) ok('question IDs and order match the independent source', qs.map(q=>q.id).join(',') === sourceBank.map(q=>q.id).join(','));
    const figs = qs.reduce((a, q) => a + (q.figs ? q.figs.length : 0), 0);
    ok('every figure from the independent source is referenced', Number.isInteger(expected.figures) && figs === expected.figures, String(figs));
    ok('and an older bank, if merged, is exactly its staging', bank.ok, bank.why);
    const declared = qs.reduce((a, q) => a + (q.img || 0), 0);
    ok('q.img and the extracted figure lists agree', declared === figs, `${declared} vs ${figs}`);

    /* THE SIX KEYS THE EXPORT GETS WRONG MUST BE RIGHT IN *THIS* BUILD TOO.
       scripts/answer-keys.js corrects them into the ALL_Q embedded in the
       single-file build; this build serves content/questions.json instead, and
       for a long time build-pwa copied that from the licensed export
       byte-for-byte — so the iPad shipped the export's own wrong keys while the
       single-file build had them right. A wrong key fails silently in the worst
       possible way: it marks a correct answer wrong and teaches the distractor.
       Asserted here against the shipped JSON, on the ids and letters from
       scripts/answer-keys.js's own table. */
    const KEYS = [['CON_16', 'C'], ['MIS_25', 'D'], ['PER_9', 'A'],
                  ['SYS_9', 'A'], ['SYS_26', 'C'], ['SYS_44', 'E']];
    const byId = new Map(qs.map(q => [q.id, q]));
    const wrong = KEYS.filter(([id, want]) => {
      const q = byId.get(id);
      return !q || 'ABCDEFGH'[q.ci] !== want;
    });
    ok('the six corrected answer keys are corrected in the served bank too',
       wrong.length === 0,
       wrong.map(([id, want]) => `${id} wants ${want}, has ${'ABCDEFGH'[(byId.get(id) || {}).ci]}`).join('; '));

    /* THE RULE, not the instance. A question with `imgopt` is asking the fellow
       to choose between lettered panels; with no figure shipped, there are no
       panels to choose between and it cannot be answered at all. Such a
       question must carry `bad` (kept out of the pool) or `flag` (shown with a
       notice saying why). COR_108 had one; COR_89 had neither and sat live in
       the pool offering five patterns nobody could see. This is the check that
       would have caught it, and catches the next one. */
    const unanswerable = qs.filter(q => q.imgopt && !(q.figs || []).length && !q.bad && !q.flag);
    ok('no question asks about a figure it does not ship, untriaged',
       unanswerable.length === 0, unanswerable.map(q => q.id).join(', '));
    const man = await (await fetch(ORIGIN + '/manifest.webmanifest')).json();
    ok('web app manifest is installable-shaped',
       man.display === 'standalone' && Array.isArray(man.icons) && man.icons.length >= 2 && !!man.start_url,
       `${man.display}, ${man.icons.length} icons`);
  }

  head('figures load by URL, on demand — not all of them, up front');
  {
    const page = watch(await browser.newPage({ viewport: { width: 900, height: 1000 } }), events, 'figures on demand', errors);
    const figReqs = [];
    page.on('request', r => { if (r.url().includes('/content/figures/')) figReqs.push(r.url()); });
    await page.goto(target, { waitUntil: 'load', timeout: 200000 });
    await booted(page);
    await page.waitForTimeout(1200);
    ok('home screen fetches no figures at all', figReqs.length === 0, String(figReqs.length));

    /* Go to a question that actually has figures and confirm one renders. */
    const shown = await page.evaluate(async () => {
      const q = ALL_Q.find(x => x.img > 0 && !x.bad);
      (S.resume = {}, startQuiz)(q.ch);
      S.questions = [q]; S.qIdx = 0; render();
      await new Promise(r => setTimeout(r, 1200));
      const img = document.querySelector('.fig-img');
      return {
        id: q.id, want: q.img,
        src: img ? img.getAttribute('src') : null,
        complete: img ? (img.complete && img.naturalWidth > 0) : false,
        naturalWidth: img ? img.naturalWidth : 0,
      };
    });
    ok('the figure is referenced by URL, not a data: URI',
       !!shown.src && shown.src.startsWith('content/figures/'), shown.src);
    ok('and it actually decoded', shown.complete && shown.naturalWidth > 0,
       `${shown.id} ${shown.naturalWidth}px`);
    ok('only that question\'s figures were fetched',
       figReqs.length > 0 && figReqs.length <= 5, `${figReqs.length} request(s)`);
    await page.close();
  }

  head('the AI path still gets real base64, resolved at send time');
  {
    const page = watch(await browser.newPage({ viewport: { width: 900, height: 1000 } }), events, 'AI base64', errors);
    await page.goto(target, { waitUntil: 'load', timeout: 200000 });
    await booted(page);
    /* Held to the figure file itself, not to one export's format: each data
       URL and image block must carry the MIME type its file's name says and
       exactly the bytes the server serves for it. */
    const resolved = await page.evaluate(async () => {
      const q = ALL_Q.find(x => x.img > 0 && !x.bad);
      const urls = await figuresAsDataUrls(q);
      if (!urls) return { none: true };
      const blocks = Vision.figureBlocks(q, urls).filter(b => b.type === 'image');
      const b64 = async name => { const u = new Uint8Array(await (await fetch('content/figures/' + name)).arrayBuffer());
        let s = ''; for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192)); return btoa(s); };
      const files = [];
      for (const name of q.figs || []) files.push({ name, data: await b64(name) });
      return { count: urls.length, want: q.img, files,
               urls: urls.map(u => ({ type: u.slice(5, u.indexOf(';')), data: u.slice(u.indexOf(',') + 1) })),
               blocks: blocks.map(b => ({ kind: b.source.type, type: b.source.media_type, data: b.source.data })) };
    });
    const files = resolved.files || [];
    const asFile = (x, i) => !!x && !!files[i] && x.type === mimeOf(files[i].name) && x.data === files[i].data && x.data.length > 0;
    ok('every figure resolves to a base64 data URL of its own type and bytes',
       resolved.count === resolved.want && resolved.count === files.length && files.length > 0 && resolved.urls.every(asFile),
       `${resolved.count}/${resolved.want} · ${files.map(f => f.name).join(', ')} · ${(resolved.urls || []).map(u => u.type).join(', ')}`);
    ok('and produces a wire-shaped image block for each, the same type and bytes',
       !!resolved.blocks && resolved.blocks.length === files.length &&
       resolved.blocks.every((b, i) => b.kind === 'base64' && !b.data.startsWith('data:') && asFile(b, i)),
       (resolved.blocks || []).map(b => `${b.kind} ${b.type} ${b.data.length}`).join(' · '));
    await page.close();
  }

  head('offline, once installed');
  {
    const transport = await originTransport(target);
    const ctx = await browser.newContext({ viewport: { width: 900, height: 1000 } });
    const page = watch(await ctx.newPage(), events, 'offline', errors);
    await page.goto(transport.url, { waitUntil: 'load', timeout: 200000 });
    await booted(page);
    const swReady = await page.evaluate(() =>
      navigator.serviceWorker.ready.then(r => !!r.active).catch(() => false));
    ok('service worker registers and activates', swReady === true);

    /* Open a question with figures so one lands in the runtime cache. */
    await page.waitForFunction(() => !!navigator.serviceWorker.controller, null, { timeout: 30000 });
    const figId = await page.evaluate(() => {
      const q = ALL_Q.find(x => x.img > 0 && !x.bad);
      (S.resume = {}, startQuiz)(q.ch); S.questions = [q]; S.qIdx = 0; render();
      return q.id;
    });
    /* The fixture must have reached Cache Storage before the outage. A
       fixed sleep neither proves that nor accounts for a slow decoder. */
    const cached = await resolved(page, async () => {
      const im = document.querySelector('.fig-img');
      return !!im && im.complete && im.naturalWidth > 0 && !!(await caches.match(im.src));
    }, null, { timeout: 30000 }).catch(() => false);
    ok('the selected figure decoded and reached Cache Storage before the outage', cached === true);
    transport.cut();
    ok('the origin transport is actually unavailable', await transport.unavailable());
    await page.reload({ waitUntil: 'load', timeout: 120000 });
    const offline = await page.evaluate(() =>
      new Promise(res => {
        const t0 = Date.now();
        (function tick() {
          if (typeof S !== 'undefined' && document.querySelector('.hero-h1')) return res({ booted: true });
          if (Date.now() - t0 > 60000) return res({ booted: false });
          requestAnimationFrame(tick);
        })();
      }));
    ok('the app boots with the network cut off', offline.booted === true, JSON.stringify(offline));

    await page.evaluate(id => {
      const q = ALL_Q.find(x => x.id === id);
      (S.resume = {}, startQuiz)(q.ch); S.questions = [q]; S.qIdx = 0; render();
    }, figId);
    const decoded = await page.waitForFunction(() => {
      const img = document.querySelector('.fig-img');
      return !!img && img.complete && img.naturalWidth > 0;
    }, null, { timeout: 30000 }).then(()=>true,()=>false);
    ok('a figure seen before is still there offline', decoded);
    // First visit to Echo happens AFTER the outage: this measures installation
    // caching, rather than images a previous visit happened to cache.
    await page.evaluate(() => { ECHO.tab = 'visual'; goEcho(); });
    await settled(page, () => !!document.querySelector('.echo-panel'));
    for (const image of await page.locator('.echo-teaching-image').all()) {
      await image.scrollIntoViewIfNeeded();
      await image.evaluate(i => i.decode().catch(() => null));
    }
    ok('public echo teaching images decode on their first visit offline', await page.evaluate(() => {
      const images = Array.from(document.querySelectorAll('.echo-teaching-image'));
      return images.length === 2 && images.every(i => i.naturalWidth > 100 && /\/echo\/echo-/.test(i.src));
    }));
    /* The Lab's modules leave app.js for vendor/ (build-pwa, 3.746) and load when the Lab is first drawn. First drawn
       here, after the outage: the file must come from the precache, and the Lab must draw from it. */
    await page.evaluate(() => goPractice());
    const labDrawn = await settled(page, () => typeof LabUI !== 'undefined' && !!document.querySelector('#plabRoot .plab-card'),
      { timeout: 30000 }).then(() => true, () => false);
    ok('the Lab, out of app.js, draws on its first visit offline', labDrawn === true && await page.evaluate(() =>
      typeof window.LAB_SRC === 'string' && !!document.querySelector('script[src="' + window.LAB_SRC + '"]')));
    transport.resume();
    await ctx.close();
    transport.close();
  }

  head('one press puts the whole bank on the device');
  /* The reason this exists: served from a laptop over Tailscale, opened on an
     iPad, then studied with the laptop shut. Under that pattern every figure
     not already met is a broken image, discovered at the worst moment. */
  {
    const transport = await originTransport(target);
    const ctx = await browser.newContext({ viewport: { width: 430, height: 932 } });
    const page = watch(await ctx.newPage(), events, 'download the rest', errors);
    let figReqs = 0;
    page.on('request', r => { if (r.url().includes('/content/figures/')) figReqs++; });
    await page.goto(transport.url, { waitUntil: 'load', timeout: 200000 });
    await booted(page);
    await page.evaluate(() => navigator.serviceWorker.ready);
    /* IT LIVES ON PROGRESS NOW, not on the home screen. The landscape home grid
       gives its whole one-screen budget to four named areas and appends
       everything else outside it, so this card was 114.5px of guaranteed
       overflow on an 11-inch iPad held sideways — see chain step 85. The
       survey moved with it, so nothing is counted until Progress is open. */
    const onHome = await page.evaluate(() => !!document.getElementById('offlineCard'));
    ok('the home screen no longer carries the card', onHome === false);
    await page.evaluate(() => goStats());
    await page.waitForFunction(() => typeof offlineJob !== 'undefined' && offlineJob.counted, null,
                               { timeout: 60000 });

    const before = await page.evaluate(() => {
      const c = document.getElementById('offlineCard');
      return c ? { total: offlineJob.total, have: offlineJob.have,
                   val: c.querySelector('.off-val').textContent,
                   btn: c.querySelector('.off-btn').textContent } : null;
    });
    ok('the card is on the Progress screen of the split build', !!before);
    ok('and knows how many figures the independent source has', before && before.total === expectedFigures, String(before && before.total));
    /* Surveying must not BE a download: caches.match asks the question without
       fetching, and 408 fetches on every home screen would be the opposite of
       the feature. */
    ok('surveying what is here costs no requests', figReqs === 0, String(figReqs));

    const t0 = Date.now();
    await page.evaluate(() => offlineDownload());
    await page.waitForFunction(() => !offlineJob.busy, null, { timeout: 300000 });
    const after = await page.evaluate(() => {
      const c = document.getElementById('offlineCard');
      return { have: offlineJob.have, total: offlineJob.total,
               val: c.querySelector('.off-val').textContent,
               btn: c.querySelector('.off-btn').textContent,
               disabled: c.querySelector('.off-btn').disabled,
               allHere: c.classList.contains('all-here'),
               width: c.querySelector('.off-fill').style.width };
    });
    ok('the download fetches every figure', after.have === after.total,
       `${after.have}/${after.total} in ${((Date.now() - t0) / 1000).toFixed(0)}s`);
    ok('and the card says so rather than still offering', /^all \d+ figures/.test(after.val) &&
       after.disabled && after.allHere && after.width === '100%', after.val + ' · ' + after.btn);

    /* It does not own a cache: it only requests, and the service worker's own
       fetch handler does the storing. So a reload must find them all through
       exactly the same lookup a figure met the ordinary way goes through. */
    figReqs = 0;
    await page.reload({ waitUntil: 'load', timeout: 200000 });
    /* A reload lands on home, and the survey now runs from Progress. */
    await page.waitForFunction(() => typeof goStats === 'function', null, { timeout: 120000 });
    await page.evaluate(() => goStats());
    await page.waitForFunction(() => typeof offlineJob !== 'undefined' && offlineJob.counted, null,
                               { timeout: 60000 });
    const reloaded = await page.evaluate(() => ({ have: offlineJob.have, total: offlineJob.total }));
    ok('a reload finds them all still there', reloaded.have === reloaded.total,
       `${reloaded.have}/${reloaded.total}`);
    ok('and re-fetches none of them', figReqs === 0, String(figReqs));

    /* AN AUTHENTICATING PROXY DOES NOT ANSWER WITH AN ERROR. Cloudflare Access
       with an expired session, an SSO gateway, a captive portal: all reply
       200 OK with a sign-in page. Without a content-type check the downloader
       counts four hundred login forms as four hundred figures and caches every
       one, leaving a bank of broken images under a progress bar reading 100%. */
    const gated = await page.evaluate(async () => {
      const url = offlineFigures()[0];
      const looksOk = offlineIsImage(new Response('<html>sign in</html>',
        { status: 200, headers: { 'content-type': 'text/html; charset=utf-8' } }));
      /* Poison the cache the way a gated fetch would. The real figure has to
         go first: caches.match() returns the first hit across all caches, so
         with the good copy still present the survey would find that instead
         and the check would pass for the wrong reason. */
      const before = offlineJob.have;
      await offlinePurge(url);
      const c = await caches.open('accsap-test-poison');
      await c.put(url, new Response('<html>sign in</html>',
        { status: 200, headers: { 'content-type': 'text/html; charset=utf-8' } }));
      await offlineSurvey();
      const counted = offlineJob.have;
      await offlinePurge(url);
      await caches.delete('accsap-test-poison');
      return { looksOk, before, counted };
    });
    ok('a 200 sign-in page is not mistaken for a figure', gated.looksOk === false);
    ok('and one already in the cache is not counted as present',
       gated.counted === gated.before - 1, `${gated.before} → ${gated.counted}`);

    /* Put the real one back so the offline check below has it. */
    await page.evaluate(() => offlineDownload());
    await page.waitForFunction(() => !offlineJob.busy, null, { timeout: 300000 });
    ok('and a retry restores it', await page.evaluate(() => offlineJob.have === offlineJob.total &&
       offlineJob.bad === 0));

    /* The claim, tested the only way that means anything: network off, and a
       question this session has never opened. */
    transport.cut();
    ok('the download check has no origin transport', await transport.unavailable());
    const cold = await page.evaluate(async () => {
      const q = ALL_Q.filter(x => x.figs && x.figs.length).slice(-1)[0];
      jumpTo(q.id);
      await new Promise(r => setTimeout(r, 2500));
      const img = document.querySelector('img[src*="content/figures/"]');
      return { id: q.id, found: !!img, complete: !!img && img.complete,
               px: img ? img.naturalWidth : 0 };
    });
    transport.resume();
    ok('offline, a figure never visited this session still draws',
       cold.found && cold.complete && cold.px > 500,
       `${cold.id} at ${cold.px}px`);
    await ctx.close();
    transport.close();
  }

  head('memory: the whole bank is no longer resident');
  {
    const page = watch(await browser.newPage({ viewport: { width: 900, height: 1000 } }), events, 'memory', errors);
    const pwaHeap = await heapAfterBoot(page, target);
    await page.close();
    if (pwaHeap === null) {
      unmeasurable('the shell\'s heap after boot',
                   `${engineName()} has no heap profiler — run this section on chromium`);
    } else if (baseline) {
      const p2 = watch(await browser.newPage({ viewport: { width: 900, height: 1000 } }), events, 'memory/second page', errors);
      const baseHeap = await heapAfterBoot(p2, 'file://' + path.resolve(baseline));
      await p2.close();
      ok('heap is materially lower than the single-file build',
         pwaHeap > 0 && baseHeap > 0 && pwaHeap < baseHeap * 0.6,
         `${mb(baseHeap)} → ${mb(pwaHeap)}`);
    } else {
      ok('heap after boot is under 40 MB', pwaHeap > 0 && pwaHeap < 40 * 1048576, mb(pwaHeap));
    }
  }

  head('a bootloader that could not start the app installs nothing');
  /* The two failure paths in the bootloader were written to the same shape and
     only one of them kept it: the content-fetch failure returns out of the
     async function, the app.js-load failure did not, so execution carried on
     into the service-worker registration below it and installed a worker for
     an application that had never started. Nothing visibly broke — which is
     why it survived — but the next launch is then served by a worker whose
     whole job is to cache a shell that could not run.

     Driven by refusing app.js at the network, which is what a half-deployed
     site or a truncated download actually looks like. A fresh context, because
     registrations are per-origin and every other section here installs one. */
  {
    const ctx = await browser.newContext({ viewport: { width: 900, height: 1000 } });
    const page = watch(await ctx.newPage(), events, 'bootloader', errors);
    await page.route('**/app.js', r => r.abort());
    await page.goto(ORIGIN + '/index.html', { waitUntil: 'load', timeout: 120000 });
    const shown = await page.waitForFunction(
      () => /failed to load/i.test(document.body.textContent || ''), null, { timeout: 30000 })
      .then(() => true, () => false);
    ok('the failure reaches the splash instead of a blank screen', shown);
    /* Long enough for a registration to have happened if one were going to:
       register() is called synchronously on the line after, and the section
       below proves the same wait is enough to see one when it is there. */
    await page.waitForTimeout(2500);
    const supported = await page.evaluate(() => 'serviceWorker' in navigator);
    if (!supported) {
      unmeasurable('no worker is registered for an app that never started',
                   'this engine has no navigator.serviceWorker');
      unmeasurable('and a healthy load still registers one', 'the same');
    } else {
      const regs = await page.evaluate(() => navigator.serviceWorker.getRegistrations().then(r => r.length));
      ok('no worker is registered for an app that never started', regs === 0,
         `${regs} registration(s)`);
      /* THE HALF THAT STOPS A BROKEN REGISTRATION PASSING. Zero is also what a
         build that never registers anything would score, so the same context
         loads the page without the block and has to reach one. */
      const healthy = watch(await ctx.newPage(), events, 'bootloader/healthy', errors);
      await healthy.goto(ORIGIN + '/index.html', { waitUntil: 'load', timeout: 120000 });
      await healthy.waitForFunction(() => typeof S !== 'undefined', null, { timeout: 120000 });
      const after = await healthy.evaluate(async () => {
        for (let i = 0; i < 50; i++) {
          const r = await navigator.serviceWorker.getRegistrations();
          if (r.length) return r.length;
          await new Promise(res => setTimeout(res, 100));
        }
        return 0;
      });
      ok('and a healthy load still registers one', after > 0, `${after} registration(s)`);
      await healthy.close();
    }
    await ctx.close();
  }

  head('the figure cache the AI path fills has a lid on it');
  /* WHAT THIS IS ABOUT. figuresAsDataUrls() base64s a question's figures for
     the Messages API, which cannot take a URL it has no access to, and cached
     the result per question id — for the life of the tab, with no bound. Base64
     is a third larger again than the bytes on the wire, and a fellow working
     through a chapter with Apex open touches dozens of questions in a sitting.
     An iPad reclaims memory by killing the tab rather than by asking.
     
     Re-resolving costs nothing worth saving: the service worker has the figure,
     so a miss is a cache read rather than a download. The cache only has to
     cover an agent loop sending the same figures several times in a row. */
  {
    const ctx = await browser.newContext({ viewport: { width: 900, height: 1000 } });
    const page = watch(await ctx.newPage(), events, 'figure cache lid', errors);
    await page.goto(target, { waitUntil: 'load', timeout: 200000 });
    await booted(page);
    await page.evaluate(() => navigator.serviceWorker.ready);

    const lid = await page.evaluate(async () => {
      const withFigs = ALL_Q.filter(q => q.img && IMGS[q.id] && IMGS[q.id].length).slice(0, 40);
      if (withFigs.length < 30) return { skipped: withFigs.length };
      for (const q of withFigs) await figuresAsDataUrls(q);
      /* Ask again for the one requested LAST of the first batch: under
         least-recently-used it is long gone, and under insertion-order-only it
         would also be gone — so the discriminating probe is the one below. */
      return { asked: withFigs.length, size: _figDataCache.size,
               cap: FIG_CACHE_MAX_ENTRIES, bytes: _figCacheBytes, byteCap: FIG_CACHE_MAX_BYTES,
               newestKept: _figDataCache.has(withFigs[withFigs.length - 1].id),
               oldestDropped: !_figDataCache.has(withFigs[0].id) };
    });
    if (lid.skipped !== undefined) {
      unmeasurable('the cache stops growing', `only ${lid.skipped} questions in this bank carry figures`);
      unmeasurable('and it keeps the newest rather than the first', 'the same');
      unmeasurable('it is least-recently-USED, not merely first-in-first-out', 'the same');
    } else {
      ok('the cache stops growing', lid.size <= lid.cap,
         `${lid.size} entries after ${lid.asked} questions, cap ${lid.cap}`);
      ok('and its bytes stay under the budget', lid.bytes <= lid.byteCap,
         `${(lid.bytes / 1048576).toFixed(1)} MB of ${(lid.byteCap / 1048576).toFixed(0)} MB`);
      ok('and it keeps the newest rather than the first',
         lid.newestKept === true && lid.oldestDropped === true,
         `newest kept ${lid.newestKept}, oldest dropped ${lid.oldestDropped}`);

      /* THE CHECK THAT TELLS LRU FROM FIFO, and the reason it matters: an agent
         loop asks for the SAME question's figures on every iteration. Under
         first-in-first-out a question asked about repeatedly is still evicted on
         schedule and re-resolved every time; under least-recently-used it stays.
         Re-touch one, fill past the cap, and see whether it survived. */
      const lru = await page.evaluate(async () => {
        const withFigs = ALL_Q.filter(q => q.img && IMGS[q.id] && IMGS[q.id].length);
        const keep = withFigs.find(q => _figDataCache.has(q.id));
        if (!keep) return { skipped: true };
        await figuresAsDataUrls(keep);                       // touched: now newest
        const fresh = withFigs.filter(q => !_figDataCache.has(q.id)).slice(0, FIG_CACHE_MAX_ENTRIES - 1);
        for (const q of fresh) await figuresAsDataUrls(q);   // fill to the cap around it
        return { skipped: false, survived: _figDataCache.has(keep.id), pushed: fresh.length };
      });
      ok('it is least-recently-USED, not merely first-in-first-out',
         lru.skipped ? false : lru.survived === true,
         lru.skipped ? 'nothing was in the cache to re-touch' : `${lru.pushed} newer entries pushed in after it`);
    }

    /* The limits exist as named numbers rather than as literals buried in the
       resolver, because the next person to tune them should not have to find
       them by reading the fetch. */
    const limits = await page.evaluate(() => ({
      timeout: typeof FIG_FETCH_TIMEOUT_MS === 'number' ? FIG_FETCH_TIMEOUT_MS : null,
      maxBytes: typeof FIG_MAX_BYTES === 'number' ? FIG_MAX_BYTES : null,
    }));
    ok('a figure fetch cannot hang a turn forever', limits.timeout > 0 && limits.timeout <= 60000,
       `${limits.timeout}ms`);
    /* Above the largest figure in the bank and far below anything that hurts. */
    ok('and an enormous one is refused rather than base64ed to find out',
       limits.maxBytes >= 1048576 && limits.maxBytes <= 32 * 1048576,
       `${(limits.maxBytes / 1048576).toFixed(0)} MB`);
    await ctx.close();
  }

  head('a shell and a code file from different builds do not run together');
  /* THE WINDOW THIS CLOSES. sw.js serves the shell cache-first and refreshes it
     in the background, one request at a time. A deploy that lands between the
     request for index.html and the request for app.js leaves a launch running
     one build's HTML against the other build's code — and because the refresh
     writes each file as it arrives, the mixed pair persists in the cache until
     something replaces it. Nothing crashes. The app behaves like neither
     version, which is worse, because there is nothing to report.
     
     Both files now carry a stamp taken over the shell digest and the content
     digest together, so any change to either moves it. Driven here by serving
     an app.js from a build that does not exist, which is exactly what the
     browser would have been handed. */
  {
    const ctx = await browser.newContext({ viewport: { width: 900, height: 1000 } });
    const page = watch(await ctx.newPage(), events, 'mismatched builds', errors);
    let loads = 0;
    page.on('framenavigated', f => { if (f === page.mainFrame()) loads++; });
    /* One character different is a different build. */
    await page.route('**/app.js', async route => {
      const res = await route.fetch();
      const body = (await res.text()).replace(/var APP_BUILD_ID='[a-f0-9]+'/,
                                              "var APP_BUILD_ID='0000000000000000'");
      await route.fulfill({ response: res, body });
    });
    await page.goto(target, { waitUntil: 'load', timeout: 200000 });
    /* It reloads once, finds the same mismatch, and must then STOP and say so
       rather than spin. Waiting on the message, not on a stopwatch. */
    /* innerText, NOT textContent, and this is the whole fix. textContent
       includes the source of every inline <script>, and the loader that
       prints this message is an inline script in the body — so the wait
       matched the loader's own source code on the FIRST load, before any
       mismatch had been noticed or any retry made. It passed hardest when
       the check it guards had not run at all.

       Found by the owner's run: this check passed and the one below reported
       "1 navigations", which is impossible if the message was real — the app
       shows it only after the one retry, so a real sighting means at least
       two. The retry then fired under the next page.evaluate, the execution
       context went with it, and the suite died without a summary.

       innerText is the rendered text: no script source, nothing hidden. */
    let noticeError = '';
    const told = await page.waitForFunction(mixedPairNotice,
      null, { timeout: 30000 }).then(() => true, err => { noticeError = String(err.message || err).split('\n')[0]; return false; });
    ok('a mixed pair is noticed rather than run', told, noticeError);
    /* The loop guard, which is the half that makes this safe to ship: exactly
       one retry. A reload that does not fix it must never become a reload
       that never stops. AND IT MUST HAVE HAPPENED: `loads <= 3` alone passed
       at 1, which is no retry at all, under a label claiming one. The goto is
       the first navigation, so a retry that happened means at least two. */
    await page.waitForTimeout(2500);
    ok('and it retries once, not forever', loads >= 2 && loads <= 3, `${loads} navigations`);
    const flagged = await page.evaluate(() => {
      try { return sessionStorage.getItem('accsap-mixed-build'); } catch (_) { return 'unreadable'; }
    });
    ok('the retry is remembered per tab, so the reload cannot loop', flagged === '1', String(flagged));
    ok('mismatched code never initializes the application', await page.evaluate(() => typeof S === 'undefined'));
    ok('the mismatch warning remains visible after the retry settles', await page.evaluate(mixedPairNotice));
    await ctx.close();
  }

  head('a deploy between preflight and execution cannot run different bytes');
  {
    const ctx = await browser.newContext({ viewport: { width: 900, height: 1000 } });
    const page = watch(await ctx.newPage(), events, 'code changed after preflight', errors);
    let requests = 0;
    await page.route('**/app.js', async route => {
      const response = await route.fetch();
      const original = await response.text();
      requests++;
      const body = requests === 1 ? original : original + '\nwindow.__pwaRaceExecuted = true;';
      await route.fulfill({ response, body });
    });
    await page.goto(target, { waitUntil: 'load', timeout: 200000 });
    await page.waitForFunction(() => window.__pwaRaceExecuted === true ||
      !!document.body && /application code failed to load/i.test(document.body.innerText || ''), null, { timeout: 30000 });
    const refused = await page.evaluate(() => ({ executed: window.__pwaRaceExecuted === true,
      started: typeof S !== 'undefined', warned: /application code failed to load/i.test(document.body.innerText || '') }));
    ok('the second response is integrity checked and refused before it can initialize',
      requests >= 2 && !refused.executed && !refused.started && refused.warned, JSON.stringify({ requests, ...refused }));
    await ctx.close();
  }

  head('and the three files a deploy writes agree on which build they are');
  {
    /* Read off the served directory rather than the page: this is a property of
       the artifact, and it is the one a person can check by hand on a server. */
    const shell = await (await fetch(new URL('index.html', target).href)).text();
    const app = await (await fetch(new URL('app.js', target).href)).text();
    const sw = await (await fetch(new URL('sw.js', target).href)).text();
    const idOf = (src, re) => (re.exec(src) || [])[1] || null;
    const a = idOf(shell, /SHELL_BUILD_ID = '([a-f0-9]+)'/);
    const b = idOf(app, /var APP_BUILD_ID='([a-f0-9]+)'/);
    const c = idOf(sw, /const BUILD_ID\s*=\s*'([a-f0-9]+)'/);
    ok('index.html carries a build stamp', !!a, a || 'absent');
    ok('app.js carries one too', !!b, b || 'absent');
    ok('and so does the worker', !!c, c || 'absent');
    ok('all three are the same build', !!a && a === b && b === c, `${a} / ${b} / ${c}`);
    /* And it is derived from both digests, so a content-only change moves it —
       which is the whole reason it is not just the shell digest again. */
    const shellV = idOf(sw, /const SHELL_V\s*=\s*'([a-f0-9]+)'/);
    ok('the stamp is not merely the shell digest under another name',
       !!shellV && a !== shellV, `build ${a}, shell ${shellV}`);

    /* ── AND WHICH COMMIT MADE THEM ────────────────────────────────────────
       BUILD_ID says the three files are from the same deploy. It cannot say
       which commit to open to read what is in them, and three months after a
       deployment that is the question. The commit rides beside it in all
       three files and in content/manifest.json.

       CHECKED HERE, OFF THE SERVED DIRECTORY, because until now nothing did.
       tests/verify-provenance-pure.js asserts build-pwa.js EMITS these — it
       reads that script as text and cannot tell whether a stamp survived
       substitution, the split, the font lift or the minifier. This reads the
       artifact, which is the only thing that answers it. Same division as
       every other pair of pure and browser suites here. */
    const gitish = /^(?:[0-9a-f]{7,40}(?:-dirty)?|unknown)$/;
    const ca = idOf(shell, /SHELL_COMMIT = '([^']*)'/);
    const cb = idOf(app, /var APP_COMMIT='([^']*)'/);
    const cc = idOf(sw, /const COMMIT\s*=\s*'([^']*)'/);
    ok('index.html names the commit it was built from', !!ca && gitish.test(ca), ca || 'absent');
    ok('app.js names it too', !!cb && gitish.test(cb), cb || 'absent');
    ok('and so does the worker', !!cc && gitish.test(cc), cc || 'absent');
    ok('all three agree on which commit that was', !!ca && ca === cb && cb === cc,
       `${ca} / ${cb} / ${cc}`);
    /* THE PLACEHOLDER MUST NOT SURVIVE. build-pwa.js throws if __COMMIT__ is
       still present after substitution, but that check reads `html` before
       eight further steps rewrite it. A literal __COMMIT__ reaching a device
       is a stamp that looks present and says nothing. */
    ok('no unsubstituted placeholder reached the artifact',
       !/__COMMIT__|__BUILD_ID__/.test(shell + app + sw));
    /* AND IT IS NOT THE BUILD ID WEARING A HAT. If someone ever folded the
       commit into BUILD_ID, or stamped BUILD_ID into both slots, these would
       read identically and every check above would still pass. */
    ok('the commit is a commit, not a copy of the build stamp', ca !== a,
       `commit ${ca}, build ${a}`);
    /* The content half, which is written by a different script entirely
       (extract-content.js) and is the one that says which commit the BANK
       came from — the half the freshness check compares. */
    const manifest = await (await fetch(new URL('content/manifest.json', target).href)).json();
    ok('the extracted content records a commit as well',
       !!manifest.commit && gitish.test(String(manifest.commit)), String(manifest.commit));
    ok('and a sourceDigest, which is what build-pwa compares against',
       /^[a-f0-9]{16}$/.test(String(manifest.sourceDigest)), String(manifest.sourceDigest));
  }

  head('the split build fits the screen it is held on');
  /* WHY THIS IS HERE AND NOT IN verify-home. verify-home tests whichever target
     the runner was given, and the screen that overflowed was the SPLIT build
     specifically — it is the only one with an offline-download card, because it
     is the only one whose figures are not already data: URIs in memory. --pwa is
     the only run that always has a served build, so this is where the claim can
     be made unconditionally.

     1194x834 is an 11-inch iPad in landscape: the widest and shortest shape the
     app is held in, and the one the landscape grid is written for. It measured
     97px over — the hero's axis (step 84) took 50 of that and moving the card to
     Progress (step 85) took the rest. */
  {
    const ctx = await browser.newContext({ viewport: { width: 1194, height: 834 } });
    const page = watch(await ctx.newPage(), events, 'narrow screen', errors);
    await page.goto(target, { waitUntil: 'load', timeout: 200000 });
    await booted(page);
    await page.evaluate(() => { goHome(); render(); });
    /* verify-home's settle, for the same reason it has one: a box that has held
       still for five frames with no finite animation running is settled, and a
       fixed sleep is a guess that passes on a fast machine and lies on a slow
       one. */
    await page.waitForFunction(() => {
      const r = document.getElementById('app').getBoundingClientRect();
      const k = [innerWidth, innerHeight, Math.round(r.width), Math.round(r.height),
                 document.documentElement.scrollHeight].join(',');
      const busy = document.getAnimations().some(a => a.playState === 'running' &&
        Number.isFinite(a.effect && a.effect.getTiming().iterations));
      window.__s = (window.__l === k && !busy) ? (window.__s || 0) + 1 : 0;
      window.__l = k;
      return window.__s >= 5;
    }, null, { timeout: 15000, polling: 'raf' });
    /* FIRST RUN AND EVERY RUN AFTER IT ARE DIFFERENT SCREENS, and only one of
       them is a standing property. A brand-new install also carries the welcome
       card — "New here?", with a Got it button — which is 130px and goes away
       for good the moment it is tapped. The screen that has to fit is the one a
       fellow sees every day, so that is what is asserted; the first-run number
       is measured too and printed beside it, because a cost nobody prints is a
       cost nobody notices growing. */
    const firstRun = await page.evaluate(() => ({
      over: document.documentElement.scrollHeight - innerHeight,
      hello: !!document.querySelector('.hello'),
    }));
    await page.evaluate(() => { try { dismissHello(); } catch (_) {} goHome(); render(); });
    await page.waitForFunction(() => !document.querySelector('.hello'), null, { timeout: 15000 });
    await page.waitForFunction(() => {
      const r = document.getElementById('app').getBoundingClientRect();
      const k = [innerWidth, innerHeight, Math.round(r.width), Math.round(r.height),
                 document.documentElement.scrollHeight].join(',');
      const busy = document.getAnimations().some(a => a.playState === 'running' &&
        Number.isFinite(a.effect && a.effect.getTiming().iterations));
      window.__s2 = (window.__l2 === k && !busy) ? (window.__s2 || 0) + 1 : 0;
      window.__l2 = k;
      return window.__s2 >= 5;
    }, null, { timeout: 15000, polling: 'raf' });
    const m = await page.evaluate(() => {
      /* WHAT reaches lowest, not just by how much. This failed once at "9px
         over" and the number named nothing — the only way on from there was
         to open the split build by hand and measure, which is what this line
         is for. Considered: #app's children and grandchildren, which on the
         landscape home are the four grid areas and what each one holds.
         Fixed and pointer-events:none elements are skipped, as decoration
         is everywhere else in these suites.

         IT CARRIES ITS OWN NUMBERS, so a reader can tell a lead from a
         verdict: the element's bottom edge against the viewport height. If
         that edge is inside the viewport while the page still scrolls, the
         overflow is padding or margin below the content, not the content —
         which is a different fix, and worth knowing before anyone makes the
         wrong one. The first-run welcome card is gone by the time this runs. */
      function lowestInApp() {
        const app = document.getElementById('app');
        if (!app) return '';
        let best = null, bottom = -Infinity;
        for (const el of app.querySelectorAll(':scope > *, :scope > * > *')) {
          const cs = getComputedStyle(el);
          if (cs.display === 'none' || cs.visibility === 'hidden') continue;
          if (cs.position === 'fixed' || cs.pointerEvents === 'none') continue;
          const r = el.getBoundingClientRect();
          if (r.width < 1 || r.height < 1) continue;
          /* >= so a later element wins a tie: document order puts a child
             after its parent, and the child is the one worth naming. */
          if (r.bottom >= bottom - 0.5) { bottom = r.bottom; best = el; }
        }
        if (!best) return '';
        const name = e => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') +
          (e.className && typeof e.className === 'string' && e.className.trim()
            ? '.' + e.className.trim().split(/\s+/)[0] : '');
        const where = best.parentElement && best.parentElement !== app
          ? name(best.parentElement) + ' > ' + name(best) : name(best);
        return ` [lowest: ${where}, ${Math.round(best.getBoundingClientRect().height)}px tall,` +
          ` ends at ${Math.round(bottom)} of ${innerHeight}]`;
      }
      /* AND WHICH ROW. The first run with the lead above named .home-wrap
         itself — 781px tall, ending at 843 of 834 — which put the overflow in
         the grid's contents (745px against a 736px budget) but not in any one
         of them. The landscape home is a grid whose third row is 1fr, so the
         question left is one number: is that row 0? If so the left column —
         hero, progress, doors — is too tall on its own and no pearl is
         involved. If not, a pearl's text is sizing the flexible row, which is
         a different fix. getComputedStyle resolves grid-template-rows to used
         pixel sizes, so the browser answers it directly. Each row is labelled
         by the first area named on it, so a reorder cannot mislabel one. */
      function gridRows() {
        const w = document.querySelector('#app .home-wrap');
        if (!w) return '';
        const cs = getComputedStyle(w);
        if (cs.display !== 'grid') return ` [rows: .home-wrap is ${cs.display}, not a grid]`;
        const sizes = cs.gridTemplateRows.split(/\s+/).filter(Boolean);
        const names = (cs.gridTemplateAreas.match(/"[^"]*"/g) || [])
          .map(r => r.replace(/"/g, '').trim().split(/\s+/)[0]);
        return ' [rows: ' + sizes.map((v, i) => (names[i] || 'row' + (i + 1)) + ' ' +
          Math.round(parseFloat(v))).join(' · ') + ' px]';
      }
      /* WHICH PEARL. The same build overflowed by 9px, then 9px, then fitted —
         nothing in the app changed between those runs, so what differs is
         what the home screen chose to show, and the pearl is chosen at random
         from a few hundred. Its length and rendered height, printed beside the
         rows, let a passing run and a failing run be compared directly. */
      const pb = document.getElementById('pearlBody');
      const pearl = pb ? ` [pearl: ${pb.textContent.trim().length} chars,` +
        ` ${Math.round(pb.getBoundingClientRect().height)}px]` : ' [pearl: none on screen]';
      return {
        over: document.documentElement.scrollHeight - innerHeight,
        card: !!document.getElementById('offlineCard'),
        appW: Math.round(document.getElementById('app').getBoundingClientRect().width),
        vw: innerWidth,
        lowest: lowestInApp(),
        rows: gridRows(),
        pearl,
      };
    });
    ok('an 11-inch iPad in landscape needs no scrolling on the home screen',
       m.over <= 0, `${m.over}px over — first run, with the welcome card, was ${firstRun.over}px` +
       /* On EVERY run, not only a failing one. The overflow is intermittent
          — 9, 9, then 0 on one build — and a passing run that says nothing
          about how close it came is half the comparison thrown away. A pass
          that ends at 833 of 834 is a warning; one at 790 is a margin. */
       m.lowest + m.rows + m.pearl);
    /* The half that stops this being satisfied by an empty screen: it must still
       be using the width, which is what the landscape layout is for. */
    ok('and it is still filling the width while it does',
       m.appW / m.vw > 0.9, `${m.appW} of ${m.vw}`);
    ok('the card that used to overflow it is on Progress instead', m.card === false);
    /* render() goes through startViewTransition, so the markup it produces lands
       in an async callback and is NOT in the document when goStats() returns. */
    const onStats = await page.evaluate(() => { goStats(); }).then(() =>
      page.waitForFunction(() => !!document.getElementById('offlineCard'), null, { timeout: 15000 })
        .then(() => true, () => false));
    ok('and it really is there, rather than merely gone', onStats === true);
    await ctx.close();
  }

  head('the server that hosts this cannot be walked out of');
  /* docs/IPAD.md offers scripts/serve.js as a hosting route over Tailscale, so
     its root guard is load-bearing rather than a development convenience. It
     was `file.startsWith(DIR)` with no trailing separator, which also accepts
     any SIBLING whose name merely begins with the root's — "/../dist-old/x"
     escaped a root of "dist". path.join has already collapsed the "..", so the
     separator is the entire check. Requested with the raw path, because a
     normalising client would resolve the traversal before it was ever sent. */
  {
    const raw = p => new Promise(resolve => {
      const http = require('http'), u = new URL(ORIGIN);
      const req = http.request({ host: u.hostname, port: u.port, path: p, method: 'GET' },
        r => { let b = ''; r.on('data', d => b += d); r.on('end', () => resolve({ status: r.statusCode, body: b })); });
      req.on('error', () => resolve({ status: 0, body: '' }));
      req.end();
    });
    const control = await raw('/index.html');
    ok('a file inside the root is still served', control.status === 200, String(control.status));
    const sibling = await raw('/../dist-old/secret.txt');
    ok('a sibling directory sharing the root\'s name prefix is refused',
       sibling.status === 403 || sibling.status === 404, String(sibling.status));
    const outside = await raw('/../../etc/hostname');
    ok('and so is a plain walk upwards', outside.status === 403 || outside.status === 404, String(outside.status));
  }

  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`
              + (unmeasured ? `, ${unmeasured} not measured here (${engineName()}${BANK.synthetic ? ', synthetic bank' : ''})` : ''));
  process.exit(failed ? 1 : 0);
})();
