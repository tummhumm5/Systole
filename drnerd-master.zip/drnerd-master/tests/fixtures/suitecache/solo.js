window.__solo = true;
