window.__classic = true;
