#!/usr/bin/env node
/*
 * How well the library actually retrieves, as a number.
 *
 *   node tests/verify-retrieval.js [build/systole.html] [--misses]
 *
 * WHY THIS EXISTS. The adoption plan proposed replacing the hand-rolled index
 * with MiniSearch, gated on "measurably better recall — not 'feels better'".
 * There was no way to measure either side, so the gate could not be applied
 * and the swap would have gone in on vibes. This is the measurement.
 *
 * It is known-item retrieval: a query built out of a note's own material
 * should return that note. No relevance judgements are invented — the ground
 * truth is the note's identity. Four query shapes, because the engines that
 * were compared here disagree depending on shape, and the disagreement is the
 * whole finding:
 *
 *   exact    the note's title, as written
 *   typo     the title with one adjacent-character transposition
 *   prefix   the title with every word truncated to five characters
 *   body     twelve words from the middle of the note's own prose, title
 *            nowhere in the query
 *
 * WHAT THE MEASUREMENT SAID. Against MiniSearch 7.2.0 over the same 785-doc
 * corpus with the app's own clinical tokeniser:
 *
 *              R@1 today   R@1 MiniSearch
 *   exact         95.9%        100.0%
 *   typo          91.1%        100.0%
 *   prefix        54.1%         99.3%
 *   body          99.3%         90.4%
 *
 * MiniSearch wins three of four and loses the fourth. That fourth is the one
 * production issues: groundedContext searches on the fellow's chat text
 * repeated three times plus 160 characters of question stem, which is a long
 * prose query, not a title. So the swap was not made.
 *
 * THE `prefix` GAP WAS THEN CLOSED WITHOUT IT, IN TWO STEPS. Chain step 72
 * completed query tokens the index had never seen — at most two completions,
 * nearest in length first — taking that column from 54.1% to 80.1% and its ten
 * empty result sets to zero, for fifteen lines. Its own note said the rest
 * "needs prefix matching inside the ranker rather than terms OR-ed into the
 * query". Chain step 73 is that: a stub is scored as one term whose postings
 * are the union of every term it prefixes, tf summed and df counted over
 * documents, so there is no cap, no double counting, and the idf is the
 * prefix's own. 66.8% to 87.1% on the 295-note shelf.
 *
 * `prefix` USED TO BE SENSITIVE TO HOW BIG THE LIBRARY IS. Under step 72 it
 * fell as the shelf grew, and steeply: holding the query set fixed at the 146
 * pre-existing notes and admitting valvular notes to the index in quarters,
 *
 *   index      146     183     221     258     295 notes
 *   step 72   80.1%   77.4%   74.7%   72.6%   71.9%    −8.2 points
 *   step 73   88.4%   88.4%   87.0%   87.0%   87.7%    −0.7 points
 *
 * Same queries, same target notes, only the number of documents competing for
 * the same stems changing. The old decline was monotonic because a cap of two
 * completions goes on getting less adequate as the vocabulary grows — the
 * mechanism was sensitive to collection size on top of the ordinary BM25
 * dilution. Scoring the whole prefix union removes that term, and what is left
 * is flat to within its own noise: the step-73 row is not even monotonic.
 *
 * THIS IS WHY THE FLOOR IS TIGHT. Under step 72 a floor near the measured
 * value would have tripped on the next unit imported, and the finding would
 * have been "the shelf grew" every time — a guard that cries wolf gets
 * ignored. At 0.7 points per 150 notes it now takes something like another 230
 * notes of drift to move 87.1% to 86.0%, so a failure here is once again most
 * likely to be what this file is for: a ranker regression. Should it fail
 * anyway, the counterfactual above is how to tell the two apart in one run —
 * index a subset, re-measure the same notes. `exact` is not sensitive in this
 * way and did not move at all across the same change.
 *
 * The floors below are a REGRESSION GUARD, set roughly one point under
 * today's measured values. One point, not five, because the measurement is
 * deterministic — there is no run-to-run noise for a wide margin to absorb,
 * and a slack floor is not a guard: the first draft of this file sat 3-4
 * points low, and removing the reference-note boost from the shipped ranking
 * moved `body` from 99.3% to 97.3% without turning a single check red.
 *
 * They are not a target to tune towards, and per standing discipline they are
 * never to be lowered to accommodate a regression: a number that drops is a
 * finding about retrieval, not about this file. Raising one when the ranker
 * genuinely improves is the other half of that bargain, and is why the
 * `prefix` floor moved from 0.79 to 0.86 with step 73 — a point under the
 * measured 87.1%, on a number that no longer drifts with the corpus.
 */
'use strict';
const path = require('path');
const { launch } = require('./_engine');
const { onDeath, watch } = require('./_deathnote.js');
const { BOOT_TIMEOUT } = require('./_render.js');

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

/* Out here because the tail is `})().catch(…)`, which handles the rejection —
   nothing is ever unhandled, so a note installed inside the IIFE would never
   fire. The catch takes the emitter instead. See tests/_deathnote.js. */
const errors = [], events = [];
const died = onDeath(() => ({ section, checks: passed + failed, errors,
                              events: events.length ? events.join(', ') : 'none' }));
const pct = x => (x * 100).toFixed(1) + '%';
/* The count beside the rounding: at one decimal 1122/1145 (97.99%, under a
   0.98 floor) and 1123/1145 (98.08%, over it) both print "98.0%", and a
   failing check that reads as its own floor tells the reader nothing. */
const frac = (x, n) => `${pct(x)} (${Math.round(x * n)}/${n})`;

const TARGET = process.argv.slice(2).find(a => !a.startsWith('--')) || path.join(__dirname, '..', 'build', 'systole.html');

(async () => {
  const browser = await launch();
  const page = watch(await browser.newPage({ viewport: { width: 1200, height: 900 } }), events);
  page.on('pageerror', e => errors.push(e.message));
  /* The real build is ~92 MB. Without a timeout here Playwright's 30 s default
     applied to the load, and the owner's Windows run died on it before the
     first check, while the wait below allowed two minutes. Both use the shared
     boot budget now. */
  await page.goto('file://' + path.resolve(TARGET), { timeout: BOOT_TIMEOUT });
  await page.waitForFunction(
    () => typeof S !== 'undefined' && typeof search === 'function' && typeof REF !== 'undefined', null,
    { timeout: BOOT_TIMEOUT });

  /* --misses lists which notes each shape failed to put first, and what came
     first instead. Off by default and changes nothing measured: it exists so a
     failing floor after a new unit can be traced to the notes responsible
     rather than guessed at. Titles only — every result is filtered to
     kind 'r' before ranking, so no question text can reach this output. */
  const MISSES = process.argv.includes('--misses');
  /* --why counts what kind of note each shape missed, and what beat it —
     numbers only, no titles, so it can be pasted from a machine whose notes
     are licensed. Off by default and changes nothing measured. */
  const WHY = process.argv.includes('--why');
  const r = await page.evaluate(({ MISSES, WHY }) => {
    const notes = REF.filter(x => x && x.title && x.title.trim().length > 6);
    const transpose = s => {
      const w = s.split(/\s+/);
      let li = 0; for (let i = 1; i < w.length; i++) if (w[i].length > w[li].length) li = i;
      const t = w[li]; if (t.length < 4) return s;
      const i = Math.floor(t.length / 2);
      w[li] = t.slice(0, i) + t[i + 1] + t[i] + t.slice(i + 2);
      return w.join(' ');
    };
    const truncate = s => s.split(/\s+/).map(x => x.length > 5 ? x.slice(0, 5) : x).join(' ');
    const midWindow = x => {
      const w = String(x.body || '').split(/\s+/).filter(Boolean);
      if (w.length < 24) return '';
      return w.slice(Math.floor(w.length / 2) - 6, Math.floor(w.length / 2) + 6).join(' ');
    };

    const sets = {
      exact:  notes.map(x => ({ q: x.title, id: x.id })),
      typo:   notes.map(x => ({ q: transpose(x.title), id: x.id })),
      prefix: notes.map(x => ({ q: truncate(x.title), id: x.id })),
      body:   notes.map(x => ({ q: midWindow(x), id: x.id })).filter(x => x.q),
    };

    /* Retrieved the way groundedContext really does it: a generous limit, then
       filter to notes. A limit of ten would measure something the app never
       does — the index also holds 639 questions competing for those places. */
    const run = q => search(q, { limit: 40 })
      .filter(h => h.meta.kind === 'r').slice(0, 10).map(h => h.meta.id);

    const byId = Object.create(null);
    for (const x of notes) byId[x.id] = x;
    const bw = x => !!x && /(^|,)\s*braunwald\s*(,|$)/i.test(String(x.tags || ''));
    const wordset = x => new Set(String(x && x.body || '').toLowerCase().split(/[^a-z0-9]+/).filter(w => w.length > 3));
    const titleCount = Object.create(null);
    for (const x of notes) titleCount[x.title] = (titleCount[x.title] || 0) + 1;
    /* For each miss: is the note a Braunwald one, is the winner, does the
       winner hold most of the missed note's words (a near-copy), and is the
       missed title one another note also has (unfindable by title at all). */
    const tallyWhy = pairs => {
      const t = { misses: pairs.length, missedBW: 0, winnerBW: 0, bwBeatenByBW: 0, nearCopy: 0, sharedTitle: 0, noWinner: 0,
                  sameFile: 0, winnerHoldsAllQuery: 0, winnerHoldsAllHeading: 0,
                  /* Which kinds met (figure note or text note, target then
                     winner), and how often the query appears word for word in
                     the winner — a shared passage, not shared vocabulary. */
                  kinds: { ff: 0, ft: 0, tf: 0, tt: 0 }, verbatimInWinner: 0 };
      const isFig = x => /(^| — )Figs?\. \d/.test(String(x.title)) || /figures/i.test(String(x.title).split(' — ')[0]);
      const flat = x => String(x || '').toLowerCase().replace(/\s+/g, ' ');
      /* Medians over the misses: how much of the query each side holds (in
         the app's own tokens), the query's length, and each side's length —
         to tell "the winner matched as much and was shorter" from "the
         target did not hold its own title's terms". */
      const med = xs => { const v = xs.filter(Number.isFinite).sort((p, q) => p - q); return v.length ? +v[v.length >> 1].toFixed(2) : null; };
      const covT = [], covW = [], qLen = [], lenT = [], lenW = [], hLen = [];
      const fileOf = x => String(x.title).split(' — ')[0];
      for (const [id, win, q] of pairs) {
        const a = byId[id], b = byId[win];
        const qt = [...new Set(tok(q || ''))];
        const holds = x => { const d = new Set(tok(x.title + ' ' + (x.tags || '') + ' ' + (x.body || ''))); return qt.length ? qt.filter(w => d.has(w)).length / qt.length : NaN; };
        qLen.push(qt.length); covT.push(holds(a)); lenT.push(tok(a.body || '').length);
        /* The title's own part, after the file title every note of that file
           shares: the part meant to tell it apart. */
        const ht = [...new Set(tok(String(a.title).split(' — ').slice(1).join(' ')))];
        hLen.push(ht.length);
        if (b && ht.length) { const d = new Set(tok(b.title + ' ' + (b.tags || '') + ' ' + (b.body || ''))); if (ht.every(w => d.has(w))) t.winnerHoldsAllHeading++; }
        if (b) { t.kinds[(isFig(a) ? 'f' : 't') + (isFig(b) ? 'f' : 't')]++; if (q && flat(b.body).includes(flat(q))) t.verbatimInWinner++; }
        if (b) { const cw = holds(b); covW.push(cw); if (cw === 1) t.winnerHoldsAllQuery++; lenW.push(tok(b.body || '').length); if (fileOf(a) === fileOf(b)) t.sameFile++; }
        if (bw(a)) t.missedBW++;
        if (!b) { t.noWinner++; continue; }
        if (bw(b)) t.winnerBW++;
        if (bw(a) && bw(b)) t.bwBeatenByBW++;
        const A = wordset(a), B = wordset(b);
        let shared = 0; for (const w of A) if (B.has(w)) shared++;
        if (A.size && shared / A.size >= 0.5) t.nearCopy++;
        if (titleCount[a.title] > 1) t.sharedTitle++;
      }
      Object.assign(t, { medQueryTerms: med(qLen), medTargetHolds: med(covT), medWinnerHolds: med(covW), medHeadingTerms: med(hLen), medTargetLen: med(lenT), medWinnerLen: med(lenW) });
      return t;
    };
    const titleOf = Object.create(null);
    for (const x of notes) titleOf[x.id] = x.title;
    const measure = set => {
      let r1 = 0, r5 = 0, mrr = 0, empty = 0;
      const missed = [], why = [];
      for (const { q, id } of set) {
        let ids; try { ids = run(q); } catch (e) { ids = []; }
        if (!ids.length) empty++;
        const k = ids.indexOf(id);
        if (k === 0) r1++;
        else if (MISSES) missed.push(titleOf[id] + '  ->  ' + (ids.length ? titleOf[ids[0]] : '(nothing)'));
        if (WHY && k !== 0) why.push([id, ids[0], q]);
        if (k > -1 && k < 5) r5++;
        if (k > -1) mrr += 1 / (k + 1);
      }
      const n = set.length;
      return { n, r1: r1 / n, r5: r5 / n, mrr: mrr / n, empty, missed, why: WHY ? tallyWhy(why) : null };
    };

    const out = { notes: notes.length, docs: notes.length + ALL_Q.length, bwNotes: notes.filter(bw).length };
    for (const k of Object.keys(sets)) out[k] = measure(sets[k]);
    return out;
  }, { MISSES, WHY });

  head('the corpus is the one production searches');
  ok('the reference library is loaded', r.notes > 100, `${r.notes} notes`);
  ok('and the questions are in the same index', r.docs > 700, `${r.docs} documents`);
  ok('every query shape produced a usable set',
     r.exact.n === r.notes && r.typo.n === r.notes && r.prefix.n === r.notes && r.body.n > 100,
     `exact ${r.exact.n}, typo ${r.typo.n}, prefix ${r.prefix.n}, body ${r.body.n}`);

  head('a note is found from its own title');
  ok('R@1 at or above 0.95', r.exact.r1 >= 0.95, frac(r.exact.r1, r.exact.n));
  ok('R@5 at or above 0.99', r.exact.r5 >= 0.99, frac(r.exact.r5, r.exact.n));
  ok('and nothing comes back empty', r.exact.empty === 0, String(r.exact.empty));

  head('a typed-in-a-hurry title still finds it');
  ok('R@1 at or above 0.90 with one transposition', r.typo.r1 >= 0.90, frac(r.typo.r1, r.typo.n));
  ok('R@5 at or above 0.97', r.typo.r5 >= 0.97, frac(r.typo.r5, r.typo.n));

  head('a half-typed title completes to the note');
  ok('R@1 at or above 0.86 on truncated terms', r.prefix.r1 >= 0.86, frac(r.prefix.r1, r.prefix.n));
  /* Zero, not "few". Returning nothing at all is a different failure from
     ranking badly: it tells the fellow their library does not cover something
     it does cover. Ten of 146 did that before step 72. */
  ok('and NONE of them returns nothing at all', r.prefix.empty === 0,
     `${r.prefix.empty} empty of ${r.prefix.n}`);

  head('prose from the note itself — the shape production actually sends');
  ok('R@1 at or above 0.98', r.body.r1 >= 0.98, frac(r.body.r1, r.body.n));
  ok('R@5 at or above 0.99', r.body.r5 >= 0.99, frac(r.body.r5, r.body.n));
  ok('and nothing comes back empty', r.body.empty === 0, String(r.body.empty));

  head('prefix matching fires only where there was nothing to match');
  {
    /* THE SAFETY PROPERTY, and it is load-bearing rather than theoretical. A
       token the index knows must be scored as itself and never as a prefix:
       "as" is aortic stenosis on this shelf, and prefix-matching it would drag
       aspirin, assess and asystole into every search that mentions it. If this
       ever stops holding, every query that works today is being widened, and
       the three unchanged columns above would be the last place it showed.

       The vacuity guard is the second check: a stub must actually reach the
       terms it prefixes, or "known words are left alone" is true only because
       nothing is happening at all. */
    const probe = await page.evaluate(() => {
      search('warm the index', { limit: 1 });
      const untouched = Object.keys(IDX.df).filter(t => t.length >= 6 && IDX.df[t] > 2)
        .slice(0, 40).every(t => stubTerms(t) === null);
      /* Measured over the whole vocabulary rather than one probe word. A single
         pick is a lottery — the first long term happened to be "50-year-old",
         whose stub reaches exactly one thing — and a check that depends on
         which word sorts first is not measuring the mechanism. */
      const reaches = [];
      for (const w of Object.keys(IDX.df)) {
        if (w.length < 9 || IDX.df[w] <= 2) continue;
        const cut = w.slice(0, 5);
        if (IDX.df[cut]) continue;
        const r = stubTerms(cut);
        reaches.push(r ? r.length : 0);
      }
      reaches.sort((a, b) => a - b);
      return { untouched, n: reaches.length, median: reaches[reaches.length >> 1],
               overCap: reaches.filter(x => x > 2).length,
               vocab: Object.keys(IDX.df).length };
    });
    ok('a known word is never treated as a prefix', probe.untouched,
       `40 sampled from a ${probe.vocab}-term vocabulary`);
    /* The old mechanism took two completions however many there were, so every
       stub in the majority below lost the rest of its postings. */
    ok('and a stub reaches past the two completions the old cap allowed',
       probe.median >= 3 && probe.overCap / probe.n >= 0.5,
       `median reach ${probe.median}; ${probe.overCap}/${probe.n} `
         + `(${(100 * probe.overCap / probe.n).toFixed(0)}%) reach more than two`);
  }

  head('a stub is one term over every completion, not a pick of two');
  {
    /* THE CLAIM OF STEP 73, STATED SO IT CAN FAIL. Three notes, three words
       sharing a prefix, one word each, chosen so the lengths differ. The old
       mechanism OR-ed in the two completions nearest in length, so the note
       holding the third word matched nothing and was not ranked low but
       absent. Scoring the prefix as a single term over the union reaches all
       three.

       Not asserted here, deliberately: that a lone five-character stub ranks
       what the whole word ranks. Measured at 40% top-5 both before and after,
       because a stub really is ambiguous — "cardi" is cardiac, cardiomyopathy
       and cardioversion — and a check demanding otherwise would be asserting
       something that should not be true. The prefix column above is where that
       outcome is measured, over whole half-typed titles, which is the query a
       fellow actually types. */
    const reach = await page.evaluate(() => {
      const WORDS = ['zylotropha', 'zylotrophin', 'zylotrophinase'];
      const added = WORDS.map((w, i) => ({
        id: 'stub-probe-' + i, title: 'Probe ' + i,
        body: w + ' is a word invented by a test.', tags: '', ts: Date.now() }));
      for (const a of added) REF.push(a);
      invalidateIndex();
      const hits = search('zylot', { limit: 10 })
        .filter(h => h.meta.kind === 'r').map(h => h.meta.id);
      const terms = stubTerms('zylot') || [];
      for (let i = 0; i < added.length; i++) REF.pop();
      invalidateIndex();
      return { hits, found: added.map(a => hits.includes(a.id)), terms };
    });
    ok('every note holding a word with that prefix is reached',
       reach.found.every(Boolean),
       `${reach.found.filter(Boolean).length}/3 found; stub covers ${reach.terms.length} terms`);
  }

  head('the word list cannot outlive the index it came from');
  {
    /* Two caches, one invalidation. A vocabulary that survives an index rebuild
       completes words that are no longer in the library. */
    /* Rebuilding on an UNCHANGED corpus proves nothing — the same vocabulary
       comes back either way. So the corpus changes: a note carrying a word
       that exists nowhere else, and a stub of it that could only complete
       against a word list built after the note arrived. */
    const after = await page.evaluate(() => {
      const NONCE = 'zylotrophin';                 // in no cardiology text ever
      const before = search('zylot', { limit: 5 }).length;
      REF.push({ id: 'nonce-probe', title: 'Probe ' + NONCE,
                 body: NONCE + ' is a word invented by a test.', tags: '', ts: Date.now() });
      const stale = search('zylot', { limit: 5 }).length;   // index not yet dropped
      invalidateIndex();
      const fresh = search('zylot', { limit: 5 })
        .filter(h => h.meta.kind === 'r').map(h => h.meta.id);
      REF.pop();
      invalidateIndex();
      const gone = search('zylot', { limit: 5 }).length;
      return { before, stale, fresh, gone };
    });
    ok('a stub of a word not in the library completes to nothing',
       after.before === 0, String(after.before));
    ok('and once the note exists and the index is dropped, it completes to it',
       after.fresh.includes('nonce-probe'), JSON.stringify(after.fresh));
    ok('and when the note goes, so does the word', after.gone === 0, String(after.gone));
  }

  head('the shape the tutor sends is the shape it is best at');
  /* The one comparison that decided against MiniSearch, kept as an assertion
     so it stays true: whatever changes, long prose queries must not become the
     engine's weak case, because that is what groundedContext sends on every
     grounded reply. */
  ok('long prose outranks half-typed titles, not the other way round',
     r.body.r1 > r.prefix.r1, `body ${pct(r.body.r1)} vs prefix ${pct(r.prefix.r1)}`);

  console.log(`\n  measured: exact ${pct(r.exact.r1)} · typo ${pct(r.typo.r1)} · ` +
              `prefix ${pct(r.prefix.r1)} · body ${pct(r.body.r1)}  (R@1)`);
  if (WHY) {
    console.log(`\n  why (counts only): ${r.notes} notes, ${r.bwNotes} of them Braunwald`);
    for (const k of ['exact', 'typo', 'prefix', 'body']) console.log(`    ${k.padEnd(6)} ${JSON.stringify(r[k].why)}`);
  }
  if (MISSES) for (const k of ['exact', 'typo', 'prefix', 'body']) {
    console.log(`\n  missed at R@1, ${k} (${r[k].missed.length}):`);
    for (const m of r[k].missed) console.log('    ' + m);
  }

  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch(died);
