#!/usr/bin/env node
/*
 * Behavioural checks for Gemini as a third provider.
 *
 *   NODE_PATH=$(npm root -g) node tests/verify-gemini.js /path/to/patched.html
 *
 * Gemini's wire shape is nothing like Mistral's, the app's other provider — a
 * top-level systemInstruction instead of a system message, roles 'user'/'model'
 * instead of 'user'/'assistant', images as inlineData instead of an image_url
 * block, tool results matched by name instead of by id. Getting any one of
 * those wrong is invisible until a real request 400s, so — same discipline as
 * verify-mistral for the other provider — this intercepts the actual outbound
 * request and inspects the JSON body rather than trusting that the code
 * "looks right".
 */
'use strict';
const path = require('path');
const { launch, isEngineNoise, routablePage } = require('./_engine');
const { booted, settled } = require('./_render.js');
const { onDeath } = require('./_deathnote.js');

const target = process.argv[2];
if (!target) { console.error('usage: node tests/verify-gemini.js <patched.html>'); process.exit(1); }
const URL = /^https?:\/\//.test(target) ? target : 'file://' + path.resolve(target);

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

/* One complete Gemini streamGenerateContent SSE reply: a text part, then a
   functionCall part, so a single stub covers both the plain-answer path and
   the tool-calling path without needing two different fixtures. */
const sseText = 'data: {"candidates":[{"content":{"role":"model","parts":[{"text":"The ECG shows atrial flutter."}]}}]}\n\n';
const sseCall = 'data: {"candidates":[{"content":{"role":"model","parts":[{"functionCall":{"name":"get_performance","args":{}}}]}}]}\n\n';
const sseFollowup = 'data: {"candidates":[{"content":{"role":"model","parts":[{"text":"You are weakest in Pericardial Disease."}]}}]}\n\n';

(async () => {
  const browser = await launch();
  const page = await routablePage(browser, { viewport: { width: 1280, height: 900 } });
  /* Hoisted so the death note can read them — this suite dies on WebKit
     against the served build, and the check that reports console errors is
     the one check a death never reaches. See tests/_deathnote.js. */
  const errors = [];
  const events = [];
  page.on('crash', () => events.push('the browser CRASHED the page'));
  page.on('close', () => events.push('the page closed'));
  page.on('requestfailed', r => {
    const why = (r.failure() || {}).errorText || '';
    if (why) events.push(`request failed: ${String(r.url()).slice(-50)} — ${why}`);
  });
  /* Installed once the arrays exist. A crash and a close are different
     diagnoses and Playwright reports both as "Target page, context or
     browser has been closed" on the next call; only the event says which. */
  onDeath(() => ({ section, checks: passed + failed, errors,
                   events: events.length ? events.join(', ') : 'none' }));
  page.on('pageerror', e => errors.push(e.message));
  /* The two deliberately-triggered error responses below (403, 429) log as
     browser-level resource-load failures regardless of how gracefully the
     app's own code handles them — that is Chromium's console, not a bug. */
  page.on('console', m => { if (m.type() === 'error' && !isEngineNoise(m.text())
      && !/Failed to load resource.*(403|404|429)/.test(m.text())) errors.push(m.text()); });

  /* A ListModels page shaped the way Google really sends one. The method list
     carries generateContent and countTokens and NOT streamGenerateContent —
     streaming is a variant of generateContent, not an advertised method. An
     earlier fixture invented that entry, the filter was written to require it,
     and the pair agreed with each other while rejecting every real model. A
     fixture that encodes the assumption under test proves nothing, so this one
     is deliberately faithful to the wire — see docs/BUILD.md, "A fixture is
     not evidence until it has been checked against reality", for the rule
     this incident (and two others) is what led to.

     Alongside the two usable models, the three kinds of thing that must still
     be rejected: an embedding model, an image model, and a TTS variant that
     does report generateContent but cannot hold a conversation. */
  const MODEL_LIST = {
    models: [
      { name: 'models/gemini-9.9-flash', displayName: 'Gemini 9.9 Flash',
        supportedGenerationMethods: ['generateContent', 'countTokens'] },
      { name: 'models/gemini-9.9-pro', displayName: 'Gemini 9.9 Pro',
        supportedGenerationMethods: ['generateContent', 'countTokens'] },
      { name: 'models/text-embedding-9', displayName: 'Text Embedding 9',
        supportedGenerationMethods: ['embedContent'] },
      { name: 'models/imagen-9', displayName: 'Imagen 9',
        supportedGenerationMethods: ['predict'] },
      { name: 'models/gemini-9.9-flash-tts', displayName: 'Gemini 9.9 Flash TTS',
        supportedGenerationMethods: ['generateContent', 'countTokens'] },
    ],
  };

  const captured = [];
  let turn = 0;
  let listBody = MODEL_LIST;            // swapped per-test to fake a starved key
  await page.route('**/generativelanguage.googleapis.com/**', route => {
    const url = route.request().url();
    let body = null;
    try { body = JSON.parse(route.request().postData() || '{}'); } catch (_) { /* GETs have none */ }
    captured.push({ url, method: route.request().method(), headers: route.request().headers(), body });
    /* ListModels is the collection itself — no ":method" suffix on the path. */
    if (/\/v1beta\/models(\?|$)/.test(url)) {
      route.fulfill({ status: 200, headers: { 'content-type': 'application/json' },
        body: JSON.stringify(listBody) });
      return;
    }
    if (/:generateContent(\?|$)/.test(url) && !/streamGenerateContent/.test(url)) {
      route.fulfill({ status: 200, headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ candidates: [{ content: { parts: [{ text: 'hi' }] } }] }) });
      return;
    }
    turn++;
    const sse = turn === 1 ? sseCall : sseFollowup;
    route.fulfill({ status: 200, headers: { 'content-type': 'text/event-stream' }, body: sse });
  });

  await page.goto(URL, { waitUntil: 'load', timeout: 200000 });
  await booted(page);
  await page.waitForTimeout(1200);

  head('provider is listed, free, and marked as seeing figures');
  const config = await page.evaluate(() => ({
    listed: PROVIDERS.some(p => p[0] === 'gemini'),
    models: (MODELS.gemini || []).map(m => m[0]),
    keyPrefix: KEY_PREFIX.gemini,
    sees: Vision.providerSeesFigures('gemini'),
    endpoint: ENDPOINT.gemini,
  }));
  ok('gemini is in PROVIDERS', config.listed);
  ok('the model menu has a placeholder before any key exists', config.models.length > 0, config.models.join(', '));
  ok('key prefix accepts both key generations Google has issued',
     Array.isArray(config.keyPrefix) && config.keyPrefix.includes('AQ.') && config.keyPrefix.includes('AIza'),
     JSON.stringify(config.keyPrefix));
  ok('Vision.providerSeesFigures says gemini can see a figure', config.sees === true);
  ok('endpoint points at the Generative Language API', /generativelanguage\.googleapis\.com/.test(config.endpoint || ''));

  head('a config naming a provider this build no longer has');
  /* THIS USED TO CHECK THE OPPOSITE. When Mistral was added, the risk was a
     stored config from BEFORE it existed; the check proved the app grew the
     missing slot on load. Mistral has since been removed, so the risk has
     inverted: a config written by the older build names a provider with no
     code path behind it, and "it has a slot" would happily keep it — leaving
     the tutor pointed at nothing.

     The self-heal runs once, at script load, so proving the APP repairs this
     (rather than the test doing it) means saving the stale shape and
     reloading, not hand-patching AI in the page and asserting on the patch. */
  await page.evaluate(() => {
    saveJSON(AI_CFG, { provider: 'mistral', mistral: { key: 'k', model: 'pixtral-large-latest' } });
  });
  await page.reload({ waitUntil: 'load', timeout: 200000 });
  await booted(page);
  await page.waitForTimeout(800);
  const repaired = await page.evaluate(() => {
    let threw = false;
    try { buildAI(); } catch (_) { threw = true; }
    return { provider: AI.provider, threw, known: !!AI_DEFAULT[AI.provider] };
  });
  ok('a stored provider this build cannot serve is healed to one it can',
     repaired.provider === 'gemini', `provider is ${repaired.provider}`);
  ok('and the healed provider is a real one', repaired.known);
  ok('opening the panel on it does not throw', !repaired.threw);

  head('key validation — the throwaway call is shaped right');
  await page.evaluate(async () => {
    AI.gemini = { key: 'AIzaFAKE-TEST-KEY', model: 'gemini-2.5-flash' };
    await validateKey('gemini', AI.gemini.key, AI.gemini.model);
  });
  const validateReq = captured.find(c => /:generateContent(\?|$)/.test(c.url) && !/streamGenerateContent/.test(c.url));
  ok('a validation request was made', !!validateReq);
  ok('the key rides in a header, not the URL', !!validateReq && !validateReq.url.includes('AIzaFAKE'),
     validateReq && validateReq.url);
  ok('the key header is x-goog-api-key', !!validateReq && validateReq.headers['x-goog-api-key'] === 'AIzaFAKE-TEST-KEY');
  captured.length = 0;

  /* Connect a key through the real setup screen. This is the whole fix: the
     model ids are not written into the build any more, they are whatever this
     key can actually reach. */
  const connect = async (key, picked) => {
    captured.length = 0;
    return page.evaluate(async ({ key, picked }) => {
      try { localStorage.removeItem('accsap12.gemini.models'); } catch (_) {}
      AI.gemini = { key: '', model: picked };
      AI.provider = 'gemini';
      aiSettings();
      document.querySelector('[data-prov="gemini"]').click();
      document.getElementById('aiKey').value = key;
      if (picked) {
        const sel = document.getElementById('aiModel');
        if ([...sel.options].some(o => o.value === picked)) sel.value = picked;
      }
      document.getElementById('aiSave').click();
      /* WAIT FOR THE ANSWER, NOT FOR A STOPWATCH. This was a flat 450ms, which
         is comfortably enough here and was not on the owner's laptop — a
         machine roughly half this one's speed, where the ListModels round trip
         had not landed and #keyMsg still read "Asking Google which models this
         key can use…". One check failed, for the message rather than for the
         behaviour: the fallback itself had already happened and every
         assertion around it passed.

         Still read BEFORE the success path's deferred buildAI() replaces the
         whole panel — polling every 40ms catches the settled message well
         inside that window — and still followed by a wait past that timer, so
         the next connect starts from a settled DOM rather than racing a
         pending re-render. */
      const settled = t => t && !/Asking Google/i.test(t);
      let msg = '', readFrom = null;
      const until = Date.now() + 8000;
      while (Date.now() < until) {
        const el = document.getElementById('keyMsg');
        const t = el ? el.textContent : '';
        if (settled(t)) { msg = t; readFrom = el; break; }
        await new Promise(r => setTimeout(r, 40));
      }
      /* Nothing settled in eight seconds. Reporting what IS there is not enough
         when what is there is nothing: an empty string makes ok()'s detail
         empty too, so the failure prints a bare label and the checks that
         assert ABSENCE — "does not report a false success" — pass vacuously
         beside it. That is what the owner's laptop showed: two failures with no
         detail at all, which says the message never arrived and says nothing
         about why. So the state is described rather than quoted. */
      if (!msg) {
        const el = document.getElementById('keyMsg');
        const raw = el ? el.textContent : null;
        msg = raw && raw.trim() ? raw
          : `(no message after 8s: #keyMsg ${el ? 'present but empty' : 'is not in the document'}`
            + `, panel ${document.getElementById('ai') ? 'open' : 'gone'})`;
      }
      /* LET THE DEFERRED RE-RENDER LAND BEFORE THE NEXT CONNECT STARTS — by
         waiting for it, not for a stopwatch. This was a flat 500ms, written
         when the success path deferred buildAI() by 450ms; mistral-patch later
         moved that timer to 700ms, so the "wait past that timer" stopped being
         one. The next connect then began inside the window, the old panel's
         re-render landed on top of it, and on the owner's laptop under a full
         run the starved-key check read "#keyMsg present but empty" for eight
         seconds — both of its message checks failing on a DOM the previous
         connect had torn down, not on anything the starved path did.

         Only the success path schedules a re-render. There, the #keyMsg read
         above is detached when buildAI() replaces the panel, so that is the
         precondition waited on. Capped, because a re-render that never
         detaches the element must not hang the suite: after the cap the
         700ms timer has long since fired either way. */
      if (/Connected/i.test(msg) && readFrom) {
        const cap = Date.now() + 4000;
        while (readFrom.isConnected && Date.now() < cap) await new Promise(r => setTimeout(r, 40));
      }
      let cached = null;
      try { cached = JSON.parse(localStorage.getItem('accsap12.gemini.models') || 'null'); } catch (_) {}
      return { msg, models: (MODELS.gemini || []).map(m => m[0]),
               chosen: AI.gemini.model, cached };
    }, { key, picked });
  };

  head('setup accepts the new AQ. key shape, not just the old AIza one');
  const aq = await connect('AQ.Ab8-FAKE-TEST-KEY-NOT-REAL-0000000000000000000000', 'gemini-2.5-flash');
  ok('a real AQ. key is not rejected as "a different kind of key"', !/different kind of key/i.test(aq.msg), aq.msg);

  head('Connect asks Google which models the key can reach');
  const listReq = captured.find(c => /\/v1beta\/models(\?|$)/.test(c.url));
  ok('a ListModels request was made', !!listReq, listReq && listReq.url);
  ok('it is a GET on the collection, not a generate call', !!listReq && listReq.method === 'GET');
  ok('it authenticates with the same x-goog-api-key header',
     !!listReq && /^AQ\./.test(listReq.headers['x-goog-api-key'] || ''));
  ok('no throwaway generateContent call is made — ListModels already proves the key',
     !captured.some(c => /:generateContent(\?|$)/.test(c.url) && !/streamGenerateContent/.test(c.url)));

  head('the discovered list replaces the built-in placeholder');
  /* The regression this suite exists for: a model that reports generateContent
     and countTokens — which is all Google ever reports — must be KEPT. */
  ok('a model that advertises generateContent alone is kept, because that is all Google advertises',
     aq.models.includes('gemini-9.9-flash') && aq.models.includes('gemini-9.9-pro'), aq.models.join(', '));
  ok('the embedding model was dropped', !aq.models.includes('text-embedding-9'));
  ok('the image model was dropped', !aq.models.includes('imagen-9'));
  ok('a TTS variant is dropped even though it reports generateContent',
     !aq.models.includes('gemini-9.9-flash-tts'));
  ok('the stale placeholder id is gone', !aq.models.includes('gemini-2.5-flash'), aq.models.join(', '));
  ok('a model the key does not have is not silently kept as the choice',
     aq.chosen !== 'gemini-2.5-flash', aq.chosen);
  ok('it fell back to a plain Flash rather than the first thing in the list',
     aq.chosen === 'gemini-9.9-flash', aq.chosen);
  ok('the fellow is told their pick was not available',
     /not on this key/i.test(aq.msg), aq.msg);
  ok('the list is cached so the menu is right on the next load',
     Array.isArray(aq.cached) && aq.cached.some(m => m[0] === 'gemini-9.9-flash'));

  head('a key with nothing usable shows its evidence, rather than blaming the project');
  listBody = { models: [{ name: 'models/text-embedding-9', displayName: 'Embedding',
                          supportedGenerationMethods: ['embedContent'] }] };
  const starved = await connect('AQ.Ab8-STARVED-KEY-0000000000000000000000000000', 'gemini-9.9-flash');
  ok('it does not report a false success', !/Connected/i.test(starved.msg), starved.msg);
  /* The first version asserted the project was misconfigured and sent people
     to a Cloud console billing prompt — while the real fault was this filter.
     Now it prints what Google returned, so the evidence is on screen. */
  ok('it names what Google actually returned', /text-embedding-9/.test(starved.msg), starved.msg);
  ok('it points at AI Studio, not at a billing account',
     /AI Studio/i.test(starved.msg) && !/billing account they/i.test(starved.msg), starved.msg);
  ok('it no longer blames the project outright', !/no chat-capable Gemini model enabled/i.test(starved.msg));
  listBody = MODEL_LIST;
  await connect('AQ.Ab8-FAKE-TEST-KEY-NOT-REAL-0000000000000000000000', 'gemini-9.9-flash');
  captured.length = 0;

  /* Drive one full exchange: fires a question with no figure of its own, but
     asks something generic enough that the model reaches for a tool — this
     exercises the request shape, the streamed reply, AND the tool round trip
     in a single pass. */
  const ask = async (wantFigure) => {
    captured.length = 0; turn = 0;
    await page.evaluate(async ({ wantFigure }) => {
      AI.provider = 'gemini';
      AI.gemini = { key: 'AIzaFAKE-TEST-KEY', model: 'gemini-2.5-flash' };
      const q = ALL_Q.find(x => !x.bad && (wantFigure ? (x.img > 0 && (IMGS[x.id] || []).length) : !x.img));
      jumpTo(q.id);
      const sh = document.getElementById('shell');
      if (!sh.classList.contains('ai-open')) toggleAI();
      buildAI();
      fire('where am I weak?');
    }, { wantFigure });
    for (let i = 0; i < 60 && captured.length < 2; i++) await page.waitForTimeout(100);
    await page.waitForTimeout(400);
    return captured;
  };

  head('the request Gemini actually receives');
  const toolsLen = await page.evaluate(() => TOOLS.length);
  const reqs = await ask(true);
  const first = reqs[0];
  ok('a request was made', !!first);
  ok('the system prompt is a top-level systemInstruction, not a message', !!first && !!first.body.systemInstruction,
     first && JSON.stringify(Object.keys(first.body || {})));
  ok('contents carries no system role', !!first && first.body.contents.every(c => c.role === 'user' || c.role === 'model'),
     first && first.body.contents.map(c => c.role).join(','));
  ok('the first turn is role "user", never "assistant"', !!first && first.body.contents[0].role === 'user');
  ok('tools are sent as functionDeclarations', !!first && Array.isArray(first.body.tools?.[0]?.functionDeclarations),
     first && JSON.stringify(first.body.tools).slice(0, 80));
  ok('every app tool made it into functionDeclarations', !!first &&
     first.body.tools[0].functionDeclarations.length === toolsLen,
     first && first.body.tools[0].functionDeclarations.length + ' vs ' + toolsLen);

  head('a figure rides as inlineData, not a source block');
  const parts = first ? first.body.contents[0].parts : [];
  const img = parts.find(p => p.inlineData);
  ok('an inlineData part is present for a question with a figure', !!img, JSON.stringify(parts.map(p => Object.keys(p))));
  ok('it carries a mimeType', !!img && /^image\//.test(img.inlineData.mimeType || ''), img && img.inlineData.mimeType);
  ok('its data is raw base64, no data: URL prefix', !!img && typeof img.inlineData.data === 'string' &&
     !img.inlineData.data.startsWith('data:') && img.inlineData.data.length > 100);
  ok('a text part is also present alongside the image', parts.some(p => typeof p.text === 'string' && p.text.length > 0));

  head('the tool round trip: functionCall out, functionResponse back, matched by name');
  ok('two requests were made — the call, then the follow-up with its result', reqs.length >= 2, reqs.length);
  const second = reqs[1];
  if (second) {
    const modelTurn = second.body.contents.find(c => c.role === 'model' && (c.parts || []).some(p => p.functionCall));
    const userTurn = second.body.contents.find(c => (c.parts || []).some(p => p.functionResponse));
    ok('the model\'s functionCall turn was pushed back', !!modelTurn);
    ok('a functionResponse turn follows it', !!userTurn);
    const fr = userTurn && userTurn.parts.find(p => p.functionResponse);
    ok('the functionResponse names the same function that was called', !!fr && fr.functionResponse.name === 'get_performance',
       fr && fr.functionResponse.name);
    ok('the functionResponse carries content, not an id (Gemini has no id to match)', !!fr && !!fr.functionResponse.response &&
       'content' in fr.functionResponse.response && fr.functionResponse.id === undefined);
  } else {
    ok('the model\'s functionCall turn was pushed back', false);
    ok('a functionResponse turn follows it', false);
    ok('the functionResponse names the same function that was called', false);
    ok('the functionResponse carries content, not an id (Gemini has no id to match)', false);
  }

  head('the thought signature goes back exactly as it came');
  /* Gemini 3 signs the parts of a turn that involved thinking and validates on
     the next request that the signature returned unchanged. Dropping it does
     not degrade the answer — it fails the call with HTTP 400, "Function call is
     missing a thought_signature in functionCall parts", and the conversation
     dies at the moment Apex reached for a tool. Which is exactly what happened
     on a real device. */
  {
    const sigReqs = [];
    let sigRound = 0;
    await page.unroute('**/v1beta/models/**:streamGenerateContent*').catch(() => {});
    await page.route('**/v1beta/models/**:streamGenerateContent*', route => {
      sigReqs.push(JSON.parse(route.request().postData() || '{}'));
      sigRound++;
      const ev = parts => parts.map(p =>
        'data: ' + JSON.stringify({ candidates: [{ content: { parts: [p] } }] }) + '\n\n').join('') + 'data: [DONE]\n\n';
      if (sigRound === 1) {
        return route.fulfill({ status: 200, headers: { 'content-type': 'text/event-stream' },
          body: ev([{ text: 'Saving that. ' },
                    { functionCall: { name: 'save_reference_note', args: { title: 'T', body: 'B' } },
                      thoughtSignature: 'SIG-ABC-123' }]) });
      }
      /* Round two enforces Google's rule rather than merely recording it: a
         missing or altered signature is answered the way the API answers it. */
      const model = (sigReqs[sigReqs.length - 1].contents || []).filter(c => c.role === 'model').pop();
      const fc = ((model && model.parts) || []).find(x => x.functionCall);
      if (!fc || fc.thoughtSignature !== 'SIG-ABC-123') {
        return route.fulfill({ status: 400, contentType: 'application/json', body: JSON.stringify({
          error: { message: 'Function call is missing a thought_signature in functionCall parts.' } }) });
      }
      return route.fulfill({ status: 200, headers: { 'content-type': 'text/event-stream' },
        body: ev([{ text: 'Signed and saved.' }]) });
    });

    const signed = await page.evaluate(async () => {
      CHATS['_general'] = []; S.screen = 'home';
      fire('save this');
      for (let i = 0; i < 90 && aiBusy; i++) await new Promise(r => setTimeout(r, 120));
      return CHATS['_general'].map(m => ({ err: !!m.err, text: String(m.content) }));
    });
    const back = (sigReqs[1] && (sigReqs[1].contents || []).filter(c => c.role === 'model').pop()) || null;
    const call = back && (back.parts || []).find(p => p.functionCall);
    ok('the signature is carried on the functionCall part it arrived with',
       !!call && call.thoughtSignature === 'SIG-ABC-123', call && call.thoughtSignature);
    ok('so the follow-up is accepted rather than 400ing',
       signed.some(m => !m.err && /Signed and saved/.test(m.text)) && !signed.some(m => m.err),
       signed.map(m => (m.err ? 'ERR:' : '') + m.text.slice(0, 40)).join(' | '));

    /* And a floor under it: an unsigned call must not be fatal. Google
       publishes an opt-out token for calls it did not generate. */
    sigReqs.length = 0; sigRound = 0;
    await page.unroute('**/v1beta/models/**:streamGenerateContent*');
    await page.route('**/v1beta/models/**:streamGenerateContent*', route => {
      sigReqs.push(JSON.parse(route.request().postData() || '{}'));
      sigRound++;
      const ev = parts => parts.map(p =>
        'data: ' + JSON.stringify({ candidates: [{ content: { parts: [p] } }] }) + '\n\n').join('') + 'data: [DONE]\n\n';
      if (sigRound === 1) return route.fulfill({ status: 200, headers: { 'content-type': 'text/event-stream' },
        body: ev([{ functionCall: { name: 'get_performance', args: {} } }]) });
      return route.fulfill({ status: 200, headers: { 'content-type': 'text/event-stream' },
        body: ev([{ text: 'ok.' }]) });
    });
    await page.evaluate(async () => {
      CHATS['_general'] = []; fire('again');
      for (let i = 0; i < 90 && aiBusy; i++) await new Promise(r => setTimeout(r, 120));
    });
    const b2 = (sigReqs[1] && (sigReqs[1].contents || []).filter(c => c.role === 'model').pop()) || null;
    const c2 = b2 && (b2.parts || []).find(p => p.functionCall);
    ok('an unsigned call falls back to the documented opt-out, not to a 400',
       !!c2 && c2.thoughtSignature === 'skip_thought_signature_validator', c2 && c2.thoughtSignature);

    /* A signature can arrive in a chunk of its own, after the part it belongs
       to. It must attach backwards, not be dropped. */
    sigReqs.length = 0; sigRound = 0;
    await page.unroute('**/v1beta/models/**:streamGenerateContent*');
    await page.route('**/v1beta/models/**:streamGenerateContent*', route => {
      sigReqs.push(JSON.parse(route.request().postData() || '{}'));
      sigRound++;
      const ev = parts => parts.map(p =>
        'data: ' + JSON.stringify({ candidates: [{ content: { parts: [p] } }] }) + '\n\n').join('') + 'data: [DONE]\n\n';
      if (sigRound === 1) return route.fulfill({ status: 200, headers: { 'content-type': 'text/event-stream' },
        body: ev([{ functionCall: { name: 'get_performance', args: {} } }, { thoughtSignature: 'LATE-SIG' }]) });
      return route.fulfill({ status: 200, headers: { 'content-type': 'text/event-stream' },
        body: ev([{ text: 'ok.' }]) });
    });
    await page.evaluate(async () => {
      CHATS['_general'] = []; fire('once more');
      for (let i = 0; i < 90 && aiBusy; i++) await new Promise(r => setTimeout(r, 120));
    });
    const b3 = (sigReqs[1] && (sigReqs[1].contents || []).filter(c => c.role === 'model').pop()) || null;
    const c3 = b3 && (b3.parts || []).find(p => p.functionCall);
    ok('a signature arriving in its own chunk attaches to the part before it',
       !!c3 && c3.thoughtSignature === 'LATE-SIG', c3 && c3.thoughtSignature);
  }

  head('the streamed reply reaches the chat');
  const chatText = await page.evaluate(() => {
    const hist = CHATS[ALL_Q.find(x => !x.bad && x.img > 0).id] || CHATS['_general'] || [];
    return hist.map(m => m.content).join(' | ');
  });
  ok('the follow-up text made it into chat history', /weakest in Pericardial/.test(chatText), chatText.slice(-120));

  head('errors, in Gemini\'s own words');
  await page.route('**/generativelanguage.googleapis.com/**', route => {
    route.fulfill({ status: 403, headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ error: { message: 'API key not valid. Please pass a valid API key.' } }) });
  }, { times: 1 });
  const badKeyMsg = await page.evaluate(async () => {
    const r = await fetch(`${ENDPOINT.gemini}/gemini-2.5-flash:generateContent`, {
      method: 'POST', headers: { 'x-goog-api-key': 'bad' }, body: '{}' });
    return apiError(r, 'gemini');
  });
  ok('a 403 reads as a rejected key, not a raw status code', /rejected/i.test(badKeyMsg), badKeyMsg);

  /* Hosted, no key typed: the call went to this site's /api/apex/gemini/, and
     the Worker refused it (here, Access not configured — its real wording).
     There is no key to re-enter, so the Worker's own reason is what is shown.
     The Response is made in the page and given the URL a hosted fetch has:
     a file: page cannot fetch its own site, and the URL is all apiError reads. */
  const relayMsg = await page.evaluate(async () => {
    const r = new Response(JSON.stringify({ error: { message: 'This deployment cannot check who is asking: ACCESS_TEAM_DOMAIN and ACCESS_AUD are not set.' } }),
      { status: 403, headers: { 'content-type': 'application/json' } });
    Object.defineProperty(r, 'url', { value: 'https://systole.pages.dev/api/apex/gemini/stream?model=gemini-9.9-flash' });
    return apiError(r, 'gemini');
  });
  ok('a 403 from this site\'s relay says what the site said, not "re-enter your key"',
     /ACCESS_TEAM_DOMAIN and ACCESS_AUD/.test(relayMsg) && !/re-enter/i.test(relayMsg), relayMsg);

  await page.route('**/generativelanguage.googleapis.com/**', route => {
    route.fulfill({ status: 429, headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ error: { message: 'You exceeded your current quota, please check your plan.' } }) });
  }, { times: 1 });
  const quotaMsg = await page.evaluate(async () => {
    const r = await fetch(`${ENDPOINT.gemini}/gemini-2.5-flash:generateContent`, {
      method: 'POST', headers: { 'x-goog-api-key': 'bad' }, body: '{}' });
    return apiError(r, 'gemini');
  });
  ok('an unspecified quota does not invent a daily reset', /quota/i.test(quotaMsg) && !/tomorrow|daily/i.test(quotaMsg), quotaMsg);

  await page.route('**/generativelanguage.googleapis.com/**', route => {
    route.fulfill({ status: 404, headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ error: { message: 'models/gemini-1.0-pro is not found for API version v1beta' } }) });
  }, { times: 1 });
  const goneMsg = await page.evaluate(async () => {
    const r = await fetch(`${ENDPOINT.gemini}/gemini-1.0-pro:generateContent`, {
      method: 'POST', headers: { 'x-goog-api-key': 'x' }, body: '{}' });
    return apiError(r, 'gemini');
  });
  /* The old text sent you to a menu in which every name was equally dead. */
  ok('a retired model points at Connect, not at the model menu',
     /Connect/.test(goneMsg) && !/pick a different one in settings/i.test(goneMsg), goneMsg);

  head('actionable quota and permission guidance');
  const guidance=await page.evaluate(async()=>{
    const get=async(status,message,details=[],hosted=false)=>{
      const r=new Response(JSON.stringify({error:{message,details}}),{status});
      if(hosted) Object.defineProperty(r,'url',{value:'https://study.example/api/apex/gemini/stream'});
      return apiError(r,'gemini');
    };
    return {
      permission:await get(403,'Permission denied'),
      daily:await get(429,'Quota exceeded',[{'@type':'type.googleapis.com/google.rpc.QuotaFailure',violations:[{quotaId:'GenerateRequestsPerDay'}]}]),
      wait:await get(429,'Quota exceeded',[{'@type':'type.googleapis.com/google.rpc.RetryInfo',retryDelay:'45s'}]),
      credit:await get(402,'Payment required'),
      relay:await get(503,'This deployment has no GEMINI_API_KEY set.',[],true),
      site:await get(429,'Too many requests in a minute — wait a moment and try again.',[],true)
    };
  });
  ok('permission failures explain project restrictions rather than reject every key',/restrictions/.test(guidance.permission)&&!/key was rejected/.test(guidance.permission));
  ok('structured daily quotas explain Pacific reset and shared project allowance',/midnight Pacific/.test(guidance.daily)&&/same project/.test(guidance.daily));
  ok('provider retry delay is preserved in the guidance',/45 seconds/.test(guidance.wait));
  ok('payment failures explain balance and spending limits',/prepaid balance/.test(guidance.credit)&&/spending limits/.test(guidance.credit));
  ok('relay configuration failures identify the hosted service',/relay needs attention/.test(guidance.relay)&&!/temporarily unavailable/.test(guidance.relay));
  ok('site throttling is distinct from Google quota',/site’s request limit/.test(guidance.site));

  head('transient overload recovery without replaying a stream');
  const retryCases = await page.evaluate(async () => {
    const saved = window.fetch, results = {};
    const send = typeof geminiFetch === 'function' ? geminiFetch : (...args) => fetch(...args);
    const response = (status, message, retry) => new Response(JSON.stringify({error:{message}}), {
      status, headers:{'content-type':'application/json', ...(retry == null ? {} : {'retry-after':retry})}
    });
    async function trial(name, replies, onRetry) {
      let calls=0; const bodies=[]; const ctl=new AbortController();
      window.fetch=async (url,init) => { bodies.push(init.body); return replies[Math.min(calls++,replies.length-1)](); };
      try {
        const r=await send('https://example.invalid/gemini', {method:'POST',body:'same request',signal:ctl.signal},
          onRetry ? () => ctl.abort() : undefined);
        results[name]={calls,status:r.status,body:await r.text(),same:bodies.every(b=>b==='same request')};
      } catch(e) { results[name]={calls,error:e.name,message:e.message}; }
    }
    try {
      await trial('recover',[()=>response(503,'overloaded','0'),()=>new Response('answer')]);
      await trial('bounded',[()=>response(503,'still overloaded','0')]);
      await trial('auth',[()=>response(403,'key rejected')]);
      await trial('daily',[()=>response(429,'GenerateRequestsPerDay quota exhausted','0')]);
      await trial('rate',[()=>response(429,'requests per minute','0'),()=>new Response('answer')]);
      await trial('long',[()=>response(503,'busy','120')]);
      await trial('cancel',[()=>response(503,'busy','0')],true);
      const brokenBody=()=>new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode('partial'));c.error(new Error('stream lost'));}}));
      // WebKit and Chromium expose different native errors for this stream.
      // Measure the fixture directly, then require unchanged propagation and
      // exactly one fetch through the helper. An accepted error-name list
      // would miss a helper that substituted its own error.
      try { await brokenBody().text(); }
      catch(e) { results.bodyError={error:e.name,message:e.message}; }
      await trial('partial',[brokenBody]);
    } finally { window.fetch=saved; }
    return results;
  });
  ok('an overload recovers before streaming, with the identical request body', retryCases.recover.calls===2 && retryCases.recover.body==='answer' && retryCases.recover.same);
  ok('persistent overload is bounded to three attempts and preserves the final error', retryCases.bounded.calls===3 && retryCases.bounded.status===503 && /still overloaded/.test(retryCases.bounded.body));
  ok('a rejected key is never retried', retryCases.auth.calls===1 && retryCases.auth.status===403);
  ok('an exhausted daily quota is never retried, even with Retry-After', retryCases.daily.calls===1 && retryCases.daily.status===429);
  ok('a short rate limit with Retry-After recovers', retryCases.rate.calls===2 && retryCases.rate.status===200);
  ok('a long retry delay is returned to the caller rather than shortened', retryCases.long.calls===1 && retryCases.long.status===503);
  ok('Stop during backoff aborts without a second request', retryCases.cancel.calls===1 && retryCases.cancel.error==='AbortError');
  ok('a failed response body is never replayed', retryCases.partial.calls===1
     && !!retryCases.bodyError?.error && retryCases.partial.error===retryCases.bodyError.error
     && retryCases.partial.message===retryCases.bodyError.message, JSON.stringify(retryCases.partial));

  head('explicit explanation uses one evidence-backed turn');
  await page.evaluate(()=>{
    window.explainProbe={saved:window.fetch,savedRun:runTool,requests:[],actions:0};
    const requests=window.explainProbe.requests;
    AI.provider='gemini'; AI.gemini.key='synthetic-key'; S.screen='home';AI_GROUNDED=true;
    REF.push({id:'explain-fixture',title:'Fictional omega protocol',body:'Omega protocol uses an amber marker.',tags:'omega'});invalidateIndex();
    CHATS._general=[];buildAI();
    window.fetch=async(url,init)=>{
      requests.push(JSON.parse(init.body));
      return new Response('data: '+JSON.stringify({candidates:[{content:{parts:[{text:'The fictional protocol uses amber.'}]}}]})+'\n\n',{headers:{'content-type':'text/event-stream'}});
    };
    document.getElementById('aiIn').value='Explain omega protocol';
      const button=document.querySelector('[data-chip="explain"]');
      if(button) button.click(); else fire('Explain omega protocol',true);
      window.explainProbe.button=!!button;
  });
  await settled(page,()=>!aiBusy,{label:'explanation finishes'});
  await page.evaluate(()=>{
      const requests=window.explainProbe.requests;
      runTool=()=>{window.explainProbe.actions++;return {result:'unexpected'};};
      window.fetch=async(url,init)=>{
        requests.push(JSON.parse(init.body));
        return new Response('data: '+JSON.stringify({candidates:[{content:{parts:[{functionCall:{name:'get_performance',args:{}}}]}}]})+'\n\n',{headers:{'content-type':'text/event-stream'}});
      };
      fire('Explain omega again',true);
  });
  await settled(page,()=>!aiBusy,{label:'unexpected explanation tool call finishes'});
  const explanation=await page.evaluate(()=>{
    const p=window.explainProbe;
    window.fetch=p.saved;runTool=p.savedRun;REF=REF.filter(r=>r.id!=='explain-fixture');invalidateIndex();
    return {button:p.button,first:p.requests[0],count:p.requests.length,actions:p.actions,notice:CHATS._general.some(m=>m.err&&/cannot run study tools/.test(m.content))};
  });
  ok('Explain draft is explicit and omits tool declarations',explanation.button&&!!explanation.first&&!explanation.first.tools);
  ok('explanation retains retrieved note evidence and grounding instruction',JSON.stringify(explanation.first).includes('Omega protocol uses an amber marker.')&&JSON.stringify(explanation.first).includes('supplied evidence is insufficient'));
  ok('unexpected tool calls cannot act or cause follow-up requests in explanation mode',explanation.count===2&&explanation.actions===0&&explanation.notice);

  head('session explanation reuse is exact and complete');
  const reuse=await page.evaluate(async()=>{
    const saved=window.fetch, savedRefs=REF, results={};let calls=0,finish='STOP';
    REF=[{id:'cache-fixture',title:'Synthetic marker',body:'Amber marker'}];invalidateIndex();
    if(typeof apexExplanationCache!=='undefined') apexExplanationCache.clear();
    window.fetch=async()=>{calls++;return new Response('data: '+JSON.stringify({candidates:[{finishReason:finish,content:{parts:[{text:'Synthetic complete explanation'}]}}]})+'\n\n',{headers:{'content-type':'text/event-stream'}});};
    aiAbort=new AbortController();lastHits=[];
    const wire=[{role:'user',content:'Explain the fictional marker'}];
    const ask=async(normal=false)=>{refFenceRoll();return oneTurnGemini(null,wire,refBlock('NOTE','title: synthetic','Amber marker'),!normal);};
    try{
      await ask();const repeated=await ask();results.hit=calls===1&&repeated.reused===true;
      REF.push({id:'cache-change',title:'Changed evidence',body:'New qualification'});
      await ask();results.source=calls===2;REF.pop();
      const model=cur().model;cur().model=model+'-different';await ask();results.model=calls===3;cur().model=model;
      await ask(true);await ask(true);results.normal=calls===5;
      wire[0].content='Another explanation';finish='MAX_TOKENS';await ask();await ask();results.incomplete=calls===7;
      if(typeof apexExplanationCache!=='undefined'){
        for(const entry of apexExplanationCache.values()) entry.at=Date.now()-16*60*1000;
        wire[0].content='Explain the fictional marker';finish='STOP';await ask();results.expired=calls===8;
      }
      return results;
    }finally{window.fetch=saved;REF=savedRefs;invalidateIndex();aiAbort=null;if(typeof apexExplanationCache!=='undefined')apexExplanationCache.clear();}
  });
  ok('identical explanations reuse despite fresh evidence fences',reuse.hit);
  ok('source changes invalidate explanation reuse',reuse.hit&&reuse.source);
  ok('model changes invalidate explanation reuse',reuse.hit&&reuse.model);
  ok('normal Send bypasses explanation reuse',reuse.hit&&reuse.normal);
  ok('incomplete answers are never reused',reuse.hit&&reuse.incomplete);
  ok('expired explanations require a new provider request',reuse.expired);

  head('explanation authentication stays with its cache identity');
  const connection=await page.evaluate(async()=>{
    const savedFetch=window.fetch,savedKey=cur().key,savedIdentity=explanationKey;
    let release,entered,request=null;
    const paused=new Promise(resolve=>{entered=resolve;});
    const gate=new Promise(resolve=>{release=resolve;});
    apexExplanationCache.clear();aiAbort=new AbortController();lastHits=[];
    cur().key='synthetic-original-credential';
    explanationKey=async body=>{const key=await savedIdentity(body);entered();await gate;return key;};
    window.fetch=async(url,init)=>{
      request={url:String(url),key:init.headers['x-goog-api-key']||''};
      return new Response('data: '+JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text:'Synthetic response'}]}}]})+'\n\n',{headers:{'content-type':'text/event-stream'}});
    };
    try{
      const turn=oneTurnGemini(null,[{role:'user',content:'Explain the credential fixture'}],'',true);
      await paused;
      // Removing a personal key in Settings is allowed while a turn is busy.
      cur().key='';release();await turn;
      return request;
    }finally{
      release();window.fetch=savedFetch;cur().key=savedKey;explanationKey=savedIdentity;
      aiAbort=null;apexExplanationCache.clear();
    }
  });
  ok('a key removed during hashing cannot switch the in-flight explanation to another route',
     !!connection&&connection.key==='synthetic-original-credential'&&connection.url.includes('generativelanguage.googleapis.com'));

  head('large reference libraries retain exact cache identity');
  const largeLibrary=await page.evaluate(async()=>{
    const saved=REF;
    try{
      REF=[{id:'large-fictional',title:'Invented reference',body:'Fictional background. '.repeat(110000)}];
      const first=await explanationKey('small request');
      REF[0].body+=' A final qualification.';
      const changed=await explanationKey('small request');
      return typeof first==='string'&&first.length===64&&typeof changed==='string'&&changed!==first;
    }finally{REF=saved;}
  });
  ok('a library larger than the request cap hashes completely and source edits invalidate it',largeLibrary);

  head('incomplete explanations are disclosed');
  const completion=await page.evaluate(async()=>{
    const saved=window.fetch;let reason='MAX_TOKENS';
    window.fetch=async()=>new Response('data: '+JSON.stringify({candidates:[{finishReason:reason,content:{parts:[{text:'Synthetic explanation fragment'}]}}]})+'\n\n',{headers:{'content-type':'text/event-stream'}});
    try{
      S.screen='home';
      const hist=[{role:'user',content:'Explain the invented marker'}];CHATS._general=hist;aiBusy=true;
      await streamReply(null,hist,'',true);
      const warned=hist.some(m=>m.incomplete===true)&&/output limit/.test(document.getElementById('ai').textContent);
      const kept=hist.some(m=>!m.err&&m.role==='assistant'&&m.content==='Synthetic explanation fragment');
      reason='STOP';const whole=[{role:'user',content:'A different invented marker'}];CHATS._general=whole;aiBusy=true;
      await streamReply(null,whole,'',true);
      return {warned,kept,clean:!whole.some(m=>m.err)};
    }finally{window.fetch=saved;}
  });
  ok('output-limit replies retain their text with a notice while complete replies remain clean',completion.warned&&completion.kept&&completion.clean);

  head('regression');
  ok('no console/page errors across the whole run', errors.length === 0, errors.slice(0, 3).join(' | '));

  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
