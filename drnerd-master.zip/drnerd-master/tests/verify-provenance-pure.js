#!/usr/bin/env node
/*
 * A split build says which build it is, and refuses to be half of two.
 *
 *   node tests/verify-provenance-pure.js
 *
 * No browser, no build, no licensed export — this reads scripts/build-pwa.js
 * and scripts/extract-content.js as text and drives the one function that can
 * be lifted out.
 *
 * ── WHAT THIS IS ABOUT ────────────────────────────────────────────────────
 *
 * The split build is assembled from TWO inputs that are produced by two
 * different commands:
 *
 *     scripts/assemble-app.js     → build/systole.html  (npm run build)
 *     scripts/extract-content.js  → content/            (from that html)
 *     scripts/build-pwa.js        → dist/               (from both)
 *
 * build-pwa.js used to check only that content/ EXISTED. So rebuilding
 * build/systole.html and splitting it again — without re-running the extract
 * in between — produced a dist/ whose index.html and app.js were the new
 * build and whose questions.json and 408 figures were the old one.
 *
 * AND EVERY GUARD DOWNSTREAM STILL AGREED. BUILD_ID is computed fresh in the
 * split run and stamped into all three files, so verify-pwa's "all three are
 * the same build" passes on a dist/ whose bank is from a different extraction
 * entirely. That is the shape this repository keeps producing: green that
 * covers the paragraph beside the one with the hole in it.
 *
 * docs/IPAD.md printed exactly that two-command sequence. It is right on a
 * clean checkout, where content/ does not exist yet, and wrong every time
 * after.
 *
 * ── AND WHICH COMMIT ──────────────────────────────────────────────────────
 *
 * BUILD_ID is a digest. It answers "are these files from the same deploy?"
 * and cannot answer "which commit do I open to see what is in this?". Three
 * months after a deploy that is the question. It was recorded only in
 * build/release-report.md — gitignored, never uploaded, on one laptop.
 *
 * ── WHAT THIS SUITE CANNOT CHECK ──────────────────────────────────────────
 *
 * That the stamps arrive in a real dist/. That needs a build and a server,
 * and tests/verify-pwa.js is where it is checked. The division is the same
 * one tests/verify-loader-pure.js documents: the arithmetic here, the wiring
 * there.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
const head = t => console.log('\n── ' + t + ' ──');

const ROOT = path.join(__dirname, '..');
const PWA = fs.readFileSync(path.join(ROOT, 'scripts', 'build-pwa.js'), 'utf8');
const EXTRACT = fs.readFileSync(path.join(ROOT, 'scripts', 'extract-content.js'), 'utf8');
/* The comment-blanked copy, for scans that must not read the explanations. */
const { blankComments } = require('./_source.js');
const EXTRACT_CODE = blankComments(EXTRACT);

/* Lifted, not copied: a copy here would stop matching build-pwa.js the first
   time either changed, and would go on passing. `crypto` is passed in because
   new Function() has no require. */
function lift(src, name) {
  const at = src.indexOf('function ' + name + '(');
  if (at < 0) throw new Error(`scripts/build-pwa.js no longer defines ${name}()`);
  let depth = 0, end = -1;
  for (let k = src.indexOf('{', at); k < src.length; k++) {
    if (src[k] === '{') depth++;
    else if (src[k] === '}') { depth--; if (!depth) { end = k + 1; break; } }
  }
  if (end < 0) throw new Error(`could not find the end of ${name}()`);
  /* eslint-disable-next-line no-new-func */
  return new Function('crypto', `${src.slice(at, end)}\nreturn ${name};`)(crypto);
}

const staleContent = lift(PWA, 'staleContent');

head('the function under test is the one that ships');
{
  ok('staleContent was lifted out of build-pwa.js', typeof staleContent === 'function');
  /* It has to be CALLED, and called before the split does any work — a check
     that exists and is never reached is the "passes without measuring"
     failure with one more step in front of it. */
  ok('build-pwa.js calls it', /const stale = staleContent\(SRC_DIGEST, contentManifest\)/.test(PWA));
  ok('and exits non-zero when it answers', /if \(stale\) \{ console\.error\(stale\); process\.exit\(1\); \}/.test(PWA));
  /* BEFORE ANY WORK, or the refusal arrives after an hour of it — and after
     dist/ has already been deleted, which is the part that stings.

     THE FIRST VERSION OF THIS compared the call against `const OPEN =`, the
     declaration that opens the split. That is a few lines below the check and
     a long way above anything that MUTATES, so an injection that moved the
     check down to just above it passed — it looked like a check that could
     not fail, and it very nearly was one. The boundary that matters is the
     first assignment to `html`, so that is what is measured. */
  const callAt = PWA.indexOf('const stale = staleContent(');
  const mutAt = PWA.search(/^html = html\./m);
  const rmAt = PWA.indexOf('fs.rmSync(DIST');
  ok('before the first change to the document', callAt > 0 && mutAt > 0 && callAt < mutAt,
     `check@${callAt} first mutation@${mutAt}`);
  ok('and before dist/ is deleted, so a refusal costs nothing',
     callAt > 0 && rmAt > 0 && callAt < rmAt, `check@${callAt} rm@${rmAt}`);
}

head('a stale content/ is refused, and a matching one is not');
{
  ok('the same digest passes', staleContent('abcdef0123456789', { sourceDigest: 'abcdef0123456789' }) === null);
  const diff = staleContent('abcdef0123456789', { sourceDigest: '0000000000000000' });
  ok('a different digest is refused', typeof diff === 'string' && diff.length > 0);
  ok('and the refusal names both, so it can be believed',
     /abcdef0123456789/.test(diff) && /0000000000000000/.test(diff), String(diff).slice(0, 80));
  ok('and says which command fixes it', /extract-content\.js/.test(diff));
  /* A one-character difference is a different build. Checked explicitly
     because "!==" and "does not start with" look the same in a passing test. */
  ok('one character is enough',
     typeof staleContent('abcdef0123456789', { sourceDigest: 'abcdef012345678a' }) === 'string');
  /* A manifest from before this field existed must not read as a match. */
  ok('a manifest with no sourceDigest is refused, not shrugged at',
     typeof staleContent('abcdef0123456789', {}) === 'string');
  ok('and so is no manifest at all', typeof staleContent('abcdef0123456789', null) === 'string');
  /* THE ONE THAT MATTERS MOST. undefined === undefined is true, and a probe
     comparing two absent values is this repository's most-repeated defect. */
  ok('two absent digests do not compare equal',
     typeof staleContent(undefined, { sourceDigest: undefined }) === 'string');
}

head('the digest compared is the digest extract-content writes');
{
  /* Two files, one number. If either side changes how it hashes — the
     algorithm, the encoding, the slice — the comparison silently becomes
     "never equal", and every split build would refuse. So the shapes are
     held to each other rather than to a literal written here twice. */
  const shapeOf = src => {
    const m = /createHash\('(\w+)'\)\s*[\s\S]{0,120}?\.digest\('hex'\)\.slice\(0, (\d+)\)/.exec(src);
    return m ? m[1] + '/' + m[2] : null;
  };
  const a = shapeOf(EXTRACT), b = shapeOf(PWA.slice(PWA.indexOf('const SRC_DIGEST')));
  ok('extract-content hashes the source', !!a, a || 'not found');
  ok('build-pwa hashes it the same way', !!b && a === b, `${a} vs ${b}`);
  /* And over the file on disk, not over the half-split `html` variable. */
  ok('build-pwa hashes the file, not the variable it is about to cut up',
     /const SRC_DIGEST = crypto\.createHash\('sha256'\)\s*\n\s*\.update\(fs\.readFileSync\(SRC\)\)/.test(PWA));

  /* AND THE TWO REALLY DO AGREE ON THE SAME FILE, measured by running them.
     The shapes above match the algorithm and the slice and nothing else: the
     same pattern holds for `update(html)` over the decoded text, and that
     is what extract-content did while build-pwa hashed the raw bytes. On
     valid UTF-8 the two agree; on a file with a byte that is not (0x92, a
     Windows-1252 apostrophe, the shape an export pasted from Word takes)
     decoding replaces it with U+FFFD, the digests part, and build-pwa
     refuses content/ that was extracted from the very file it is splitting.
     (This replaced a check that handed one digest to staleContent() as both
     arguments, which could not fail.)

     So: a small synthetic build with a 0x92 byte appended, extracted by
     scripts/extract-content.js itself, and build-pwa's own SRC_DIGEST
     expression evaluated over the same file. */
  const os = require('os');
  const { spawnSync } = require('child_process');
  const Assemble = require(path.join(ROOT, 'scripts', 'assemble-app.js'));
  const Syn = require(path.join(ROOT, 'scripts', 'synthetic-export.js'));
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'provenance-'));
  try {
    /* The notes in the temporary folder too: left to its defaults the
       assembler reads content/refs, the licensed library. */
    const refsDir = path.join(tmp, 'refs'), imagesDir = path.join(tmp, 'refs-images');
    fs.mkdirSync(refsDir); fs.mkdirSync(imagesDir);
    const lib = Syn.syntheticRefs(1);
    for (const [n, t] of lib.files) fs.writeFileSync(path.join(refsDir, n), t);
    for (const [k, b] of lib.images) fs.writeFileSync(path.join(imagesDir, k), b);
    const shell = fs.readFileSync(path.join(ROOT, 'app', 'systole.html'), 'utf8');
    const resolve = Assemble.producers({ exportHtml: Syn.syntheticExport(2), refsDir, imagesDir });
    const built = Buffer.from(Assemble.assembleApp({ shell, resolve, commit: 'abc123def456' }).out, 'utf8');
    const src = path.join(tmp, 'systole.html');
    fs.writeFileSync(src, Buffer.concat([built, Buffer.from('<!-- it'), Buffer.from([0x92]), Buffer.from('s -->\n')]));
    const raw = fs.readFileSync(src);
    ok('the fixture carries a byte that is not UTF-8', raw.includes(0x92) && !raw.equals(Buffer.from(raw.toString('utf8'), 'utf8')));

    const x = spawnSync(process.execPath, [path.join(ROOT, 'scripts', 'extract-content.js'), src, path.join(tmp, 'content')], { encoding: 'utf8' });
    ok('extract-content extracted it', x.status === 0, `exit ${x.status}`);
    let written = null;
    try { written = JSON.parse(fs.readFileSync(path.join(tmp, 'content', 'manifest.json'), 'utf8')).sourceDigest; } catch (_) {}

    /* build-pwa's expression, found in the code rather than its comments and
       evaluated as written, over the same file. */
    const m = /const SRC_DIGEST = (crypto\.createHash\([\s\S]*?\.slice\(0, 16\));/.exec(blankComments(PWA));
    let computed = null;
    if (m) computed = new Function('crypto', 'fs', 'SRC', 'return ' + PWA.slice(m.index + m[0].indexOf(m[1]), m.index + m[0].indexOf(m[1]) + m[1].length) + ';')(crypto, fs, src);
    ok('build-pwa\'s SRC_DIGEST expression was found and ran', /^[0-9a-f]{16}$/.test(String(computed)), String(computed));
    ok('and extract-content wrote the digest build-pwa computes for that file',
       /^[0-9a-f]{16}$/.test(String(written)) && staleContent(computed, { sourceDigest: written }) === null,
       `content ${written} / build ${computed}`);
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

head('the one-command split build runs the extract it depends on');
{
  /* THE GATE ABOVE MADE THIS VISIBLE. `npm run pwa` was
   *
   *     node scripts/build-pwa.js build/systole.html
   *
   * with no extract step — the same two-command sequence docs/IPAD.md used
   * to print, and the one staleContent() now refuses. Since the refusal is
   * loud, the script no longer produces a mixed dist/; what it still did was
   * TEACH the wrong sequence, from package.json, which is the first place
   * anyone looks for how to build. The docs were corrected and this was not.
   *
   * Order is the whole property: build-pwa reads content/ at its very first
   * lines, so an extract that ran afterwards would be a rebuild of the thing
   * already consumed. */
  const pkg = JSON.parse(require('fs').readFileSync(require('path').join(ROOT, 'package.json'), 'utf8'));
  const pwa = (pkg.scripts || {}).pwa || '';
  ok('npm run pwa exists', !!pwa, pwa || 'absent');
  ok('it extracts the content', /scripts\/extract-content\.js/.test(pwa), pwa);
  ok('and it splits the build', /scripts\/build-pwa\.js/.test(pwa), pwa);
  ok('in that order, since build-pwa reads content/ before it does anything else',
     pwa.indexOf('extract-content.js') >= 0
     && pwa.indexOf('extract-content.js') < pwa.indexOf('build-pwa.js'), pwa);
  /* Both halves read the SAME file, or the freshness check is being handed
     two different builds on purpose. */
  const args = [...pwa.matchAll(/scripts\/(?:extract-content|build-pwa)\.js\s+(\S+)/g)].map(m => m[1]);
  ok('both halves are given the same build to work from',
     args.length === 2 && args[0] === args[1], args.join(' vs ') || 'not found');
}

head('the artifact names the commit that produced it');
{
  /* Three files carry BUILD_ID. All three now carry the commit beside it. */
  ok('the shell loader carries a commit placeholder', /var SHELL_COMMIT = '__COMMIT__';/.test(PWA));
  ok('and it is substituted, both directions checked',
     /html\.indexOf\('__COMMIT__'\) < 0/.test(PWA)
     && /html = html\.replace\('__COMMIT__', COMMIT\)/.test(PWA)
     && /html\.indexOf\('__COMMIT__'\) >= 0/.test(PWA));
  ok('app.js carries one', /var APP_COMMIT='\$\{COMMIT\}'/.test(PWA));
  ok('the service worker carries one', /const COMMIT\s+= '\$\{COMMIT\}';/.test(PWA));
  ok('and the extracted content records one too', /^\s*commit,$/m.test(EXTRACT));

  /* IT MUST NOT BE FOLDED INTO ANYTHING. BUILD_ID answers a different
     question, and SHELL_V / CONTENT_V are cache keys: rekeying either on a
     commit id would evict a device's 19 MB of figures for a change that
     altered no byte the browser runs. */
  const buildId = /const BUILD_ID = crypto[\s\S]{0,200}?digest\('hex'\)\.slice\(0, 16\);/.exec(PWA);
  ok('BUILD_ID is still shell+content only', !!buildId && !/COMMIT/.test(buildId[0]),
     buildId ? buildId[0].replace(/\s+/g, ' ').slice(0, 70) : 'not found');
  const shellV = /const shellDigest = crypto[\s\S]{0,200}?digest\('hex'\)\.slice\(0, 16\);/.exec(PWA);
  ok('and the shell digest is still the shell bytes only',
     !!shellV && !/COMMIT/.test(shellV[0]));
  /* THIS CHECK WAS WRONG FIRST TIME, in the way this repo keeps producing: it
     looked for `commit` within eighty characters of `sourceDigest` and found
     it — in the manifest LITERAL, where the two fields simply sit on adjacent
     lines. That is adjacency, not hashing. The property is about the one line
     that computes the digest, so that is the line it reads. */
  const digestLine = /const sourceDigest = crypto[\s\S]{0,120}?;/.exec(EXTRACT_CODE);
  ok('the content digest is over the source bytes and nothing else',
     !!digestLine && /\.update\(srcBytes\)\.digest/.test(digestLine[0]) && !/commit/i.test(digestLine[0])
     && /const srcBytes = fs\.readFileSync\(SRC\);/.test(EXTRACT_CODE),
     digestLine ? digestLine[0].replace(/\s+/g, ' ') : 'not found');
  ok('and nothing on either side hashes the commit in',
     ![...PWA.matchAll(/\.update\(([^)]*)\)/g)].some(m => /COMMIT/.test(m[1]))
     && ![...EXTRACT.matchAll(/\.update\(([^)]*)\)/g)].some(m => /commit/i.test(m[1])));

  /* A build from a tarball is a legitimate build. */
  ok('a missing git is "unknown", not a failed build',
     /catch \(_\) \{ return 'unknown'; \}/.test(PWA));
  ok('and a dirty tree is marked as one', /dirty \? at \+ '-dirty' : at/.test(PWA));
  ok('the same two rules hold in extract-content', /return 'unknown'/.test(EXTRACT)
     && /dirty \? at \+ '-dirty' : at/.test(EXTRACT));
}

head('the single file says which commit made it, too');
{
  /* IT SAID NOTHING AT ALL once. The split build has carried a BUILD_ID since
     the shell/content split and a commit since the provenance pass; the
     single file carried neither — and it is the artifact that actually
     travels, dropped into Files and opened on a tablet away from the
     repository that made it.

     Held by running the stamp, not by reading its source: scripts/stamp.js is
     what scripts/assemble-app.js stamps the finished document with. (Until
     the patch chain was retired this section read scripts/build.js as text.) */
  const { stampBuffer, gitCommit, STAMP_RE } = require(path.join(ROOT, 'scripts', 'stamp.js'));
  const crypto = require('crypto');
  /* A lone 0x92 — the Windows-1252 apostrophe an exported corpus carries — is
     one byte that a string round trip turns into three. */
  const doc = Buffer.concat([Buffer.from('<html><head><title>x</title>'), Buffer.from([0x92]),
                             Buffer.from('</head><body>b</body></html>')]);
  const { out, digest } = stampBuffer(doc, 'abc123def456');
  const text = out.toString('latin1');
  ok('the document is stamped with its digest and the commit, before </head>',
     /<!-- systole-build [0-9a-f]{16} commit abc123def456 -->\n<\/head>/.test(text), text.slice(0, 120));
  ok('the digest is taken over the unstamped bytes',
     digest === crypto.createHash('sha256').update(doc).digest('hex').slice(0, 16), digest);
  const at = out.indexOf(Buffer.from('<!-- systole-build'));
  const len = out.indexOf(Buffer.from('-->\n'), at) + 4 - at;
  ok('and nothing else changes: removing the stamp gives the input back, byte for byte',
     Buffer.concat([out.subarray(0, at), out.subarray(at + len)]).equals(doc));
  ok('the stamp is an HTML comment, which the CSP and the inline-script checks never see',
     /^<!-- [^>]* -->\n$/.test(out.subarray(at, at + len).toString('latin1')));
  let refused = '';
  try { stampBuffer(Buffer.from('<html><body>no head</body></html>'), 'x'); } catch (e) { refused = e.message; }
  ok('a document without a </head> is refused, not stamped', /exactly one <\/head>/.test(refused), refused || 'stamped anyway');
  refused = '';
  try { stampBuffer(Buffer.from('<head></head><head></head>'), 'x'); } catch (e) { refused = e.message; }
  ok('and so is one with two', /exactly one <\/head>/.test(refused), refused || 'stamped anyway');
  /* NO CLOCK. The same document at the same commit must produce the same bytes. */
  ok('no timestamp rides along, so the build stays reproducible', stampBuffer(doc, 'abc123def456').out.equals(out));
  ok('the stamp the assembler strips is the one it writes', (text.match(STAMP_RE) || []).length === 1);
  /* Same two rules as everywhere else: a tarball is a legitimate place to
     build from, and a dirty tree is a claim the repository cannot honour. */
  ok('outside a git checkout the commit is "unknown"', gitCommit(require('os').tmpdir()) === 'unknown');
  {
    /* A throwaway repository: one commit, then a change not committed. */
    const { execFileSync } = require('child_process');
    const repo = fs.mkdtempSync(path.join(require('os').tmpdir(), 'stamp-git-'));
    const git = (...a) => execFileSync('git', ['-c', 'user.name=t', '-c', 'user.email=t@t', ...a], { cwd: repo, stdio: 'ignore' });
    git('init', '-q'); fs.writeFileSync(path.join(repo, 'a'), '1'); git('add', 'a'); git('commit', '-q', '-m', 'x');
    const clean = gitCommit(repo);
    fs.writeFileSync(path.join(repo, 'a'), '2');
    const dirty = gitCommit(repo);
    fs.rmSync(repo, { recursive: true, force: true });
    ok('a clean checkout is its commit, and a dirty tree is marked',
       /^[0-9a-f]{12}$/.test(clean) && dirty === clean + '-dirty', `${clean} / ${dirty}`);
  }
}

head('the built artifacts are checked where only a build can check them');
{
  /* WHAT THIS FILE CANNOT DO, said once rather than implied. Everything above
     reads build-pwa.js as TEXT and runs stamp.js: it proves they EMIT the stamps.
     It cannot tell whether a stamp survived substitution, the split, the font
     lift or eight later rewrites of `html`. Only the artifact answers that,
     and only a run with the licensed export produces one.

     So the browser suite must carry the other half, and this asserts it does
     — otherwise "provenance is tested" would be true of the emitting and
     false of the artifact, which is the shape of hole this repository keeps
     finding: green that covers the paragraph beside the one with the hole. */
  const PWASUITE = fs.readFileSync(path.join(ROOT, 'tests', 'verify-pwa.js'), 'utf8');
  ok('verify-pwa reads the commit off the served shell', /SHELL_COMMIT = '\(\[\^'\]\*\)'/.test(PWASUITE));
  ok('and off app.js and the worker',
     /var APP_COMMIT='\(\[\^'\]\*\)'/.test(PWASUITE) && /const COMMIT\\s\*=\\s\*'\(\[\^'\]\*\)'/.test(PWASUITE));
  ok('and holds all three to the same commit', /all three agree on which commit that was/.test(PWASUITE));
  ok('and refuses an unsubstituted placeholder in the artifact',
     /no unsubstituted placeholder reached the artifact/.test(PWASUITE));
  ok('and will not accept the build stamp in the commit slot',
     /the commit is a commit, not a copy of the build stamp/.test(PWASUITE));
  ok('and checks the content manifest the freshness gate compares against',
     /the extracted content records a commit as well/.test(PWASUITE));
}

head('the record names the tree the suites ran on, not the tree after the record was written');
{
  /* A --pwa run writes tests/test-stats.json twice. provenance() asked git
     after the first write, saw that file modified, and recorded a clean
     checkout as "+uncommitted changes" (the record of 2026-10-08). So it is
     asked once, before any suite runs, and everything that names the checkout
     uses that answer. Read from the blanked source: the comment above
     STARTED_ON quotes the very phrase. */
  const { blankComments } = require('./_source.js');
  const V = blankComments(fs.readFileSync(path.join(__dirname, '..', 'scripts', 'verify.js'), 'utf8'));
  const calls = [...V.matchAll(/(?<!function )\bprovenance\(\)/g)].map(m => m.index);
  const runs = ['await runSerial(', 'await runPool('].map(t => V.indexOf(t)).filter(i => i > 0);
  const firstRun = runs.length ? Math.min(...runs) : -1, firstWrite = V.indexOf('writeStats(');
  ok('verify.js asks git about the checkout exactly once, into STARTED_ON', calls.length === 1 && /STARTED_ON\s*=\s*provenance\(\)/.test(V), `${calls.length} call(s)`);
  ok('and before any suite runs or the record is written',
     calls.length === 1 && firstRun > 0 && calls[0] < firstRun && calls[0] < firstWrite);
  ok('the record, the failure log and the summary lines all use that answer',
     /commit:\s*STARTED_ON\b/.test(V) && /# checkout\s+\$\{STARTED_ON\}/.test(V) && (V.match(/\$\{STARTED_ON\}/g) || []).length >= 3);
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
