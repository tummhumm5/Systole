#!/usr/bin/env node
/*
 * Figures that arrived with an imported chapter, and the one way to lose them.
 *
 *   node tests/verify-refassets-pure.js
 *
 * Pure Node, no browser, no build. refassets.js reaches for IndexedDB and
 * already handles not having it — `indexedDB.open` throws a ReferenceError
 * here, the try/catch resolves null, and the module falls back to its memory
 * mirror. That fallback is a supported mode (private browsing, file://), so
 * testing through it is testing a real path rather than a stub.
 *
 * WHAT IS AT STAKE. These are not the shipped corpus. content/refs-images is
 * baked into REF_IMGS at build time and can always be rebuilt from source;
 * this store holds figures from chapters the fellow imported themselves, which
 * cannot. Losing one is losing something they cannot get back by rebuilding.
 *
 * Which makes sweep() the function worth testing hardest. It exists because
 * import is content-addressed and deletion is not, so a deleted chapter would
 * otherwise leave its figures behind for ever — but it decides what to delete
 * from the note bodies it is handed, and its only caller is
 *
 *     RefAssets.sweep(REF.map(r => r.body))
 *
 * An empty REF — mid-restore, or the note store failing while the asset store
 * did not — used to mean every imported figure was reclaimed. Indistinguishable
 * from "the fellow deleted every note", and irreversible in one direction.
 */
'use strict';
const fs = require('fs');
const path = require('path');

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
const head = t => console.log('\n── ' + t + ' ──');

const SRC = fs.readFileSync(path.join(__dirname, '..', 'src', 'core', 'refassets.js'), 'utf8');
function fresh() {
  const root = {};
  new Function(SRC).call(root);
  return root.RefAssets;
}
const bytesOf = s => new Uint8Array(Buffer.from(s, 'utf8'));

head('it knows an image when it sees one');
{
  const R = fresh();
  ok('jpg, jpeg, png, webp, gif and avif are images',
     ['a.jpg', 'a.jpeg', 'a.png', 'a.webp', 'a.gif', 'a.avif'].every(n => R.isImageName(n)));
  ok('a note is not', !R.isImageName('chapter.md') && !R.isImageName('notes.txt'));
  ok('a bare name with no extension is not', !R.isImageName('README'));
  ok('the extension is matched case-insensitively', R.mimeFor('SCAN.JPG') === 'image/jpeg');
  ok('and an unknown extension has no mime', R.mimeFor('x.tiff') === '');
}

head('the same bytes are the same figure');
{
  const R = fresh();
  const a = R.add(bytesOf('pretend this is a PNG'), 'fig1.png');
  const b = R.add(bytesOf('pretend this is a PNG'), 'fig1.png');
  ok('adding an image returns a refimg key', typeof a === 'string' && a.startsWith('u/'), String(a));
  ok('identical bytes give the same key — importing twice stores one copy', a === b, `${a} / ${b}`);
  ok('and the store holds one entry, not two', R.count() === 1, String(R.count()));
  const c = R.add(bytesOf('a different picture entirely'), 'fig2.png');
  ok('different bytes give a different key', c !== a, `${c}`);
  ok('the key carries the extension so the mime survives a reload', /\.png$/.test(a));
  ok('what comes back is a usable data URL', /^data:image\/png;base64,/.test(R.get(a)));
  ok('and a key nobody stored gives an empty string, not undefined', R.get('u/nope.png') === '');
  ok('has() agrees with get()', R.has(a) === true && R.has('u/nope.png') === false);
  ok('a non-image is refused outright', R.add(bytesOf('# a chapter'), 'chapter.md') === null);
}

head('sweep reclaims what no surviving note cites');
{
  const R = fresh();
  const keep = R.add(bytesOf('kept figure'), 'keep.png');
  const lose = R.add(bytesOf('orphaned figure'), 'lose.png');
  ok('two figures are stored', R.count() === 2);
  const n = R.sweep([`Some prose.\n\n![a caption](refimg://${keep})\n\nMore prose.`]);
  ok('the uncited one is reclaimed', n === 1, String(n));
  ok('the cited one survives', R.has(keep) === true);
  ok('and the orphan is gone', R.has(lose) === false);
}

head('and refuses to reclaim against nothing — the irreversible direction');
{
  /* THE BUG THIS CLOSES. The only caller passes REF.map(r => r.body). An empty
     REF means either "every note was deleted" or "the notes have not loaded
     yet", and from in here those are the same value. Treating the second as
     the first deletes every figure the fellow ever imported — their own
     chapters, which unlike the shipped corpus cannot be rebuilt from source.
     Doing nothing costs a delayed reclaim the next sweep performs anyway. */
  const R = fresh();
  const a = R.add(bytesOf('an imported figure'), 'a.png');
  const b = R.add(bytesOf('another imported figure'), 'b.png');
  ok('two imported figures are in the store', R.count() === 2);

  ok('sweeping against an empty note list reclaims nothing', R.sweep([]) === 0);
  ok('and the figures are still there', R.has(a) && R.has(b), String(R.count()));
  ok('sweeping against undefined reclaims nothing', R.sweep(undefined) === 0);
  ok('sweeping against a non-array reclaims nothing', R.sweep('not a list') === 0);
  ok('the store is untouched by all three', R.count() === 2, String(R.count()));

  /* But a real list with real notes still works — the guard must not have
     turned sweep into a no-op. */
  const n = R.sweep([`![x](refimg://${a})`]);
  ok('while a genuine list still reclaims the orphan', n === 1 && R.has(a) && !R.has(b), String(n));
}

head('unless the caller vouches that the list is the whole set');
{
  /* THE OTHER HALF, AND IT WAS MISSING — the refusal above shipped without it
     and broke the case it did not think about. Deleting the LAST note that
     cites a figure produces a legitimately empty list, so a blanket refusal
     means that final figure is never reclaimed and the store only ever grows.

     verify-assets found it in a browser, three runs running:

         FAIL  and when the last citation goes, so does the figure  → 1

     which is the right suite to have caught it and the wrong place to have
     needed to: that one needs a build, a browser and the licensed export, so
     it runs on one machine when someone remembers. Everything the failure
     turns on is arithmetic over strings, and belongs here where it runs on a
     push. That is the whole argument for this file existing, made against it.

     refDelete has just rebuilt REF from the live array, so it knows. A future
     boot-time sweep would not, and would say nothing — which is why the
     assurance is opt-in and its absence keeps the safe refusal. */
  const R = fresh();
  const a = R.add(bytesOf('the last chapter'), 'a.png');
  const b = R.add(bytesOf('and its second figure'), 'b.png');
  ok('two imported figures are in the store', R.count() === 2);

  const n = R.sweep([], { authoritative: true });
  ok('an empty list the caller vouches for reclaims everything', n === 2, String(n));
  ok('and the store is empty afterwards', R.count() === 0 && !R.has(a) && !R.has(b),
     String(R.count()));

  /* The assurance must be exactly true, not merely truthy: a caller that
     passes an options object for some other reason must not reclaim the shelf
     by accident. */
  const R2 = fresh();
  R2.add(bytesOf('x'), 'x.png');
  ok('a bare options object does not vouch', R2.sweep([], {}) === 0 && R2.count() === 1);
  ok('and neither does a truthy non-true value',
     R2.sweep([], { authoritative: 'yes' }) === 0 && R2.count() === 1, String(R2.count()));
}

head('the citation pattern matches what md() actually writes');
{
  const R = fresh();
  const k = R.add(bytesOf('figure bytes'), 'f.png');
  R.add(bytesOf('other bytes'), 'g.png');
  /* An empty caption, and a caption containing brackets — both legal Markdown
     and both produced by importers in the wild. */
  ok('an empty caption still counts as a citation',
     R.sweep([`![](refimg://${k})`]) === 1 && R.has(k));
  const R2 = fresh();
  const k2 = R2.add(bytesOf('figure bytes'), 'f.png');
  R2.add(bytesOf('other bytes'), 'g.png');
  ok('a caption with punctuation still counts',
     R2.sweep([`![Fig. 1 — LV, apical](refimg://${k2})`]) === 1 && R2.has(k2));
}

head('what it reports about itself');
{
  const R = fresh();
  R.add(bytesOf('x'.repeat(300)), 'a.png');
  ok('keys are listed', R.keys().length === 1 && R.keys()[0].startsWith('u/'));
  ok('count agrees with keys', R.count() === R.keys().length);
  ok('bytes is a plausible decoded size, not the base64 length',
     R.bytes() > 200 && R.bytes() < 500, String(R.bytes()));
  ok('an empty store reports zero', fresh().count() === 0 && fresh().bytes() === 0);
}

(async()=>{
  head('backup includes cited images and rejects corrupt data before writing');
  const R=fresh(),key=R.add(bytesOf('synthetic image bytes'),'fig.png');
  R.add(bytesOf('uncited bytes'),'orphan.png');
  const {assets,missing:none}=await R.backup([`![Synthetic](refimg://${key})`]);
  ok('only the cited user image is backed up',Object.keys(assets).length===1&&assets[key]===R.get(key)&&none.length===0);
  const target=fresh(),stored=await target.restoreBackup(assets);
  ok('restoration retains the exact bytes even without IndexedDB',target.get(key)===R.get(key));
  ok('a fallback restore reports that the image is not durable',stored===false);
  let refused=false;try{await target.restoreBackup({...assets,[key]:assets[key].replace(/.$/,'!')});}catch(_){refused=true;}
  ok('corrupt image data is rejected without replacing the existing image',refused&&target.get(key)===R.get(key));
  const empty=fresh();let failedRestore=false;
  try{await empty.restoreBackup({...assets,'u/not-a-hash.png':'data:image/png;base64,QQ=='});}catch(_){failedRestore=true;}
  ok('every image is validated before the first write',failedRestore&&empty.count()===0);
  /* A cited image that is not here: the rest still exports, and the gap is
     reported once per image, however often it is cited. */
  const part=fresh(),kept=part.add(bytesOf('present bytes'),'here.png');
  const lost=`u/${part.hashBytes(bytesOf('absent bytes'))}.png`;
  let partial;try{partial=await part.backup([`![](refimg://${kept}) ![](refimg://${lost})`,`![](refimg://${lost})`]);}catch(e){partial=e;}
  ok('a missing cited image does not stop the export of the images that are here',
     !!partial&&!!partial.assets&&partial.assets[kept]===part.get(kept)&&!(lost in partial.assets),String(partial&&partial.message||''));
  ok('and the missing image is reported, once',
     !!partial&&Array.isArray(partial.missing)&&partial.missing.length===1&&partial.missing[0]===lost);
  head('a database whose open never answers');
  {
    /* Same failure as store.js: an open that fires none of success, error or
       blocked left ready(), backup() and every write waiting for ever, and
       Export awaits backup(). The module's setTimeout is swapped for one that
       runs its delay in a few milliseconds and records what it was asked for;
       the fake web keeps the real timers. */
    const { makeWeb } = require('./_fakeweb.js');
    const asked = [];
    const quick = (fn, ms) => { asked.push(ms); return setTimeout(fn, Math.min(ms, 30)); };
    const load = web => { const root = {}; new Function('indexedDB', 'setTimeout', SRC).call(root, web.indexedDB, quick); return root.RefAssets; };
    const HUNG = 'still waiting after 2 s';
    const within = p => Promise.race([p, new Promise(res => setTimeout(() => res(HUNG), 2000))]);
    const H = load(makeWeb({ openHangs: true }));
    const n = await within(H.ready());
    ok('ready() settles instead of waiting for ever', n === 0, String(n));
    /* 10-30 s. The floor is why this moved from 4 s: on a loaded machine an
       open that was fine took longer, and the images restored in that visit
       were lost at the next reload (src/core/refassets.js, OPEN_TIMEOUT_MS).
       The ceiling keeps a hung open a bounded wait. */
    ok('after giving the database 10-30 s, longer than a slow first open, not none',
       asked.some(ms => ms >= 10000 && ms <= 30000), asked.join(', ') || 'no timer was set');
    ok('and says it gave up', H.openInfo().state === 'gave up', JSON.stringify(H.openInfo()));
    const k = H.add(bytesOf('imported while the database hung'), 'h.png');
    const flushed = await within(H.flush());
    ok('a write settles, and reports it was not stored', flushed === false, String(flushed));
    ok('while the figure is still there for this session', !!k && H.has(k));
    const b = await within(H.backup([`![](refimg://${k})`]));
    ok('and a backup completes with it', b !== HUNG && !!b.assets && b.assets[k] === H.get(k));

    const lateWeb = makeWeb({ openAfter: 150 });
    const L = load(lateWeb);
    await L.ready();
    await new Promise(res => setTimeout(res, 250));
    ok('a connection that arrives after the give-up is closed', lateWeb.closed === 1, `${lateWeb.closed} closed`);
    /* And an open that answers in time says so, with how long it took. */
    const O = load(makeWeb({}));
    await O.ready();
    const info = O.openInfo();
    ok('an open that answers in time is reported open, with its time',
       info.state === 'open' && typeof info.ms === 'number' && info.ms >= 0 && info.ms < 10000, JSON.stringify(info));
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch(e=>{console.error(e);process.exit(1);});
