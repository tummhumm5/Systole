#!/usr/bin/env node
/*
 * Checks for the cardiac cycle: Wiggers diagram, PV loop, flow, right heart,
 * Starling/Guyton — src/core/physio.js and src/ui/wiggers.js.
 *
 *   NODE_PATH=$(npm root -g) node tests/verify-physio.js <patched.html|url>
 *
 * The claim worth testing is not "a diagram renders". It is that every curve
 * on it is a real physiological identity, not an illustration:
 *
 *   · valves are CROSSINGS of two independently written pressure curves,
 *     measured by bisection, not asserted by a constant;
 *   · volume is EXACTLY flat — not nearly flat — wherever both valves are shut;
 *   · the PV loop is SOLVED from two elastances (Ees, Ea), so raising afterload
 *     must raise end-systolic volume and lower EF with contractility untouched;
 *   · the ESPVR and EDPVR must pass through the loop's own corners, for every
 *     intervention, because a relation that doesn't touch the loop it explains
 *     is decoration;
 *   · aortic and mitral flow are the derivative of the SAME volume curve, so
 *     what leaves during ejection must equal what returns during filling;
 *   · Guyton's two curves must cross at exactly one point, and stroke volume
 *     rising with preload must exceed contractility barely moving output —
 *     the actual clinical lesson, not just "two curves are drawn";
 *   · the diagram's cursor must be driven by the SAME clock as the beating
 *     heart, not a second animation that happens to agree with it.
 *
 * If any of those stop being true, this is what says so — not a screenshot
 * that merely looks like a Wiggers diagram.
 */
'use strict';
const path = require('path');
const { launch, isEngineNoise, engineName } = require('./_engine');
const { booted, afterRender } = require('./_render.js');
const { onDeath } = require('./_deathnote.js');

const target = process.argv[2];
if (!target) { console.error('usage: node tests/verify-physio.js <patched.html|url>'); process.exit(1); }
const URL = /^https?:\/\//.test(target) ? target : 'file://' + path.resolve(target);

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
/* A THIRD OUTCOME, FOR A CLAIM THIS ENGINE CANNOT WEIGH — the same device
   tests/verify-pwa.js uses for its heap budget, and for the same reason. The
   rate check below needs frames to exist. Failing it where they do not would
   call the app broken over a browser that would not paint; passing it would
   report a rate nobody measured. Both are lies, and the second is worse,
   because it reads as coverage. */
let unmeasured = 0;
const unmeasurable = (label, why) => {
  unmeasured++;
  console.log('  ----  ' + label + '  → not measurable here: ' + why);
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

(async () => {
  const browser = await launch();
  const page = await browser.newPage({ viewport: { width: 1000, height: 1300 }, deviceScaleFactor: 2 });
  const errors = [];
  const events = [];
  page.on('crash', () => events.push('the browser CRASHED the page'));
  page.on('close', () => events.push('the page closed'));
  page.on('requestfailed', r => {
    const why = (r.failure() || {}).errorText || '';
    if (why) events.push(`request failed: ${String(r.url()).slice(-50)} — ${why}`);
  });
  /* A crash and a close are different diagnoses; Playwright reports both
     as "Target page, context or browser has been closed" on the next call,
     so only the event says which. See tests/_deathnote.js. */
  onDeath(() => ({ section, checks: passed + failed, errors,
                   events: events.length ? events.join(', ') : 'none' }));
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !isEngineNoise(m.text())) errors.push(m.text()); });

  await page.goto(URL, { waitUntil: 'load', timeout: 250000 });
  await booted(page, { timeout: 150000 });

  /* ═══════════════════════ the model, in isolation ═══════════════════════ */
  head('the physiology, independent of any rendering');
  const M = await page.evaluate(() => {
    const P = Physio, T = P.T;
    const d = P.derived(0.8);

    /* Continuity, including across the wrap from t=1 back to t=0.
       Not "the biggest step is small" — isovolumetric relaxation drops 85 mmHg
       in 0.065 of a cycle and is supposed to look almost vertical, so a fixed
       threshold would fail a curve that is perfectly continuous and merely
       steep. Instead, halve the sample spacing: a continuous curve's largest
       step halves with it, while a genuine jump stays exactly the same size
       however finely you sample around it. The ratio is the discontinuity. */
    const step = (fn, n) => { let w = 0; for (let i = 0; i < n; i++) { const a = i / n, b = (i + 1) / n; w = Math.max(w, Math.abs(fn(b) - fn(a))); } return w; };
    const refine = fn => step(fn, 12000) / Math.max(step(fn, 6000), 1e-12);
    const steps = { vol: refine(P.lvVolume), lv: refine(P.lvPressure), ao: refine(P.aoPressure), rv: refine(P.rvPressure), pa: refine(P.paPressure), la: refine(P.laPressure), ra: refine(P.raPressure) };

    /* isovolumetric flatness — exact, not approximate */
    const flat = (a, b) => { let lo = 1e9, hi = -1e9; for (let i = 0; i <= 300; i++) { const t = a + (b - a) * i / 300, v = P.lvVolume(t); lo = Math.min(lo, v); hi = Math.max(hi, v); } return hi - lo; };
    const ivcFlat = flat(T.mc, T.ao - 1e-6), ivrFlat = flat(T.ac, T.mo - 1e-6);

    /* valve events: measured crossing vs the design constant */
    const x = P.crossings();
    const crossErr = {};
    for (const k of ['mc', 'ao', 'ac', 'mo', 'tc', 'po', 'pc', 'to']) crossErr[k] = Math.abs(x[k] - T[k]);

    /* flow: ejected volume must equal filled volume must equal SV, both ways */
    let vOut = 0, vIn = 0;
    for (let i = 0; i < 20000; i++) { const t = i / 20000; vOut += Math.max(0, -P.dVdt(t)) / 20000; vIn += Math.max(0, P.dVdt(t)) / 20000; }

    /* E/A and coronary phase split */
    let E = 0, Et = 0, A = 0;
    for (let i = 0; i < 4000; i++) { const t = i / 4000, q = P.mitralFlow(t, 0.8);
      if (t >= T.mo && t < T.dias && q > E) { E = q; Et = t; } if (t < T.mc && q > A) A = q; }

    /* PV loop / interventions: ESPVR and EDPVR must pass through the corners */
    const ivErr = P.INTERVENTIONS.map(iv => {
      const L = P.loopWith(iv.args);
      return { id: iv.id, ef: L.ef, sv: L.sv, esv: L.esv,
                esErr: Math.abs(P.espvr(L.esv, L.ees, L.v0) - L.esp),
                edErr: Math.abs(P.edpvr(L.edv, L.stiff, L.shift) - L.edp) };
    });
    const base = P.loopWith(), after = P.loopWith({ ea: 2.4 }), inotrope = P.loopWith({ ees: 4.2 }), preload = P.loopWith({ edv: 150 });

    /* Guyton: solve each operating point, don't trust a fixed sample */
    const solve = (st, msfp) => { let lo = -4, hi = 20; for (let k = 0; k < 70; k++) { const m = (lo + hi) / 2; (P.cardiacFunction(m, st) - P.venousReturn(m, msfp) < 0) ? lo = m : hi = m; } return { ra: (lo + hi) / 2, co: P.venousReturn((lo + hi) / 2, msfp) }; };
    const gNormal = solve(null, 7), gVolume = solve('failing', 14), gFailing = solve('failing', 7);

    return { d, steps, ivcFlat, ivrFlat, crossErr, vOut, vIn,
             ea: E / A, coronaryDia: d.leftDiastolicFraction,
             ivErr, base, after, inotrope, preload,
             gNormal, gVolume, gFailing,
             starlingNormalAt10: P.starling(10), starlingFailingAt10: P.starling(10, 'failing'),
             phaseCount: P.PHASES.length, eventCount: P.EVENTS.length,
             dpdtPhase: P.phaseAt(d.dpdtAt).id };
  });

  ok('every trace is continuous — halving the sample spacing halves its largest step, so no curve jumps',
     Object.values(M.steps).every(s => s < 0.7),
     Object.entries(M.steps).map(([k, v]) => `${k} ${v.toFixed(2)}`).join('  '));
  ok('LV volume is EXACTLY flat during isovolumetric contraction', M.ivcFlat < 1e-4, `spread ${M.ivcFlat}`);
  ok('and exactly flat during isovolumetric relaxation', M.ivrFlat < 1e-4, `spread ${M.ivrFlat}`);

  ok('every valve event is a measured crossing within 1% of its design time', Object.values(M.crossErr).every(e => e < 0.01), JSON.stringify(M.crossErr));

  ok('LV systolic pressure is physiological', M.d.lvSys > 110 && M.d.lvSys < 132, M.d.lvSys.toFixed(1));
  ok('LVEDP is physiological, not the near-zero a naive isovolumetric plateau gives', M.d.lvEdp > 6 && M.d.lvEdp < 14, M.d.lvEdp.toFixed(1));
  ok('aortic pressure is 120/80-ish with a real pulse pressure', M.d.aoSys > 110 && M.d.aoSys < 130 && M.d.aoDia > 68 && M.d.aoDia < 88, `${M.d.aoSys.toFixed(0)}/${M.d.aoDia.toFixed(0)}`);
  ok('ejection fraction is normal', M.d.ef > 0.52 && M.d.ef < 0.65, (M.d.ef * 100).toFixed(1) + '%');
  ok('RV pressure is a quarter of LV, not a rescaled copy of it', M.d.rvSys > 18 && M.d.rvSys < 30, M.d.rvSys.toFixed(1));
  ok('S2 splits — A2 before P2, by a physiological margin', M.d.s2Split > 5 && M.d.s2Split < 60, M.d.s2Split.toFixed(0) + ' ms');
  ok('S1 splits too — M1 before T1', M.d.s1Split > 2 && M.d.s1Split < 40, M.d.s1Split.toFixed(0) + ' ms');
  ok('dP/dt max falls in isovolumetric contraction, where physiology says it must', M.dpdtPhase === 'ivc', M.dpdtPhase);

  ok('ejected volume equals filled volume equals stroke volume', Math.abs(M.vOut - M.vIn) < 0.5 && Math.abs(M.vOut - M.d.sv) < 0.5, `out ${M.vOut.toFixed(2)}  in ${M.vIn.toFixed(2)}  SV ${M.d.sv}`);
  ok('E/A ratio is normal for a resting adult', M.ea > 1.0 && M.ea < 2.2, M.ea.toFixed(2));
  ok('left coronary flow arrives mostly in diastole', M.coronaryDia > 0.75, (M.coronaryDia * 100).toFixed(0) + '%');

  head('the pressure-volume relations, against every loop they explain');
  /* "All six" is counted, not assumed: [].every() is true, so an emptied or shortened INTERVENTIONS passed both. */
  ok('ESPVR passes through end-systole on all six interventions', M.ivErr.length === 6 && M.ivErr.every(e => e.esErr < 0.5), M.ivErr.map(e => e.id + ':' + e.esErr.toFixed(2)).join(' '));
  ok('EDPVR passes through end-diastole on all six interventions', M.ivErr.length === 6 && M.ivErr.every(e => e.edErr < 0.5), M.ivErr.map(e => e.id + ':' + e.edErr.toFixed(2)).join(' '));
  ok('the base parametric loop reproduces the physiological one', Math.abs(M.base.esv - 50) < 1 && Math.abs(M.base.ef - M.d.ef) < 0.01, `ESV ${M.base.esv.toFixed(1)}  EF ${(M.base.ef * 100).toFixed(1)}%`);
  ok('raising afterload raises ESV and lowers EF with contractility untouched',
     M.after.esv > M.base.esv + 5 && M.after.ef < M.base.ef - 0.05, `ESV ${M.base.esv.toFixed(0)}→${M.after.esv.toFixed(0)}  EF ${(M.base.ef*100).toFixed(0)}%→${(M.after.ef*100).toFixed(0)}%`);
  ok('raising contractility lowers ESV and raises EF', M.inotrope.esv < M.base.esv - 5 && M.inotrope.ef > M.base.ef + 0.05, `ESV ${M.inotrope.esv.toFixed(0)}  EF ${(M.inotrope.ef*100).toFixed(0)}%`);
  ok('raising preload raises stroke volume', M.preload.sv > M.base.sv + 10, `SV ${M.base.sv.toFixed(0)}→${M.preload.sv.toFixed(0)}`);

  head('Starling and Guyton — the operating point is solved, not sampled');
  ok('a failing ventricle needs more filling pressure for the same output', M.starlingFailingAt10 < M.starlingNormalAt10, `normal ${M.starlingNormalAt10.toFixed(0)}  failing ${M.starlingFailingAt10.toFixed(0)}`);
  ok('normal cardiac output at rest is physiological', M.gNormal.co > 4 && M.gNormal.co < 6.5, M.gNormal.co.toFixed(2) + ' L/min');
  ok('acute failure drops output well below normal', M.gFailing.co < M.gNormal.co - 1, `${M.gFailing.co.toFixed(2)} vs ${M.gNormal.co.toFixed(2)}`);
  ok('volume retention partially restores output in failure — Guyton\'s actual lesson', M.gVolume.co > M.gFailing.co + 0.5, `${M.gFailing.co.toFixed(2)} → ${M.gVolume.co.toFixed(2)}`);

  ok('seven phases, eight valve events — nothing dropped from the model', M.phaseCount === 7 && M.eventCount === 8);

  /* ═══════════════════════════ rendered, in Rhythm Lab ═══════════════════════ */
  head('mounted in Rhythm Lab');
  await page.evaluate(() => { goLab(); render(); });
  await page.waitForTimeout(600);

  const mounted = await page.evaluate(() => ({
    hasPanel: !!document.querySelector('.physio-panel'),
    hasCanvas: !!document.getElementById('physioCanvas'),
    view: physio ? physio.view() : null,
    chips: [...document.querySelectorAll('[data-physio-view]')].map(c => c.getAttribute('data-physio-view')),
  }));
  ok('the cardiac-cycle panel is in Rhythm Lab', mounted.hasPanel && mounted.hasCanvas);
  ok('it opens on the Wiggers view', mounted.view === 'wiggers');
  /* THE IDS, NOT A COUNT. This asserted `chipCount === 5` until the Conduction
     Wave landed a sixth view on purpose, and the first full run after that
     merge failed here with a bare "6" — correct to fail, but the number said
     that something changed and nothing about what. Swapping 5 for 6 would
     have left the same blind spot for the next view.

     Pinned here, deliberately, rather than read from PHYSIO_VIEWS: the chips
     are rendered FROM that list, so comparing the two would only prove the
     loop ran. Adding or removing a view should be a decision this line has
     to be told about — which is what just happened, and it worked. Order is
     ignored, duplicates are not. */
  /* Seven since Coronary joined — told here on purpose, which is what pinning
     the ids is for: a view added without this line moving fails loudly. */
  const EXPECTED_VIEWS = ['conduction', 'coronary', 'curves', 'flow', 'pv', 'right', 'wiggers'];
  const chipsSorted = mounted.chips.slice().sort();
  ok('the seven views each have one chip, and there are no others',
     JSON.stringify(chipsSorted) === JSON.stringify(EXPECTED_VIEWS),
     mounted.chips.join(', ') || 'no chips');

  head('it keeps its own clock, at the rate the rhythm sets');
  /* The diagram used to read its time from the 3D heart beside it. That heart
     is gone, so the claim is no longer "these two agree" but "this one runs" —
     and runs at the rate the physiology says, which is the stronger claim of
     the two because it can be checked against a number rather than against
     another animation. */
  /* MEASURED ACROSS FRAMES, NOT ACROSS A SLEEP. This was a bare
     setTimeout(600), and on WebKit it reported 0.00 and 0.06 of a cycle where
     0.34 was expected — which reads exactly like a broken clock and is not one.
     The panel's tick() is driven by its own requestAnimationFrame chain, and a
     lone rAF chain on an otherwise idle headless page is throttled to about ONE
     frame in 600ms. tick() clamps its delta with Math.min(now - last, 100) — a
     correct guard, so that a backgrounded tab does not leap a minute of cardiac
     cycle on its first frame back — so one frame advances the model by exactly
     100ms, and 100ms of 1760ms is 0.057. That is the number that was appearing.

     Confirmed by measurement rather than by argument: with frames flowing the
     same build on the same WebKit advances 0.3678 and 0.3904 against an
     expected 0.34, and Chromium advances 0.3495. The clock is right on both.

     So the window requests frames rather than sleeping through them. This is
     not a weaker claim: the suite supplies the frame clock, physio's own loop
     still decides what to do with it, and a panel that had stopped animating
     would still report nothing moving. The threshold below is untouched. */
  await page.locator('#physioCanvas').scrollIntoViewIfNeeded();
  const ownClock = await page.evaluate(async () => {
    // The first tick establishes its timestamp and intentionally advances by zero.
    // Start the measurement after that frame, with the diagram in view.
    await new Promise(resolve => requestAnimationFrame(resolve));
    const t0 = physio.time();
    const started = performance.now();
    let frames = 0;
    await new Promise(res => {
      const step = () => {
        frames++;
        if (performance.now() - started < 600) requestAnimationFrame(step); else res();
      };
      requestAnimationFrame(step);
    });
    const t1 = physio.time();
    /* Cycle fraction wraps, so measure forward distance around the circle. */
    const advanced = ((t1 - t0) % 1 + 1) % 1;
    return { t0, t1, advanced, frames, wall: performance.now() - started,
             hr: RHYTHMS[labKind].hr, slow: (physio.slow ? physio.slow() : 1) };
  });
  /* Frames and wall time in the detail: WebKit once read 0.000 → 0.000, and without them
     "no frames came" and "frames came and the clock stood still" read the same. */
  ok('the cursor advances on its own', ownClock.advanced > 0.001,
     `${ownClock.t0.toFixed(3)} → ${ownClock.t1.toFixed(3)}, ${ownClock.frames} frame(s) in ${Math.round(ownClock.wall)} ms`);
  /* 600ms at 68 bpm is 0.68 of a cycle, DIVIDED BY the playback speed. Both
     halves matter and the suite now pins both: the clock is driven by the
     rhythm's own rate rather than a free-running constant, and the slow-motion
     control is a divisor on that rather than a redefinition of the heart rate.
     A Wiggers diagram running at "34 bpm" would be a bradycardia, not a replay,
     so the two must stay separable. Generous bounds — this is asserting the
     clock runs at roughly the right speed, not benchmarking the frame timer. */
  const expected = 0.6 * (ownClock.hr / 60) / (ownClock.slow || 1);
  /* THE ONE THING THAT MAKES THIS UNWEIGHABLE, stated as arithmetic rather than
     as a feeling about engines. tick() clamps each step with
     Math.min(now - last, 100) so a backgrounded tab cannot leap a minute of
     cardiac cycle on its first frame back. That guard is correct, and it means
     model time can only keep up with wall time while frames arrive closer
     together than 100ms. Headless WebKit here delivers three in 603ms, so the
     model advances 300ms of a 603ms window — half rate, by construction, with
     nothing wrong anywhere. Give the same build the same WebKit with frames
     flowing and it advances 0.3678 and 0.3904 against this same expected 0.34;
     Chromium advances 0.3495. The clock is right on both. */
  const mean = ownClock.wall / Math.max(1, ownClock.frames);
  if (mean >= 100) {
    unmeasurable('and at roughly the rate the rhythm implies, not some free-running speed',
      `${ownClock.frames} frames in ${Math.round(ownClock.wall)}ms — ${mean.toFixed(0)}ms apart, `
      + `and tick() clamps each step at 100ms, so the model cannot keep up with the wall`);
  } else {
    ok('and at roughly the rate the rhythm implies, not some free-running speed',
       Math.abs(ownClock.advanced - expected) < 0.25 || Math.abs(ownClock.advanced - expected + 1) < 0.25,
       `advanced ${ownClock.advanced.toFixed(2)} of a cycle, expected ~${expected.toFixed(2)} at ${ownClock.hr} bpm`
       + ` (${ownClock.frames} frames, ${mean.toFixed(0)}ms apart)`);
  }

  const paused = await page.evaluate(async () => {
    /* Scrubbing must stop the clock, or you could never read the dicrotic
       notch — the cursor would walk out from under your finger. */
    physio.setScrub(true); physio.setTime(0.42);
    await new Promise(r => setTimeout(r, 400));
    const held = physio.time();
    physio.setScrub(false);
    return held;
  });
  ok('and holds still while the diagram is being scrubbed', Math.abs(paused - 0.42) < 0.01, paused.toFixed(3));

  head('a diagram that is not moving is not redrawn');
  /* A draw is one clearRect on the diagram's canvas. The window asks for its own frames, as the clock check above does, and reports the draws
     with the frames that came in it. Before this, the loop drew on every frame whatever the state: a paused Wiggers view, or the Curves view,
     which has no time in it, cost three milliseconds sixty times a second to put the same picture on the canvas.

     A CLAIM ABOUT FRAMES IS MADE ONLY WHERE THE FRAMES CAME, and for every window, the later ones too: a window is a number of frames, not a
     number of milliseconds (how many a headless page delivers in a second varies by engine and by load), it gives up at six seconds, and then
     the check says "not measurable" instead of passing or failing on almost nothing. What does not need a frame (the chip, the state the panel
     reports, a drag) is checked apart from what does. */
  const COUNT_DRAWS = () => {
    window.__physioDraws = 0;
    const clear = CanvasRenderingContext2D.prototype.clearRect;
    CanvasRenderingContext2D.prototype.clearRect = function () { if (this.canvas && this.canvas.id === 'physioCanvas') window.__physioDraws++; return clear.apply(this, arguments); };
    window.__physioWindow = (n, maxMs) => new Promise(res => {
      const d0 = window.__physioDraws, t0 = performance.now();
      let frames = 0;
      const step = () => { frames++; if (frames < n && performance.now() - t0 < maxMs) requestAnimationFrame(step); else res({ draws: window.__physioDraws - d0, frames }); };
      requestAnimationFrame(step);
    });
  };
  const FRAMES = 30, GIVE_UP_MS = 6000;
  const inFrames = (n = FRAMES) => page.evaluate(([n, ms]) => window.__physioWindow(n, ms), [n, GIVE_UP_MS]);
  const measure = (label, r, cond, detail, n = FRAMES) =>
    r.frames >= n ? ok(label, cond, detail) : unmeasurable(label, `${r.frames} of ${n} frames in ${GIVE_UP_MS} ms`);
  const panel = () => page.evaluate(() => ({ playing: physio.playing(), chip: (document.querySelector('[data-physio-play]') || {}).textContent || null,
                                              media: matchMedia('(prefers-reduced-motion: reduce)').matches }));
  /* render() swaps the DOM inside a view transition, and the panel is mounted again on a new canvas afterwards: wait for that canvas, and for
     the markup to go quiet (tests/_render.js), rather than for a time. */
  const remounted = async (act, label) => {
    await page.evaluate(() => { window.__oldPhysioCanvas = document.getElementById('physioCanvas'); });
    await page.evaluate(act);
    await afterRender(page, () => { const cv = document.getElementById('physioCanvas'); return !!cv && cv !== window.__oldPhysioCanvas && !!physio && physioCanvasEl === cv; },
                      { label: `the panel mounted again on a new canvas (${label})`, timeout: 30000 });
  };
  const click = sel => page.evaluate(sel => document.querySelector(sel).click(), sel);
  {
    await page.evaluate(COUNT_DRAWS);
    /* The precondition, as a check of its own: that it is playing and draws, or "draws nothing" below would be true of a counter that counts nothing. */
    const running = await inFrames();
    measure('playing, it draws on the frames that come', running, running.draws >= running.frames * 0.8, `${running.draws} draws in ${running.frames} frames`);

    await click('[data-physio-play]');
    const afterPause = await panel();
    ok('the Pause chip pauses it, and the chip says Play', afterPause.playing === false && afterPause.chip === 'Play', `playing ${afterPause.playing}, chip ${afterPause.chip}`);
    await page.waitForTimeout(150);                                  // a frame may be in flight
    const still = await inFrames();
    measure('and a paused diagram draws nothing over the frames that come', still, still.draws === 0, `${still.draws} draws in ${still.frames} frames`);

    /* The loop no longer draws for a paused diagram, so everything that changes the picture has to draw for itself. A drag is the one a hand uses. */
    const cvBox = await page.locator('#physioCanvas').boundingBox();
    const d0 = await page.evaluate(() => window.__physioDraws);
    await page.mouse.move(cvBox.x + cvBox.width * 0.2, cvBox.y + cvBox.height * 0.5);
    await page.mouse.down();
    await page.mouse.move(cvBox.x + cvBox.width * 0.85, cvBox.y + cvBox.height * 0.5, { steps: 8 });
    await page.mouse.up();
    const dragged = await page.evaluate(() => ({ draws: window.__physioDraws, t: physio.time() }));
    ok('a paused diagram still follows a finger: dragging across it draws, and puts the cursor where the finger is',
       dragged.draws - d0 >= 3 && dragged.t > 0.6 && dragged.t < 1, `${dragged.draws - d0} draws, cursor at ${dragged.t.toFixed(2)}`);

    /* And a resize, which only the loop can notice. The stage is narrowed in the page's own style, not by resizing the window, so that nothing
       of the app's (a resize handler, a re-render) can redraw it: the canvas has to be redrawn, at the size it now has, by the loop. */
    const wide = await page.evaluate(() => document.getElementById('physioCanvas').width);
    const before = await page.evaluate(() => window.__physioDraws);            // counted from before the stimulus: the next frame can be the one that draws
    await page.evaluate(() => { document.querySelector('.physio-stage').style.maxWidth = '320px'; });
    const resized = await inFrames(10);
    const size = await page.evaluate(() => { const c = document.getElementById('physioCanvas'), b = c.getBoundingClientRect();
                                             return { w: c.width, want: Math.round(b.width * Math.min(devicePixelRatio || 1, 3)), draws: window.__physioDraws }; });
    await page.evaluate(() => { document.querySelector('.physio-stage').style.maxWidth = ''; });
    measure('a paused diagram follows its canvas when that is resized: it is redrawn, at the size the canvas now has', resized,
            size.draws - before >= 1 && size.w === size.want && size.w < wide, `${wide} → ${size.w} px wide (wanted ${size.want}), ${size.draws - before} draws`, 10);
    await page.waitForTimeout(200);

    /* A diagram mounted where it cannot be laid out yet, and shown later, is drawn once it can. 150 by 75 points at two device pixels to the point
       is 300 by 150, the size a canvas has before anything is done to it, so the size alone would never say that it needs drawing. It counts
       eight frames of its own, and waits as long as they take. */
    const late = await page.evaluate(async () => {
      const host = document.createElement('div');
      host.style.cssText = 'display:none;position:fixed;left:0;top:0;width:150px;height:75px;z-index:-1';
      const cv = document.createElement('canvas');
      cv.style.cssText = 'display:block;width:150px;height:75px';
      host.appendChild(cv); document.body.appendChild(host);
      const w = Wiggers.mount(cv, { view: 'wiggers', playing: false });
      const blank = () => { const d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data; for (let i = 3; i < d.length; i += 4) if (d[i]) return false; return true; };
      const before = blank(), dpr = devicePixelRatio;
      host.style.display = 'block';
      await new Promise(res => { let n = 0; const step = () => (++n < 8 ? requestAnimationFrame(step) : res()); requestAnimationFrame(step); });
      const after = blank(), dims = cv.width + '×' + cv.height;
      w.destroy(); host.remove();
      return { before, after, dims, dpr };
    });
    ok('and a diagram mounted where it could not be laid out is drawn once it can, though its canvas never changed size',
       late.before === true && late.after === false && late.dims === '300×150' && late.dpr === 2,
       `blank at mount ${late.before}, blank after it was shown ${late.after}, canvas ${late.dims} at ${late.dpr}x`);

    await click('[data-physio-play]');
    const afterPlay = await panel();
    ok('the Play chip plays it again, and the chip says Pause', afterPlay.playing === true && afterPlay.chip === 'Pause', `playing ${afterPlay.playing}, chip ${afterPlay.chip}`);
    await page.waitForTimeout(150);
    const resumed = await inFrames();
    measure('and it draws on the frames that come', resumed, resumed.draws >= resumed.frames * 0.8, `${resumed.draws} draws in ${resumed.frames} frames`);

    /* The Curves view has no time in it: "playing" there moves nothing. */
    await remounted(() => document.querySelector('[data-physio-view="curves"]').click(), 'Curves');
    const curves = await inFrames();
    measure('the Curves view, which has no time in it, is not redrawn while it is playing', curves, (await panel()).playing === true && curves.draws === 0, `${curves.draws} draws in ${curves.frames} frames`);
    await remounted(() => document.querySelector('[data-physio-view="wiggers"]').click(), 'Wiggers');
  }

  head('Reduce Motion starts the cycle paused');
  {
    /* A diagram that begins moving by itself and goes on for ever is what the setting is for. With it on, the panel mounts still, says Play, and
       plays only when asked; the panel above, without it, mounted playing. The setting is emulated on this page and the panel is mounted again as
       it is on a first visit, with nothing yet decided, rather than on a second page: headless WebKit hands the page behind the front one one
       frame in a second, and a claim about frames cannot be made there. */
    await page.emulateMedia({ reducedMotion: 'reduce' });
    try {
      await remounted(() => { physioPlaying = null; render(); }, 'Reduce Motion on');
      const first = await panel();
      ok('with Reduce Motion on the diagram mounts paused, and the chip says Play', first.media === true && first.playing === false && first.chip === 'Play',
         `reduce ${first.media}, playing ${first.playing}, chip ${first.chip}`);
      const idle = await inFrames();
      measure('and it draws nothing over the frames that come', idle, idle.draws === 0, `${idle.draws} draws in ${idle.frames} frames`);
      const t0 = await page.evaluate(() => physio.time());
      await click('[data-physio-play]');
      const after = await panel();
      ok('and Play plays it, and the chip says Pause', after.playing === true && after.chip === 'Pause', `playing ${after.playing}, chip ${after.chip}`);
      await page.waitForTimeout(150);
      const moving = await inFrames();
      const t1 = await page.evaluate(() => physio.time());
      measure('and the cursor moves, and it draws on the frames that come', moving, t1 !== t0 && moving.draws >= moving.frames * 0.8,
              `cursor ${t0.toFixed(3)} → ${t1.toFixed(3)}, ${moving.draws} draws in ${moving.frames} frames`);
    } finally {
      await page.emulateMedia({ reducedMotion: 'no-preference' });
      await remounted(() => { physioPlaying = null; render(); }, 'Reduce Motion off again');
    }
  }

  /* WHAT THIS DOES NOT HOLD: that the diagram's rate follows. setLab hands the
     rhythm's rate to physio.setRate, but the diagram has no getter for it, and
     reading it back off the live clock is a race against real frames. With
     setRate taken out of setLab this section stays green, so it claims only what
     it reads: that the lab moved to the rhythm asked for. (The rhythm chips
     carry no data attribute, so the click that used to precede the call found
     nothing; setLab is what a chip's onclick calls.) */
  head('setLab moves the lab to the rhythm it is asked for');
  await page.evaluate(() => { setLab('tachy'); });
  await page.waitForTimeout(300);
  const afterTachy = await page.evaluate(() => ({ kind: labKind }));
  ok('setLab reaches the rhythm the test asked for', afterTachy.kind === 'tachy');

  head('every view mounts, sizes its canvas and says what it is');
  const viewSweep = await page.evaluate(async () => {
    const out = [];
    for (const [id] of PHYSIO_VIEWS) {
      document.querySelector(`[data-physio-view="${id}"]`)?.click();
      await new Promise(r => setTimeout(r, 120));
      const cv = document.getElementById('physioCanvas');
      const m = document.getElementById('physioModel');
      out.push({ id, w: cv.width, h: cv.height, view: physio.view(), model: m && m.getBoundingClientRect().height > 0 ? m.textContent : '' });
    }
    return out;
  });
  /* The sweep iterates PHYSIO_VIEWS, and every() over an empty list is true —
     so without the length term this passed hardest when there was nothing to
     sweep. Held to the same six the chip check pins. */
  ok('every view mounted and sized its canvas',
     viewSweep.length === EXPECTED_VIEWS.length && viewSweep.every(v => v.w > 100 && v.h > 100),
     JSON.stringify(viewSweep.map(v => v.id)));
  ok('clicking a chip actually switches the view',
     viewSweep.length === EXPECTED_VIEWS.length && viewSweep.every(v => v.id === v.view),
     viewSweep.map(v => `${v.id}:${v.view}`).join(' '));
  /* The curves are computed from textbook resting values, and the panel has
     to say so wherever it is open: a model that looks like a recording reads
     as one. Every view rebuilds the panel, so each is checked, not just the first. */
  ok('every view says it is a teaching model, not a recording',
     viewSweep.length === EXPECTED_VIEWS.length && viewSweep.every(v => /teaching model/i.test(v.model) && /not recorded from a patient/i.test(v.model)),
     viewSweep.filter(v => !/teaching model/i.test(v.model)).map(v => v.id).join(' ') || 'all');

  head('the PV loop responds to an intervention, on screen');
  await page.evaluate(() => { document.querySelector('[data-physio-view="pv"]').click(); });
  await page.waitForTimeout(150);
  const ivSwap = await page.evaluate(() => {
    document.querySelector('[data-physio-iv="after"]')?.click();
    return { iv: physio.intervention(), note: document.getElementById('physioNote').textContent };
  });
  ok('clicking an intervention chip changes the loop', ivSwap.iv === 'after');
  ok('the explanatory note updates with it', /afterload/i.test(ivSwap.note), ivSwap.note.slice(0, 60));

  head('the note follows the live phase on the Wiggers view');
  await page.evaluate(() => { document.querySelector('[data-physio-view="wiggers"]').click(); });
  await page.waitForTimeout(200);
  // Read every painted frame in the same observation window. Four protocol
  // round trips can repeatedly land in the same phase on a slow WebKit host.
  const notes = await page.evaluate(() => new Promise(resolve => {
    const seen = new Set(), end = performance.now() + 880;
    const read = () => {
      seen.add(document.getElementById('physioNote').textContent);
      if (performance.now() >= end) resolve([...seen]);
      else requestAnimationFrame(read);
    };
    read();
  }));
  ok('the phase note is live text, not a static caption', new Set(notes).size > 1, notes.map(n => n.slice(0, 18)).join(' | '));

  head('scrubbing pauses the live clock and reads back a chosen instant');
  await page.evaluate(() => { document.querySelector('[data-physio-view="wiggers"]').click(); });
  await page.waitForTimeout(150);
  const scrub = await page.evaluate(async () => {
    const cv = document.getElementById('physioCanvas');
    const r = cv.getBoundingClientRect();
    physio.setScrub(true);
    const t1 = physio.scrubAt(r.width * 0.2, r.height * 0.3);
    const readAt1 = physio.time();
    await new Promise(res => setTimeout(res, 300));
    const heldStill = physio.time();
    physio.setScrub(false);
    return { t1, readAt1, heldStill };
  });
  ok('scrubbing moves the cursor to roughly where it was dragged', Math.abs(scrub.t1 - scrub.readAt1) < 0.02);
  ok('while scrubbing, the live heart clock does not overwrite the chosen instant', Math.abs(scrub.heldStill - scrub.readAt1) < 0.005, `${scrub.readAt1.toFixed(3)} → ${scrub.heldStill.toFixed(3)}`);

  head('scrubAt reads back the SAME margins each view actually draws with');
  /* The test above only checks scrubAt's return value against time() — which
     it will always agree with, since scrubAt sets S.t and time() just reads
     it back. That self-agreement survives even if scrubAt uses the wrong
     margins entirely, so it could not have caught the real bug: scrubAt once
     carried its own hardcoded (40, 14) that happened to match drawRight, was
     2px off drawWiggers's real right margin, and 4px off drawFlow's real
     left margin — every drag on Flow landed on a slightly wrong instant. The
     fix is a margins table both scrubAt and each draw function now read from
     the same place, which this checks against an independent oracle: the
     margins each view is DOCUMENTED to draw with, taken from wiggers.js
     itself rather than re-derived from scrubAt's own behaviour. */
  const marginCheck = await page.evaluate(async ({ views }) => {
    const out = {};
    for (const v of views) {
      document.querySelector(`[data-physio-view="${v.id}"]`).click();
      /* render() rebuilds the whole screen on a chip click — including a
         brand-new <canvas> node — so cv MUST be re-queried after the click
         and settle, never cached from before it, or it points at a detached
         element with a zero-size bounding rect. */
      await new Promise(res => setTimeout(res, 150));
      const cv = document.getElementById('physioCanvas');
      const r = cv.getBoundingClientRect();
      physio.setScrub(true);
      const x = r.width * 0.5;
      const got = physio.scrubAt(x, r.height * 0.3);
      const expected = (x - v.L) / (r.width - v.L - v.R);
      out[v.id] = { got, expected, w: r.width };
      physio.setScrub(false);
    }
    return out;
  }, { views: [{ id: 'wiggers', L: 40, R: 12 }, { id: 'flow', L: 44, R: 14 }, { id: 'right', L: 40, R: 14 }] });
  for (const [id, m] of Object.entries(marginCheck)) {
    ok(`${id}: scrubbing to the mid-canvas reports the instant that view's own margins predict`,
       Math.abs(m.got - m.expected) < 0.0003, `got ${m.got.toFixed(4)} expected ${m.expected.toFixed(4)} (canvas ${m.w.toFixed(0)}px)`);
  }
  await page.evaluate(() => { document.querySelector('[data-physio-view="wiggers"]').click(); });

  head('no stray errors');
  ok('no console or page errors across the run', errors.length === 0, errors.slice(0, 3).join(' | '));

  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`
              + (unmeasured ? `, ${unmeasured} not measurable on ${engineName()}` : ''));
  process.exit(failed ? 1 : 0);
})();
