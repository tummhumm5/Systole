#!/usr/bin/env node
/*
 * The Voice card on the Study screen: a session of ten questions answered out loud.
 *
 *   node tests/verify-voicescreen.js build/synthetic/systole.html
 *
 * src/core/voicemode.js is held by verify-voicemode-pure. The speaker and the microphone are the device's
 * and cannot be tested here, so this stubs both with a scripted voice and holds the wiring around them:
 *   · with no speech APIs there is no card, and the rest of the Study screen is there;
 *   · with them the card has a Start button at least 44 px tall, and nothing is spoken before it is pressed;
 *   · pressing it opens the quiz, reads the stem and the options aloud, and listens;
 *   · a spoken letter is scored by the ordinary answer path (chStats moves, the miss list follows), the
 *     feedback is read, and the answer is rated: right → a later due date, wrong → due again today;
 *   · "skip" moves the quiz screen on and records no answer; "stop" ends with a spoken summary;
 *   · leaving the quiz screen ends the session and nothing more is spoken;
 *   · so does moving the quiz by hand (an option and a rating tapped), mid-sentence or while listening, and a
 *     letter heard after the move is not recorded or rated on the question the screen moved to;
 *   · with the microphone open and nothing said, that move closes it at the listen's next look (every 250 ms),
 *     not at its 9 s timeout, and an old listener's look never ends a session started after it.
 * What it cannot show: that a real microphone hears a letter. That is the owner's, on the iPad.
 */
'use strict';
const path = require('path');
const { launch } = require('./_engine');
const { onDeath, watch } = require('./_deathnote.js');
const { booted, onScreen, quiet } = require('./_render.js');

const target = process.argv[2];
if (!target) { console.error('usage: node tests/verify-voicescreen.js <build.html>'); process.exit(1); }
const URL = /^https?:\/\//.test(target) ? target : 'file://' + path.resolve(target);

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

/* A scripted voice. Speaking is instant; listening waits for the next line pushed onto window.__heard. */
const STUB = () => {
  window.__said = []; window.__heard = []; window.__listens = 0;
  /* Every interval's ticks are counted, so a test can wait for the listen's own 250 ms watch to have looked,
     rather than for a length of time. A recognizer notes the interval set just before it was made: in
     voiceHear, that is the watch. */
  window.__ivTicks = {}; window.__lastIv = null;
  const setIv = window.setInterval;
  window.setInterval = function (fn, ms, ...rest) {
    let id = null;
    const counted = typeof fn !== 'function' ? fn
      : function () { try { return fn.apply(this, arguments); } finally { window.__ivTicks[id] = (window.__ivTicks[id] || 0) + 1; } };
    id = setIv.call(window, counted, ms, ...rest);
    window.__lastIv = id;
    return id;
  };
  window.SpeechSynthesisUtterance = function (t) { this.text = t; };
  /* speechSynthesis is a read-only property of window: plain assignment is silently ignored. */
  /* With window.__holdSpeech set, an utterance is kept in window.__heldSpeech until the test ends it, as a long sentence would be. */
  window.__heldSpeech = [];
  Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { speak(u) { window.__said.push(u.text);
    if (window.__holdSpeech) window.__heldSpeech.push(u); else setTimeout(() => u.onend && u.onend(), 0); }, cancel() {} } });
  window.__recs = [];
  window.SpeechRecognition = function () {
    window.__recs.push(this);
    this.watch = window.__lastIv;
    /* Listening waits for the test to say something, as a person would; the page's own timeout ends it otherwise. */
    this.start = () => {
      this.started = true;
      window.__listens++;
      const tick = () => {
        if (this.stopped) return;   // a listener the page has stopped must not take the next section's words
        if (window.__heard.length) this.onresult && this.onresult({ results: [[{ transcript: window.__heard.shift() }]] });
        else setTimeout(tick, 20);
      };
      tick();
    };
    this.stop = () => { this.stopped = true; };
  };
  /* The microphone hears a phrase this instant: the open listener's onresult, run in the caller's own task.
     True when an open listener took it. */
  window.__hear = t => {
    const r = window.__recs.filter(x => x.started && !x.stopped).pop();
    if (!r || !r.onresult) return false;
    r.onresult({ results: [[{ transcript: t }]] });
    return true;
  };
};

(async () => {
  const browser = await launch();
  const errors = [], events = [];
  onDeath(() => ({ section, checks: passed + failed, errors, events: events.length ? events.join(', ') : 'none' }));

  /* ONE PAGE, LOADED ONCE. This suite opened the app four times, one page per section. On the
     owner's laptop the real build is 92 MB, and the fourth load ran out at 200 s 50 minutes into a
     full run. Each section now starts from a reset instead: no voice session, an empty scripted
     voice, and empty progress. */
  const page = watch(await browser.newPage({ viewport: { width: 430, height: 1000 } }), events, 'main');
  page.on('pageerror', e => errors.push(e.message));
  await page.addInitScript(STUB);
  await page.goto(URL, { waitUntil: 'load', timeout: 200000 });
  await booted(page);
  /* Home first, so the next toStudy() is a real screen change and reads a Study screen drawn after the reset. */
  const fresh = async () => {
    await page.evaluate(() => {
      stopVoice();
      window.__said = []; window.__heard = []; window.__listens = 0;
      S.srs = {}; S.chStats = {}; S.missed = new Set(); S.daily = {};
      goHome();
    });
    await onScreen(page, 'home', { marker: '.hero-h1' });
  };
  const toStudy = async (page) => {
    await page.evaluate(() => goSessions());
    await onScreen(page, 'sessions', { marker: '#sessionsPage' });
    await quiet(page);
  };
  const waitFor = (page, fn, arg) => page.waitForFunction(fn, arg, { timeout: 15000 });

  head('no speech in the browser: no card, and the rest is there');
  {
    await fresh();
    /* The scripted voice is set aside and put back: the same page, without speech. */
    await page.evaluate(() => { window.__stubSynth = window.speechSynthesis; Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: undefined }); });
    await toStudy(page);
    const r = await page.evaluate(() => ({ voice: !!document.getElementById('voiceCard'), plan: !!document.getElementById('mockCard') }));
    ok('no Voice card without speech APIs', r.voice === false, JSON.stringify(r));
    ok('the mock card is still there', r.plan === true);
    await page.evaluate(() => { Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: window.__stubSynth }); });
  }

  head('the card, and nothing spoken before the tap');
  await fresh();
  await toStudy(page);
  const card = await page.evaluate(() => {
    const b = document.getElementById('voiceStart');
    return { has: !!document.getElementById('voiceCard'), h: b ? b.offsetHeight : 0, said: window.__said.length, listens: window.__listens };
  });
  ok('the Voice card is on the Study screen', card.has);
  ok('its Start button is at least 44 px tall', card.h >= 44, card.h + ' px');
  ok('nothing was spoken or listened for before the tap', card.said === 0 && card.listens === 0, JSON.stringify(card));

  head('a spoken answer, scored and rated like a tap');
  /* The first answer is the key of whatever question is first, so "right" is measured, not assumed:
     it is read from the deck once the session has opened. The second is deliberately the wrong letter. */
  await page.click('#voiceStart');
  await onScreen(page, 'quiz', { marker: '.q-card' });
  await waitFor(page, () => window.__listens >= 1);
  const first = await page.evaluate(() => ({
    said: window.__said.slice(), n: S.questions.length, stem: VoiceMode.clean(S.questions[0].s), mode: S.mode,
    opts: S.questions[0].o.length,
    /* options with nothing to say once markup is removed: a figure-only option, read as a count, never as text */
    silent: S.questions[0].o.filter(o => !VoiceMode.clean(o && o.t)).length,
  }));
  ok('the session is a review session of up to ten questions', first.mode === 'due' && first.n >= 2 && first.n <= 10, first.n + ' in ' + first.mode);
  /* Details are counts, never text: on the owner's machine this runs on the licensed bank, and a detail is printed. */
  ok('the stem was read aloud', first.said.join(' ').includes(first.stem.split(/[.?!]/)[0].trim().slice(0, 30)), `${first.said.length} parts spoken, stem ${first.stem.length} characters`);
  const optLines = first.said.filter(t => /^Option [A-H]\./.test(t)).length;
  ok('every option was read by its letter', optLines === first.opts, `${optLines} of ${first.opts} options read, ${first.silent} with no text to read`);
  await page.evaluate(() => { window.__heard.push('skip'); });
  await waitFor(page, () => S.qIdx === 1);
  const skipped = await page.evaluate(() => ({ idx: S.qIdx, answered: S.answered, total: Object.values(S.chStats).reduce((a, c) => a + c.total, 0), said: window.__said.some(t => t === 'Skipping.') }));
  ok('"skip" moved the quiz screen on to the second question', skipped.idx === 1 && skipped.answered === false, JSON.stringify(skipped));
  ok('"skip" recorded no answer', skipped.total === 0, skipped.total + ' recorded');
  ok('"skip" was acknowledged out loud', skipped.said === true);

  /* second question: answer correctly */
  await waitFor(page, () => window.__listens >= 2);
  const letter = await page.evaluate(() => 'ABCDEFGH'[S.questions[1].ci]);
  const id1 = await page.evaluate(() => S.questions[1].id);
  await page.evaluate(l => { window.__heard.push('option ' + l); }, letter);
  await waitFor(page, id => S.srs[id] != null, id1);
  const right = await page.evaluate(id => ({ card: S.srs[id], total: Object.values(S.chStats).reduce((a, c) => a + c.total, 0), missed: S.missed.has(id), said: window.__said.filter(t => /^Correct\./.test(t)).length }), id1);
  ok('the spoken letter was scored as one answer', right.total === 1 && !right.missed, JSON.stringify({ t: right.total, m: right.missed }));
  ok('"Correct." was spoken, with the reason', right.said === 1);
  ok('a right answer was rated Good: first interval of two days or more, no lapse', right.card && right.card.ivl >= 2 && right.card.lapses === 0, JSON.stringify(right.card));

  head('a wrong letter, and stop');
  await fresh();
  const p2 = page;
  await toStudy(p2);
  await p2.click('#voiceStart');
  await onScreen(p2, 'quiz', { marker: '.q-card' });
  await waitFor(p2, () => window.__listens >= 1);
  const id0 = await p2.evaluate(() => S.questions[0].id);
  const wrong = await p2.evaluate(() => { const q = S.questions[0]; return 'ABCDEFGH'[(q.ci + 1) % q.o.length]; });
  await p2.evaluate(l => { window.__heard.push('option ' + l, 'stop'); }, wrong);
  await waitFor(p2, () => window.__said.some(t => /^Finished\./.test(t)));
  const done = await p2.evaluate(id => ({ missed: S.missed.has(id), srs: S.srs[id] || null, said: window.__said.filter(t => /^Not quite\./.test(t)).length, fin: window.__said.filter(t => /^Finished\./.test(t)) }), id0);
  ok('a wrong letter put the question on the miss list', done.missed === true);
  ok('"Not quite" was spoken, naming the answer', done.said === 1);
  ok('a wrong answer was rated Again: a lapse, due again tomorrow at the latest', done.srs !== null && done.srs.lapses === 1 && done.srs.ivl <= 1, JSON.stringify(done.srs));
  ok('"stop" ended the session with a spoken summary', done.fin.length === 1 && /1 of 1 correct|0 of 1 correct/.test(done.fin[0]), done.fin[0]);

  head('stopping closes the microphone at once, so a quick restart keeps its first answer');
  /* stopVoice() used to leave the open listener running until its own 250 ms
     watch noticed, and the watch asked whether any session was running. A new
     session started inside that window kept the old listener open, and it took
     the new session's first answer ("I did not catch that"): with WebKit's
     screen swaps instant, "a wrong letter, and stop" failed 4 runs in 12 on it.
     Counted in the same task as the stop, so no timing can rescue it. */
  await fresh();
  await toStudy(page);
  await page.click('#voiceStart');
  await onScreen(page, 'quiz', { marker: '.q-card' });
  await waitFor(page, () => window.__listens >= 1);
  const open = await page.evaluate(() => {
    const live = () => window.__recs.filter(r => r.started && !r.stopped).length;
    const before = live();
    stopVoice();
    return { before, after: live() };
  });
  ok('a listener was open before the stop, so the count can catch one left behind', open.before >= 1, JSON.stringify(open));
  ok('and none is open the moment stopVoice() returns', open.after === 0, JSON.stringify(open));

  head('a session that finishes its sentence after a restart does not end the new one');
  /* The owner leaves the quiz mid-question and starts voice again. The old
     session is still waiting on its sentence; when that sentence ends it
     finds itself no longer live and used to call stopVoice(), which ended
     whichever session was running: the new one. */
  await fresh();
  await toStudy(page);
  await page.evaluate(() => { window.__holdSpeech = true; window.__heldSpeech = []; });
  await page.click('#voiceStart');
  await onScreen(page, 'quiz', { marker: '.q-card' });
  await waitFor(page, () => window.__heldSpeech.length >= 1);
  const restart = await page.evaluate(async () => {
    const A = _voice, parts = VoiceMode.speakable(A.deck[A.state.i]).parts.length, first = window.__heldSpeech[0];
    goStudy();
    startVoice();
    const B = _voice;
    first.onend();                                   // A's sentence ends; A runs on in this task's microtasks
    await new Promise(r => setTimeout(r, 0));        // a task boundary, so they have all run
    return { parts, restarted: !!B && B !== A, bLive: _voice === B && B !== null, dock: !!document.getElementById('voiceDock') };
  });
  await page.evaluate(() => { window.__holdSpeech = false; window.__heldSpeech.splice(0).forEach(u => u.onend && u.onend()); });
  ok('(the old session had more of its question to say, and a new session started)', restart.parts >= 2 && restart.restarted, JSON.stringify(restart));
  ok('the new session is still running after the old one’s sentence ends', restart.bLive && restart.dock, JSON.stringify(restart));

  /* The same from a listener. The old session was listening when the fellow left and started again; its watch
     ends its own session when it finds it no longer live, and must leave the new one running. The read waits
     for that watch to have looked once since the restart. */
  await fresh();
  await toStudy(page);
  await page.click('#voiceStart');
  await onScreen(page, 'quiz', { marker: '.q-card' });
  await waitFor(page, () => window.__listens >= 1);
  const swap = await page.evaluate(() => {
    const A = _voice, rec = window.__recs[window.__recs.length - 1];
    const was = { aOpen: !!A && !!rec && rec.started === true && !rec.stopped, watch: rec ? rec.watch : null, ticks: rec ? (window.__ivTicks[rec.watch] || 0) : 0 };
    goStudy();
    startVoice();
    window.__B = _voice;
    return { ...was, restarted: !!_voice && _voice !== A };
  });
  await waitFor(page, w => w.watch == null || (window.__ivTicks[w.watch] || 0) > w.ticks, swap);
  const kept = await page.evaluate(() => ({ bLive: _voice !== null && _voice === window.__B, dock: !!document.getElementById('voiceDock') }));
  ok('(the old session was listening, and a new session started)', swap.aOpen && swap.restarted && swap.watch != null, JSON.stringify(swap));
  ok('the old listener’s watch, looking after the restart, leaves the new session running', kept.bLive && kept.dock, JSON.stringify(kept));

  head('leaving the quiz ends the session');
  await fresh();
  const p3 = page;
  await toStudy(p3);
  await p3.click('#voiceStart');
  await onScreen(p3, 'quiz', { marker: '.q-card' });
  await waitFor(p3, () => window.__listens >= 1);
  await p3.evaluate(() => { goStudy(); });
  await onScreen(p3, 'study', { marker: '#planCard' });
  const before = await p3.evaluate(() => ({ said: window.__said.length, listens: window.__listens }));
  await p3.waitForFunction(() => _voice === null, null, { timeout: 5000 }).catch(() => {});
  const after = await p3.evaluate(() => ({ said: window.__said.length, listens: window.__listens, live: _voice !== null }));
  ok('nothing more is spoken or listened for after leaving', after.said === before.said && after.listens === before.listens, JSON.stringify({ before, after }));
  ok('the session itself is over, not just quiet', after.live === false, JSON.stringify(after));

  head('moving the quiz by hand ends the session, and no letter lands on the question it moved to');
  /* The screen stays live under the voice: on an iPad the fellow can tap an option and a rating while the
     question is still being read. That moves the quiz on without the voice, which used to hear a letter for
     the question it had read, record it on the one the screen had moved to, and rate that card with the read
     question's verdict, one question out of step from then on. The taps call what the option and Good
     buttons call, once mid-sentence and once with the microphone open. */
  await fresh();
  await toStudy(page);
  await page.evaluate(() => { window.__holdSpeech = true; window.__heldSpeech = []; });
  await page.click('#voiceStart');
  await onScreen(page, 'quiz', { marker: '.q-card' });
  await waitFor(page, () => window.__heldSpeech.length >= 1);
  const midRead = await page.evaluate(() => {
    const live = _voice !== null;
    selectOpt(S.questions[0].ci); rateReview(3);
    return { live, idx: S.qIdx };
  });
  await page.evaluate(() => { window.__holdSpeech = false; window.__heldSpeech.splice(0).forEach(u => u.onend && u.onend()); });
  await waitFor(page, () => _voice === null || window.__listens >= 1);
  const read = await page.evaluate(() => ({ live: _voice !== null, listens: window.__listens, dock: !!document.getElementById('voiceDock') }));
  ok('(a session was reading, and the taps moved the screen on to the second question)', midRead.live && midRead.idx === 1, JSON.stringify(midRead));
  ok('a move by hand mid-sentence ends the session before it listens', !read.live && read.listens === 0 && !read.dock, JSON.stringify(read));

  /* With the microphone open and nothing said, the same taps used to leave it open, the dock reading "Listening",
     until the listen's own 9 s timeout: its 250 ms watch asked only whether the session was running and the screen
     was the quiz. The read waits for that watch to have looked once since the move (the stub counts its ticks),
     never for a length of time, so a microphone left open cannot be rescued by waiting longer. */
  await fresh();
  await toStudy(page);
  await page.click('#voiceStart');
  await onScreen(page, 'quiz', { marker: '.q-card' });
  await waitFor(page, () => window.__listens >= 1);
  const quietMove = await page.evaluate(() => {
    const rec = window.__recs[window.__recs.length - 1], d = document.getElementById('voiceDock');
    const was = { live: _voice !== null, open: !!rec && rec.started === true && !rec.stopped, dock: d ? d.querySelector('.vd-state').textContent : null };
    selectOpt(S.questions[0].ci); rateReview(3);
    return { ...was, idx: S.qIdx, watch: rec ? rec.watch : null, ticks: rec ? (window.__ivTicks[rec.watch] || 0) : 0 };
  });
  /* No watch found is the first check's failure to report, not a wait to time out on. */
  await waitFor(page, w => w.watch == null || (window.__ivTicks[w.watch] || 0) > w.ticks, quietMove);
  const closed = await page.evaluate(() => {
    const rec = window.__recs[window.__recs.length - 1], d = document.getElementById('voiceDock');
    return { stopped: !!rec && rec.stopped === true, dock: d ? d.querySelector('.vd-state').textContent : null, live: _voice !== null };
  });
  ok('(a session was listening, the dock said so, and the taps moved the screen on)',
     quietMove.live && quietMove.open && quietMove.dock === 'Listening' && quietMove.idx === 1 && quietMove.watch != null, JSON.stringify(quietMove));
  ok('a move by hand while listening closes the microphone at the listen’s next look, not at its 9 s timeout', closed.stopped, JSON.stringify(closed));
  ok('and the dock no longer says Listening, because the session is over', closed.dock !== 'Listening' && !closed.live, JSON.stringify(closed));

  await fresh();
  await toStudy(page);
  await page.click('#voiceStart');
  await onScreen(page, 'quiz', { marker: '.q-card' });
  await waitFor(page, () => window.__listens >= 1);
  /* The letter is the moved-to question's key where the read question has that option (recording it there would
     even look right), else A: it must be one both questions have, or neither would take it, fixed or not.
     It is heard in the same task as the taps: the listen's watch closes the microphone at its next look after a
     move (above), so a letter lands after one only inside that window, and this puts it there every run. */
  const midListen = await page.evaluate(() => {
    const live = _voice !== null, q0 = S.questions[0], q1 = S.questions[1];
    const k = q1 && q1.ci < q0.o.length ? q1.ci : 0;
    selectOpt(q0.ci); rateReview(3);
    const took = window.__hear('option ' + 'ABCDEFGH'[k]);
    return { live, idx: S.qIdx, id1: q1 && q1.id, took, both: !!q1 && k < q0.o.length && k < q1.o.length };
  });
  await waitFor(page, id => _voice === null || S.srs[id] != null, midListen.id1);
  const heard = await page.evaluate(id => ({ live: _voice !== null, answered: !!S.answers[1], rated: S.srs[id] != null,
    feedback: window.__said.filter(t => /^(Correct|Not quite)\./.test(t)).length }), midListen.id1);
  ok('(a session was listening, the taps moved the screen on, and the letter was heard)', midListen.live && midListen.idx === 1 && midListen.both && midListen.took === true, JSON.stringify(midListen));
  ok('a letter heard after a move by hand is not recorded, answered aloud or rated on the moved-to question', !heard.answered && !heard.rated && heard.feedback === 0, JSON.stringify(heard));
  ok('and the session ends', !heard.live, JSON.stringify(heard));

  head('an option tapped while the voice listens is not graded with the voice’s verdict');
  /* The quiz is not moved, only answered: a wrong option tapped while the
     microphone is open. The voice then hears the key. Its record found the
     question already answered and did nothing, but it still said "Correct"
     and rated the card Good: the tapped wrong answer graded as the spoken
     right one (found in review of the fix above). */
  await fresh();
  await toStudy(page);
  await page.click('#voiceStart');
  await onScreen(page, 'quiz', { marker: '.q-card' });
  await waitFor(page, () => window.__listens >= 1);
  /* The key is heard in the same task as the tap: the listen's watch now ends the listen at its next look after
     a tap (below), so a letter lands after one only inside that window, and this puts it there every run. */
  const tapped = await page.evaluate(() => {
    const q0 = S.questions[0], wrong = (q0.ci + 1) % q0.o.length;
    const live = _voice !== null;
    selectOpt(wrong);
    const answered = S.answered, wrongTapped = S.selected === wrong && wrong !== q0.ci;
    const took = window.__hear('option ' + 'ABCDEFGH'[q0.ci]);
    return { live, idx: S.qIdx, id0: q0.id, answered, wrongTapped, took };
  });
  await waitFor(page, id => _voice === null || S.srs[id] != null, tapped.id0);
  const graded = await page.evaluate(id => ({ live: _voice !== null, rated: S.srs[id] != null,
    feedback: window.__said.filter(t => /^(Correct|Not quite)\./.test(t)).length }), tapped.id0);
  ok('(a session was listening, a wrong option was tapped on the same question, and the key was heard)',
     tapped.live && tapped.idx === 0 && tapped.answered && tapped.wrongTapped && tapped.took === true, JSON.stringify(tapped));
  ok('the card is not rated with the voice’s verdict, and no verdict is spoken', !graded.rated && graded.feedback === 0, JSON.stringify(graded));
  ok('and the session ends', !graded.live, JSON.stringify(graded));

  /* With nothing said after the tap, the microphone used to stay open, the dock reading "Listening", until the
     listen's 9 s timeout: the watch asked whether the session was live, and a tap that does not move the quiz
     leaves it live. The read waits for the watch to have looked once since the tap, never for a length of time. */
  await fresh();
  await toStudy(page);
  await page.click('#voiceStart');
  await onScreen(page, 'quiz', { marker: '.q-card' });
  await waitFor(page, () => window.__listens >= 1);
  const quietTap = await page.evaluate(() => {
    const rec = window.__recs[window.__recs.length - 1], d = document.getElementById('voiceDock');
    const was = { live: _voice !== null, open: !!rec && rec.started === true && !rec.stopped, dock: d ? d.querySelector('.vd-state').textContent : null };
    const q0 = S.questions[0];
    selectOpt((q0.ci + 1) % q0.o.length);
    return { ...was, idx: S.qIdx, answered: S.answered, id0: q0.id, watch: rec ? rec.watch : null, ticks: rec ? (window.__ivTicks[rec.watch] || 0) : 0 };
  });
  /* No watch found is the first check's failure to report, not a wait to time out on. */
  await waitFor(page, w => w.watch == null || (window.__ivTicks[w.watch] || 0) > w.ticks, quietTap);
  const tapClosed = await page.evaluate(id => {
    const rec = window.__recs[window.__recs.length - 1], d = document.getElementById('voiceDock');
    return { stopped: !!rec && rec.stopped === true, dock: d ? d.querySelector('.vd-state').textContent : null, live: _voice !== null, rated: S.srs[id] != null };
  }, quietTap.id0);
  ok('(a session was listening, the dock said so, and an option was tapped without moving the quiz)',
     quietTap.live && quietTap.open && quietTap.dock === 'Listening' && quietTap.idx === 0 && quietTap.answered && quietTap.watch != null, JSON.stringify(quietTap));
  ok('a tap while listening closes the microphone at the listen’s next look, not at its 9 s timeout', tapClosed.stopped, JSON.stringify(tapClosed));
  ok('and the dock no longer says Listening, the session over, the card unrated', tapClosed.dock !== 'Listening' && !tapClosed.live && !tapClosed.rated, JSON.stringify(tapClosed));

  head('clinical comparisons and an eight-option answer reach the real voice flow');
  await fresh();
  await toStudy(page);
  await page.evaluate(() => {
    const q = QBYID[planNow(10).items[0].id];
    window.__voicePublicFixture = { q, s: q.s, o: q.o, ci: q.ci, ex: q.ex };
    q.s = 'EF <35% and HR >100. Choose the public example.';
    q.o = Array.from({ length: 8 }, (_, i) => ({ t: 'Public example ' + (i + 1) }));
    q.ci = 7; q.ex = 'Public explanation.';
  });
  try {
    await page.click('#voiceStart');
    await onScreen(page, 'quiz', { marker: '.q-card' });
    await waitFor(page, () => window.__listens >= 1);
    const spoken = await page.evaluate(() => window.__said.join(' '));
    ok('the actual speaker receives both clinical comparisons and their measurements',
      spoken.includes('EF less than 35% and HR greater than 100.'));
    await page.evaluate(() => { window.__heard.push('option h'); });
    await waitFor(page, () => S.srs[window.__voicePublicFixture.q.id] != null || window.__listens > 1);
    const graded = await page.evaluate(() => {
      const q = window.__voicePublicFixture.q;
      return { rated: S.srs[q.id] != null, missed: S.missed.has(q.id), correct: (S.chStats[q.ch] || {}).correct, total: (S.chStats[q.ch] || {}).total };
    });
    ok('spoken H records and rates the eighth option through the ordinary answer path exactly once',
      graded.rated && !graded.missed && graded.correct === 1 && graded.total === 1);
  } finally {
    await page.evaluate(() => {
      stopVoice();
      const f = window.__voicePublicFixture;
      Object.assign(f.q, { s: f.s, o: f.o, ci: f.ci, ex: f.ex });
      delete window.__voicePublicFixture;
    });
  }

  ok('no page errors', errors.length === 0, errors.join(' | '));
  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
