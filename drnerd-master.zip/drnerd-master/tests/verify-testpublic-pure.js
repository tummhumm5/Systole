#!/usr/bin/env node
'use strict';
/*
 * `npm test` runs every check that needs no export, and says so honestly.
 *
 *   node tests/verify-testpublic-pure.js
 *
 * scripts/test-public.js takes its suite list from the workflow, so the first
 * half here holds that reading to the workflow itself: the pure suites are the
 * ones that launch no browser, the browser suites are the ones that do, and
 * nothing the two jobs invoke is dropped. The second half runs it on invented
 * suites in a temporary folder — tiny scripts that pass or fail on purpose —
 * because a runner is only as good as what it does with a failure, a missing
 * file, a browser that is not there, and the half it did not run.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { suitesFromWorkflow, run } = require('../scripts/test-public.js');

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
const head = t => console.log('\n── ' + t + ' ──');
const ROOT = path.join(__dirname, '..');

head('the list is the workflow’s, split the way the suites actually are');
const yml = fs.readFileSync(path.join(ROOT, '.github', 'workflows', 'verify.yml'), 'utf8');
const { pure, browser, synthetic, split } = suitesFromWorkflow(yml);
const synNames = synthetic.suites.map(x => x.name);
/* The same "uses a browser" rule verify-stats and verify-engine apply. */
/* The rule verify.js tags suites with (tests/_targets.js tagsOf), not a copy
   of it: a copy here saw only direct launches. */
const launches = n => require('./_targets.js').tagsOf(n.replace(/^verify-/, '')).includes('browser');
ok('it finds the pure suites', pure.length > 20, `${pure.length}`);
ok('and the browser suites', browser.length > 0, browser.join(', '));
ok('no pure suite launches a browser', pure.every(n => !launches(n)), pure.filter(launches).join(', ') || 'none');
ok('every browser suite does', browser.every(launches), browser.filter(n => !launches(n)).join(', ') || 'none');
/* Each suite once: synthetic-webkit runs some of the synthetic job's suites
   again in WebKit, and npm test runs them once, in the engine it is given. A
   suite only that job named would still be missing below. */
const all = [...new Set([...yml.matchAll(/node\s+tests\/(verify-[a-z0-9-]+)\.js/g)].map(m => m[1]))];
ok('the synthetic job\u2019s suites are found, each with a target', synNames.length > 0 && synthetic.suites.every(x => /\.html$/.test(x.target)),
   `${synNames.length} suites`);
ok('and every one of them launches a browser', synNames.every(launches), synNames.filter(n => !launches(n)).join(', ') || 'none');
ok('the commands that build their target are found, and each script exists',
   synthetic.build.length >= 2 && synthetic.build.every(([s]) => fs.existsSync(path.join(ROOT, s))),
   synthetic.build.map(c => c[0]).join(', '));
ok('and the last of them writes the target the suites read',
   synthetic.build.length > 0 && synthetic.suites.every(x => synthetic.build[synthetic.build.length - 1].includes(x.target)));
/* The synthetic jobs are matrices of shards that download one build. npm test
   reads the build from the job that makes it, and the suites from the whole
   job body, which is every shard's list at once (scripts/shard.js). */
{
  const { jobBody } = require('../scripts/test-public.js');
  const { shardOf } = require('../scripts/shard.js');
  const stats = JSON.parse(fs.readFileSync(path.join(ROOT, 'tests', 'test-stats.json'), 'utf8'));
  const cmds = b => [...(b || '').matchAll(/^\s+node\s+scripts\/(synthetic-export|assemble-app)\.js/gm)].length;
  ok('the build commands are the synthetic-build job\u2019s, and neither sharded job builds again',
     cmds(jobBody(yml, 'synthetic-build')) === 2 && cmds(jobBody(yml, 'synthetic-browser')) === 0 && cmds(jobBody(yml, 'synthetic-webkit')) === 0);
  const union = [1, 2, 3, 4].flatMap(i => shardOf(yml, stats, 'synthetic-browser', i, 4));
  ok('and the suites npm test runs are the union of synthetic-browser\u2019s shards, not one of them',
     synNames.length > 30 && JSON.stringify(union.slice().sort()) === JSON.stringify(synNames.slice().sort()), `${union.length} in the shards, ${synNames.length} read`);
}
ok('together they are every suite the workflow runs, each once',
   JSON.stringify(pure.concat(browser, synNames).sort()) === JSON.stringify(all.slice().sort()), `${pure.length + browser.length + synNames.length} of ${all.length}`);
/* The split-build job names no suite, so the check above cannot see it: its
   commands are held here, in the order npm test will run them. */
ok('the split-build job’s commands are found, and each script exists',
   split.length >= 3 && split.every(([s]) => fs.existsSync(path.join(ROOT, s))), split.map(c => c[0]).join(', ') || 'none');
const splitLast = split[split.length - 1] || [];
ok('and the last of them checks the split build alone, through verify.js --pwa',
   splitLast[0] === 'scripts/verify.js' && splitLast.includes('--pwa') && / --only pwa( |$)/.test(splitLast.join(' ')), splitLast.join(' '));
{
  const target = splitLast[1];
  const at = (script, has) => split.findIndex(c => c[0] === script && has(c));
  const made = at('scripts/assemble-app.js', c => c[c.indexOf('--out') + 1] === target);
  const taken = at('scripts/extract-content.js', c => c[1] === target);
  ok('on a build an earlier command writes, whose content is taken out before the check',
     made >= 0 && taken > made && taken < split.length - 1, `${target}: written at ${made}, extracted at ${taken}, checked at ${split.length - 1}`);
}

head('the workflow runs once per commit');
{
  /* A push to a branch with a pull request fired this workflow as `push` and
     as `pull_request`: every job twice per commit. Held in the workflow's own
     trigger block, comments blanked. */
  const top = yml.slice(yml.indexOf('\non:'), yml.indexOf('\njobs:')).replace(/#.*$/gm, '');
  ok('`push` is for master only, so a branch with a pull request is not run twice',
     /\n\s+push:\s*\n\s+branches:\s*\[\s*master\s*\]/.test(top), top.replace(/\s+/g, ' ').slice(0, 120));
  ok('pull requests are still tested', /\n\s+pull_request:/.test(top));
  ok('a newer push cancels the pull request run before it, and never a master run',
     /cancel-in-progress:\s*\$\{\{\s*github\.event_name\s*==\s*'pull_request'\s*\}\}/.test(top));
}

head('reading a workflow');
const SYN = syn => !syn ? '' : `  synthetic-browser:\n    steps:\n      - name: build\n        run: |\n${syn.build.map(c => `          node ${c.join(' ')}\n`).join('')}` +
  syn.suites.map(n => `      - name: ${n} (1 checks)\n        run: node tests/${n}.js ${syn.target}\n`).join('');
/* A split-build job the way the real one is written: its first commands in a
   block, its last on a step of its own. */
const SPLIT = cmds => !cmds ? '' : `  split-build:\n    steps:\n      - name: make it\n        run: |\n` +
  cmds.slice(0, -1).map(c => `          node ${c.join(' ')}\n`).join('') +
  `      - name: check it\n        run: node ${cmds[cmds.length - 1].join(' ')}\n`;
const Y = (logic, browserJob, after, syn, split) =>
  `jobs:\n  logic:\n    steps:\n${logic.map(n => `      - name: ${n} (1 checks)\n        run: node tests/${n}.js\n`).join('')}` +
  `  public-browser:\n    strategy:\n      matrix:\n        engine: [chromium]\n    steps:\n${browserJob.map(n => `      - name: ${n}\n        run: node tests/${n}.js\n`).join('')}` +
  SYN(syn) + SPLIT(split) + (after ? `  build-guard:\n    steps:\n      - run: node tests/${after}.js\n` : '');
{
  const s = suitesFromWorkflow(Y(['verify-a', 'verify-b'], ['verify-c'], 'verify-z'));
  ok('a job’s suites end where the next job begins', JSON.stringify(s) === JSON.stringify({ pure: ['verify-a', 'verify-b'], browser: ['verify-c'], synthetic: { build: [], suites: [] }, split: [] }), JSON.stringify(s));
  const cmds = [['scripts/one.js', 'a.html'], ['scripts/two.js', 'a.html', '--out', 'b.html'], ['scripts/three.js', 'b.html', '--pwa']];
  const p = suitesFromWorkflow(Y(['verify-a'], ['verify-c'], 'verify-z', null, cmds));
  ok('a split-build job is read as its commands, in order, from a block and from a step of its own',
     JSON.stringify(p.split) === JSON.stringify(cmds), JSON.stringify(p.split));
  let msg = '';
  try { suitesFromWorkflow('jobs:\n  logic:\n    steps: []\n'); } catch (e) { msg = e.message; }
  ok('a workflow without the browser job is refused, not read as zero browser suites', /no public-browser job/.test(msg), msg || 'accepted');
}

head('running them');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'testpublic-'));
fs.mkdirSync(path.join(TMP, 'tests'));
const suite = (n, body) => fs.writeFileSync(path.join(TMP, 'tests', n + '.js'), body);
suite('verify-a', 'process.exit(0)');
suite('verify-b', 'console.log("  FAIL  zq"); process.exit(1)');
suite('verify-timeout', 'console.log("  PASS  with no errors on load"); console.error("locator.waitFor: Timeout 60000ms exceeded."); process.exit(1)');
suite('verify-quiet-failure', 'console.log("the dependency never answered"); process.exit(1)');
suite('verify-mixed-failure', 'console.error("a dependency warning"); console.log("  FAIL  the note was not persisted"); process.exit(1)');
suite('verify-death-warning', 'console.error("a dependency warning"); console.log("last section reached: drawing the trace"); console.log("page.evaluate: Target page has been closed"); process.exit(1)');
suite('verify-c', 'process.exit(process.env.SYSTOLE_ENGINE === "webkit" ? 0 : 3)');
suite('verify-g', 'process.exit(["GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_CONFIG_PARAMETERS", "GIT_CONFIG_COUNT", "GIT_CONFIG_KEY_0"].some(k => k in process.env) ? 4 : 0)');
const go = (logic, br, opts, syn, split) => {
  const lines = [];
  const r = run(Object.assign({ root: TMP, yml: Y(logic, br, null, syn, split), log: s => lines.push(s) }, opts));
  return Object.assign(r, { text: lines.join('\n') });
};
{
  const r = go(['verify-a', 'verify-b'], ['verify-c'], { pure: true });
  ok('a failing suite fails the run, and is named', r.code === 1 && JSON.stringify(r.failed) === '["verify-b"]', JSON.stringify(r.failed));
}
{
  const r = go(['verify-timeout'], ['verify-c'], { pure: true });
  ok('a timeout reports stderr instead of a successful assertion mentioning errors',
     r.code === 1 && r.text.includes('locator.waitFor: Timeout 60000ms exceeded.') && !r.text.includes('with no errors on load'), r.text);
  const quiet = go(['verify-quiet-failure'], ['verify-c'], { pure: true });
  ok('a failure without an Error or FAIL keyword still reports its output',
     quiet.code === 1 && quiet.text.includes('the dependency never answered'), quiet.text);
  const death = go(['verify-death-warning'], ['verify-c'], { pure: true });
  ok('a stderr warning cannot hide a death diagnostic on stdout',
     death.code === 1 && death.text.includes('drawing the trace') && death.text.includes('Target page has been closed') && death.text.includes('a dependency warning'), death.text);
  const mixed = go(['verify-mixed-failure'], ['verify-c'], { pure: true });
  ok('stderr does not hide a failed assertion on stdout',
     mixed.code === 1 && mixed.text.includes('a dependency warning') && mixed.text.includes('the note was not persisted'), mixed.text);
}
{
  const r = go(['verify-a', 'verify-gone'], ['verify-c'], { pure: true });
  ok('a suite whose file is missing is a failure, not a skip', r.code === 1 && r.failed.includes('verify-gone'), JSON.stringify(r.failed));
}
{
  const r = go(['verify-a'], ['verify-c'], { pure: true });
  const last = r.text.trim().split('\n').slice(-2)[0];
  ok('--pure passes on passing suites', r.code === 0 && r.ran.length === 1);
  ok('and says which browser suites it did not run, never "all"',
     /browser suites NOT run: verify-c/.test(last) && !/\ball\b/.test(last), last);
}
{
  /* engine pinned: the hint names the engine asked for, so an ambient
     SYSTOLE_ENGINE=webkit would otherwise make it say webkit. */
  const r = go(['verify-a'], ['verify-c'], { engine: 'chromium', executablePath: path.join(TMP, 'no-such-browser') });
  ok('with no browser installed, nothing runs and the run fails', r.code === 1 && r.ran.length === 0, JSON.stringify(r.ran));
  ok('and it says how to install one, or to run the pure half', /npx playwright install chromium/.test(r.text) && /test:pure/.test(r.text));
}
{
  const r = go(['verify-a'], ['verify-c'], { executablePath: process.execPath, engine: 'webkit' });
  ok('the full run runs the browser suites too, on the engine asked for', r.code === 0 && JSON.stringify(r.ran) === '["verify-a","verify-c"]', r.failed.join(',') || JSON.stringify(r.ran));
  const r2 = go(['verify-a'], ['verify-c'], { executablePath: process.execPath, engine: 'chromium' });
  ok('and a suite sees the engine it was handed, not a default', r2.code === 1 && r2.failed.includes('verify-c'));
  let msg = '';
  try { go(['verify-a'], ['verify-c'], { engine: 'safari' }); } catch (e) { msg = e.message; }
  ok('an engine that is not one is refused before anything runs', /not an engine/.test(msg), msg || 'accepted');
  msg = '';
  try { go([], ['verify-c'], { pure: true }); } catch (e) { msg = e.message; }
  ok('a logic job with no suites is refused, not reported as a pass', /invokes no suites/.test(msg), msg || 'accepted');
}
{
  /* What git hands the commands it runs: a linked worktree's pre-push hook
     gets GIT_DIR and its siblings, and `git -c …` (or `rebase -x`, `bisect
     run`) passes its settings on. A suite that inherits them runs its
     throwaway repositories' git commands against the real one, or with the
     caller's settings. */
  const VARS = ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_CONFIG_PARAMETERS', 'GIT_CONFIG_COUNT', 'GIT_CONFIG_KEY_0'];
  const keep = {}; for (const k of VARS) keep[k] = process.env[k];
  Object.assign(process.env, { GIT_DIR: path.join(TMP, 'not-this'), GIT_WORK_TREE: TMP, GIT_INDEX_FILE: path.join(TMP, 'idx'),
    GIT_CONFIG_PARAMETERS: "'commit.gpgsign'='true'", GIT_CONFIG_COUNT: '1', GIT_CONFIG_KEY_0: 'core.bare' });
  let r;
  try { r = go(['verify-g'], [], { pure: true }); }
  finally { for (const k in keep) { if (keep[k] === undefined) delete process.env[k]; else process.env[k] = keep[k]; } }
  ok('a suite run from a git hook does not inherit where git looks for the repository', r.code === 0 && r.ran.includes('verify-g'), JSON.stringify(r.failed));
}
head('the synthetic build, then its suites');
{
  /* A build that writes the target, a suite that passes only when handed a
     target that exists, and a suite that leaves a mark when it runs at all. */
  fs.mkdirSync(path.join(TMP, 'scripts'));
  fs.writeFileSync(path.join(TMP, 'scripts', 'mk.js'), 'require("fs").writeFileSync(process.argv.slice(2)[0], "x")');
  fs.writeFileSync(path.join(TMP, 'scripts', 'broken.js'), 'process.exit(1)');
  /* argv.slice, not argv[2], in both fixtures: tests/_targets.js tags a
     suite "build" when its source binds argv[2], and verify-engine expects a
     suite that mentions it to bind a target. A fixture's text is in this
     suite's source, so it read as this suite taking a build. */
  suite('verify-s', 'const f = process.argv.slice(2)[0]; require("fs").writeFileSync(require("path").join(__dirname, "ran-s"), "1"); process.exit(f && require("fs").existsSync(f) ? 0 : 4)');
  const T = path.join(TMP, 'syn.html');
  const parsed = suitesFromWorkflow(Y(['verify-a'], ['verify-c'], null, { build: [['scripts/mk.js', T]], suites: ['verify-s'], target: T }));
  ok('a synthetic job is read as its build and its suites, each with its target',
     JSON.stringify(parsed.synthetic) === JSON.stringify({ build: [['scripts/mk.js', T]], suites: [{ name: 'verify-s', target: T }] }),
     JSON.stringify(parsed.synthetic));
  const good = go(['verify-a'], [], { executablePath: process.execPath, engine: 'chromium' },
                  { build: [['scripts/mk.js', T]], suites: ['verify-s'], target: T });
  ok('the build runs first, and each suite is handed the target', good.code === 0 && good.ran.includes('verify-s'),
     good.failed.join(',') || JSON.stringify(good.ran));
  fs.rmSync(T, { force: true }); fs.rmSync(path.join(TMP, 'tests', 'ran-s'), { force: true });
  const bad = go(['verify-a'], [], { executablePath: process.execPath, engine: 'chromium' },
                 { build: [['scripts/broken.js'], ['scripts/mk.js', T]], suites: ['verify-s'], target: T });
  ok('a build that fails fails its suites, rather than skipping them', bad.code === 1 && bad.failed.includes('verify-s'), JSON.stringify(bad.failed));
  ok('and they are not run against a build that is not there', !fs.existsSync(path.join(TMP, 'tests', 'ran-s')) && !fs.existsSync(T));
  ok('and the run says the build is why', /synthetic build failed at scripts\/broken\.js/.test(bad.text));
  fs.rmSync(T, { force: true });
  const p = go(['verify-a'], [], { pure: true }, { build: [['scripts/mk.js', T]], suites: ['verify-s'], target: T });
  ok('--pure names them among the suites it did not run', p.notRun.includes('verify-s') && !fs.existsSync(T), JSON.stringify(p.notRun));
}
head('the split build, after the synthetic suites');
{
  /* A command that records the engine it was handed, so the run's engine is
     seen to reach the split build as it reaches a suite. */
  fs.writeFileSync(path.join(TMP, 'scripts', 'eng.js'), 'require("fs").writeFileSync(process.argv.slice(2)[0], String(process.env.SYSTOLE_ENGINE))');
  const T = path.join(TMP, 'syn2.html'), A = path.join(TMP, 'split-a'), E = path.join(TMP, 'split-engine');
  const syn = { build: [['scripts/mk.js', T]], suites: ['verify-s'], target: T };
  const good = go(['verify-a'], [], { executablePath: process.execPath, engine: 'webkit' }, syn,
                  [['scripts/mk.js', A], ['scripts/eng.js', E]]);
  ok('npm test runs the split-build job’s commands, in order, after the synthetic suites',
     good.code === 0 && good.ran.includes('split-build') && fs.existsSync(A) &&
     good.text.indexOf('split  node scripts/mk.js') > good.text.indexOf('verify-s'), good.failed.join(',') || JSON.stringify(good.ran));
  ok('in the engine it was given', fs.existsSync(E) && fs.readFileSync(E, 'utf8') === 'webkit', fs.existsSync(E) ? fs.readFileSync(E, 'utf8') : 'not run');
  ok('and says the split build passed with the rest', /and the split build made from it\./.test(good.text), good.text.trim().split('\n').slice(-2)[0]);
  for (const f of [T, A, E]) fs.rmSync(f, { force: true });
  const B = path.join(TMP, 'split-b');
  const bad = go(['verify-a'], [], { executablePath: process.execPath, engine: 'chromium' }, null,
                 [['scripts/broken.js'], ['scripts/mk.js', B]]);
  ok('a command that fails fails the run, under the job’s name', bad.code === 1 && JSON.stringify(bad.failed) === '["split-build"]', JSON.stringify(bad.failed));
  ok('and the commands after it do not run, and the run says which one failed',
     !fs.existsSync(B) && /split-build\s+failed at scripts\/broken\.js/.test(bad.text), bad.text.split('\n').filter(l => /split/.test(l)).join(' | '));
  const C = path.join(TMP, 'split-c');
  const p = go(['verify-a'], [], { pure: true }, null, [['scripts/mk.js', C]]);
  ok('--pure names the split build among what it did not run, and runs none of it',
     p.notRun.includes('split-build') && !fs.existsSync(C), JSON.stringify(p.notRun));
}
head('the public CLI refuses unexpected arguments and help starts no suite');
{
  const { spawnSync } = require('child_process');
  for (const file of ['test-public.js', 'gitenv.js'])
    fs.copyFileSync(path.join(ROOT, 'scripts', file), path.join(TMP, 'scripts', file));
  fs.mkdirSync(path.join(TMP, '.github', 'workflows'), { recursive: true });
  fs.writeFileSync(path.join(TMP, '.github', 'workflows', 'verify.yml'), Y(['verify-cli-probe'], ['verify-c']));
  fs.writeFileSync(path.join(TMP, 'tests', '_engine.js'),
    'module.exports={ENGINES:["chromium","webkit","firefox"],DEFAULT_ENGINE:"chromium"};');
  const marker = path.join(TMP, 'tests', 'cli-was-run');
  suite('verify-cli-probe', 'require("fs").writeFileSync(require("path").join(__dirname,"cli-was-run"),"yes");');
  for (const [label, args, status, diagnostic] of [
    ['--help', ['--pure', '--help'], 0, /Usage:/],
    ['-h', ['--pure', '-h'], 0, /Usage:/],
    ['an unknown option', ['--pure', '--typo'], 2, /Unexpected argument.*--typo/],
    ['an unexpected target', ['--pure', 'extra.html'], 2, /Unexpected argument.*extra.html/],
    ['--plan with --pure, which has no browser suite to plan', ['--pure', '--plan'], 2, /--plan says what the browser suites would do/],
  ]) {
    fs.rmSync(marker, { force: true });
    const r = spawnSync(process.execPath, [path.join(TMP, 'scripts', 'test-public.js'), ...args],
      { cwd: TMP, encoding: 'utf8', timeout: 10000 });
    ok(`${label} starts no public suite`, r.status === status &&
       diagnostic.test((r.stdout || '') + (r.stderr || '')) && !fs.existsSync(marker),
       `exit ${r.status}; suite launched ${fs.existsSync(marker)}`);
  }
  const cli = path.join(TMP, 'scripts', 'test-public.js');
  fs.rmSync(marker, { force: true });
  const fr = spawnSync(process.execPath, [cli, '--pure', '--fresh'], { cwd: TMP, encoding: 'utf8', timeout: 10000 });
  ok('--fresh is accepted with --pure, which keeps no results to be fresh about: the pure suites run', fr.status === 0 && fs.existsSync(marker), `exit ${fr.status}; ${String(fr.stderr).slice(0, 120)}`);
  const hp = spawnSync(process.execPath, [cli, '--help'], { cwd: TMP, encoding: 'utf8', timeout: 10000 });
  ok('help names --fresh and --plan, and what turns the result cache off', /--fresh/.test(hp.stdout) && /--plan/.test(hp.stdout) && /\bCI\b/.test(hp.stdout) && /SYSTOLE_NO_CACHE/.test(hp.stdout), String(hp.stdout).split('\n').slice(0, 3).join(' | '));
}
fs.rmSync(TMP, { recursive: true, force: true });

head('the commands say what they run');
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('npm test is the no-export run', pkg.scripts.test === 'node scripts/test-public.js', pkg.scripts.test);
ok('npm run test:pure is its browser-free half', pkg.scripts['test:pure'] === 'node scripts/test-public.js --pure', pkg.scripts['test:pure']);
ok('npm run test:fresh measures every browser suite now', pkg.scripts['test:fresh'] === 'node scripts/test-public.js --fresh', pkg.scripts['test:fresh']);
ok('npm run test:plan says what npm test would reuse and run, and runs no suite', pkg.scripts['test:plan'] === 'node scripts/test-public.js --plan', pkg.scripts['test:plan']);
ok('npm run test:private is the whole registry against your build', pkg.scripts['test:private'] === 'node scripts/verify.js', pkg.scripts['test:private']);

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
