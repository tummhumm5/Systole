#!/usr/bin/env node
/*
 * Behavioural checks for the startup pass.
 *
 *   NODE_PATH=$(npm root -g) node tests/verify-splash.js /path/to/patched.html
 *
 * The claim being tested is not "a splash element exists" — it is that the
 * splash is on screen during the window where the app is not, and gone
 * afterwards. So the checks that matter here are the timing ones: the splash
 * markup has to precede the script in the document, and it has to be visible
 * at a point when the app still has not rendered.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const { launch, cpuThrottle, isEngineNoise } = require('./_engine');
const { onDeath, watch } = require('./_deathnote.js');
const { booted } = require('./_render.js');

const target = process.argv[2];
if (!target) { console.error('usage: node tests/verify-splash.js <patched.html>'); process.exit(1); }
/* Accepts a path (single-file build) or an http URL (the Stage 1 PWA
   build, which has to be served because it fetches its content). */
const URL = /^https?:\/\//.test(target) ? target : 'file://' + path.resolve(target);

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

(async () => {
  head('document order: the splash must not be waiting on the script it hides');
  /* Read the document as it is actually served, so this works against both the
     single-file build on disk and the Stage 1 shell over http. */
  const raw = /^https?:\/\//.test(target)
    ? await (await fetch(target)).text()
    : fs.readFileSync(target, 'utf8');
  const splashAt = raw.indexOf('<div id="splash"');
  /* Whichever way the content arrives — inline in the single file, or fetched
     by the Stage 1 loader — the splash has to come first. */
  const inlineAt = raw.indexOf('const ALL_Q=');
  const loaderAt = raw.indexOf("fetch('content/questions.json'");
  const bigScriptAt = inlineAt > -1 ? inlineAt : loaderAt;
  ok('splash markup appears before the question bank / main script',
     splashAt > -1 && bigScriptAt > -1 && splashAt < bigScriptAt,
     `splash@${splashAt} payload@${bigScriptAt} (${inlineAt > -1 ? 'inline' : 'fetched'})`);
  ok('splash never intercepts input', /#splash\{[^}]*pointer-events:none/.test(raw));
  /* The pre-paint boot script reads the saved theme and stamps the mode and
     palette attributes before the splash paints. It used to be a bare
     light/dark toggle; since the theme system it maps a preset id to a
     [mode, palette] pair — but the claim is unchanged: storage is consulted,
     and the attributes are set, ahead of the splash. */
  ok('theme is adopted from storage before the splash paints',
     raw.indexOf("accsap12.v2") < splashAt &&
     /setAttribute\('data-theme'/.test(raw.slice(0, splashAt)) &&
     /setAttribute\('data-palette'/.test(raw.slice(0, splashAt)));
  ok('the loading screen does not depend on Heart3D',
     !/id="splash"[\s\S]{0,900}Heart3D/.test(raw));

  const browser = await launch();
  /* Six pages, one per section, each closed before the next opens — so "the
     page closed" on its own says nothing and every event carries the section
     that owned it. The last block keeps its own array because it asserts on
     them; the rest route through watch()'s fourth argument. See
     tests/_deathnote.js. */
  const errors = [], events = [];
  onDeath(() => ({ section, checks: passed + failed, errors,
                   events: events.length ? events.join(', ') : 'none' }));

  head('the splash covers the blank window before the app renders');
  {
    const page = watch(await browser.newPage({ viewport: { width: 834, height: 1112 } }), events, 'splash covers blank', errors);
    /* Throttling widens the gap this section is trying to observe; it does
       not create it. Where the engine cannot throttle, the ordering claim is
       still the claim — just measured through a narrower window, which the
       detail line says out loud so a tight number is not read as a tight
       margin. */
    const throttled = await cpuThrottle(page, 4);
    /* Record when each first appears rather than trying to catch the gap by
       polling. Racing it was fine against the 26 MB single file, where the gap
       is seconds wide; against the Stage 1 shell the app can render before the
       first poll comes back, and "I could not observe the gap" is not the same
       finding as "the splash was late". Ordering is the actual claim. */
    /* rAF rather than a MutationObserver: an init script runs before
       document.documentElement exists, so observing it throws and takes the
       rest of the init script with it. */
    await page.addInitScript(() => {
      window.__t = {};
      (function tick() {
        if (!window.__t.splash && document.getElementById('splash')) window.__t.splash = performance.now();
        if (document.querySelector('#splash .sp-trace')) window.__t.trace = true;
        if (!window.__t.app && document.querySelector('.hero-h1')) window.__t.app = performance.now();
        if (!window.__t.app) requestAnimationFrame(tick);
      })();
    });
    page.goto(URL, { waitUntil: 'commit' }).catch(() => {});
    /* Tolerated, not awaited for its own sake, and ONLY here. The init script
       above is what records when #splash and the app each first appear, and
       the assertion below already treats a splash that never came as a
       failure with numbers attached. Letting this throw turns "the splash was
       late on this engine" — the finding — into a suite that reports nothing,
       which is exactly how WebKit's version of this looked before anyone ran
       it. The four later waits stay strict: their sections need the splash on
       screen to have anything to examine. */
    await page.waitForSelector('#splash', { timeout: 30000 }).catch(() => {});
    await page.waitForFunction(() => window.__t && window.__t.app, null, { timeout: 120000 });
    const during = await page.evaluate(() => ({
      splashAt: Math.round(window.__t.splash),
      appAt: Math.round(window.__t.app),
      traceAnimated: window.__t.trace === true,
    }));
    ok('the splash is on screen before the app renders',
       during.splashAt !== undefined && during.splashAt !== null
       && during.splashAt <= during.appAt,
       `splash@${during.splashAt}ms  app@${during.appAt}ms  (covered ${during.appAt - during.splashAt}ms`
       + `${throttled ? ', CPU at 1/4' : ', UNTHROTTLED — this engine has no CDP'})`);
    ok('the rhythm strip is present on it', during.traceAnimated);

    await page.waitForFunction(() => !!document.querySelector('.hero-h1'), null, { timeout: 120000 });
    await page.waitForTimeout(1400);
    const after = await page.evaluate(() => ({
      splashGone: !document.getElementById('splash'),
      appRendered: !!document.querySelector('.hero-h1'),
    }));
    ok('splash is removed from the DOM once the app is up', after.splashGone, JSON.stringify(after));
    ok('the app is what is left behind', after.appRendered);
    await page.close();
  }

  head('the rhythm trace waits for the heart to settle, instead of sweeping in parallel with it');
  {
    const page = watch(await browser.newPage({ viewport: { width: 834, height: 1112 } }), events, 'rhythm trace', errors);
    await page.addInitScript(() => {
      (function sample(){
        const selectors=['.sp-heart-mount','.sp-word','.sp-sub','.sp-trace'];
        const nodes=selectors.map(sel=>document.querySelector(sel));
        if(nodes.every(el=>el&&getComputedStyle(el).animationName!=='none')){
          window.__splashDelays=nodes.map(el=>parseFloat(getComputedStyle(el).animationDelay));return;
        }
        requestAnimationFrame(sample);
      })();
    });
    page.goto(URL, { waitUntil: 'commit' }).catch(() => {});
    await page.waitForSelector('#splash', { timeout: 30000 });
    await page.waitForFunction(()=>Array.isArray(window.__splashDelays),null,{timeout:30000});
    const delays=await page.evaluate(()=>{
      const [heart,word,sub,trace]=window.__splashDelays;
      return {heart,word,sub,trace};
    });
    ok('the heart, word and subtitle keep their original entrance timing',
       delays.heart === 0 && delays.word === 0.1 && delays.sub === 0.24, JSON.stringify(delays));
    ok('the rhythm trace now waits for the heart to settle, instead of starting on the same frame',
       delays.trace !== null && delays.trace > delays.sub && delays.trace >= 0.7 && delays.trace <= 1.0,
       `trace delay ${delays.trace}s (heart settles at ~${delays.heart + 1}s)`);
    await page.close();
  }

  head('the heart has its own keyframes, not the word/subtitle\'s later-declared spRise');
  {
    const page = watch(await browser.newPage({ viewport: { width: 834, height: 1112 } }), events, 'heart keyframes', errors);
    await page.addInitScript(() => {
      (function sampleHeart() {
        const el = document.querySelector('.sp-heart-mount');
        if (el) {
          const name = getComputedStyle(el).animationName;
          if (name && name !== 'none') {
            let fromTransform = null;
            for (const sheet of document.styleSheets) {
              let rules;
              try { rules = sheet.cssRules; } catch (_) { continue; }
              for (const rule of rules) {
                if (rule instanceof CSSKeyframesRule && rule.name === name) {
                  for (const kf of rule.cssRules) {
                    if (kf.keyText === 'from' || kf.keyText === '0%') { fromTransform = kf.style.transform; break; }
                  }
                }
              }
            }
            window.__splashHeart = { found: true, name, fromTransform };
            return;
          }
        }
        requestAnimationFrame(sampleHeart);
      })();
    });
    page.goto(URL, { waitUntil: 'commit' }).catch(() => {});
    await page.waitForSelector('#splash', { timeout: 30000 });
    await page.waitForFunction(() => !!window.__splashHeart, null, { timeout: 30000 });
    const heart = await page.evaluate(() => window.__splashHeart);
    ok('.sp-heart-mount uses its own animation name, not the shared spRise', heart.name === 'spRiseHeart', JSON.stringify(heart));
    ok('and that keyframes rule still carries the scale-in it was authored with',
       !!heart.fromTransform && /scale/.test(heart.fromTransform), heart.fromTransform);
    await page.close();
  }

  head('the delay does not leak into the reduced-motion override');
  {
    const page = watch(await browser.newPage({ viewport: { width: 834, height: 1112 } }), events, 'reduced motion', errors);
    await page.emulateMedia({ reducedMotion: 'reduce' });
    page.goto(URL, { waitUntil: 'commit' }).catch(() => {});
    await page.waitForSelector('#splash', { timeout: 30000 });
    await page.waitForFunction(() => {
      const el = document.querySelector('.sp-trace');
      return el && /^0(?:px)?$/.test(getComputedStyle(el).strokeDashoffset);
    }, null, { timeout: 30000 });
    const trace = await page.evaluate(() => {
      const el = document.querySelector('.sp-trace');
      return el ? getComputedStyle(el).animationName : null;
    });
    ok('the rhythm trace still fully disables its animation under prefers-reduced-motion',
       trace === 'none', trace);
    await page.close();
  }

  head('theme handover: no flash of the wrong theme');
  {
    const page = watch(await browser.newPage({ viewport: { width: 834, height: 1112 } }), events, 'theme handover', errors);
    await page.goto(URL, { waitUntil: 'load', timeout: 200000 });
  /* The Stage 1 build injects app.js only after its content fetch resolves,
     so 'load' no longer implies the app has booted. Wait for it explicitly —
     a no-op on the single-file build, where this is already true. */
  await booted(page);
    await page.evaluate(() => { S.theme = 'dark'; applyTheme(); save(); });
    await page.reload({ waitUntil: 'commit' });
    await page.waitForSelector('#splash', { timeout: 30000 });
    const early = await page.evaluate(() => ({
      attr: document.documentElement.getAttribute('data-theme'),
      appRendered: !!document.querySelector('.hero-h1'),
    }));
    ok('a saved dark theme is already on the root element while the splash shows',
       early.attr === 'dark', JSON.stringify(early));
    await page.close();
  }

  head('the beating hero layer');
  {
    const page = watch(await browser.newPage({ viewport: { width: 834, height: 1112 } }), events, 'beating hero');
    /* Its own array, because this section asserts on it and must not see the
       five that ran before it. Both are fed: the assertion reads `seen`, the
       note reads the suite's. */
    const seen = [];
    const note = m => { seen.push(m); errors.push('beating hero: ' + m); };
    page.on('pageerror', e => note(e.message));
    page.on('console', m => { if (m.type() === 'error' && !isEngineNoise(m.text())) note(m.text()); });
    await page.goto(URL, { waitUntil: 'load', timeout: 200000 });
  /* The Stage 1 build injects app.js only after its content fetch resolves,
     so 'load' no longer implies the app has booted. Wait for it explicitly —
     a no-op on the single-file build, where this is already true. */
  await booted(page);
    await page.waitForTimeout(2200);
    const hero = await page.evaluate(() => {
      const el = document.querySelector('.hero-live');
      if (!el) return { found: false };
      const cs = getComputedStyle(el, '::after');
      return { found: true, anim: cs.animationName, dur: cs.animationDuration, z: cs.zIndex };
    });
    ok('hero carries the heartbeat layer', hero.found && hero.anim === 'heroBeat', JSON.stringify(hero));
    ok('it beats at roughly 68 bpm', hero.dur === '1.76s', hero.dur);
    ok('it sits behind the trace, not over it', hero.z === '-1', hero.z);

    /* The rule that keeps this a study tool: no ambient animation behind
       reading. If a future change puts one there, this should fail. */
    const quiet = await page.evaluate(() => {
      (S.resume = {}, startQuiz)('Arrhythmias'); render();
      const card = document.querySelector('.q-card');
      if (!card) return { noCard: true };
      const bad = [];
      for (const el of [card, ...card.querySelectorAll('*')]) {
        for (const pe of ['', '::before', '::after']) {
          const n = getComputedStyle(el, pe || undefined).animationName;
          if (n && n !== 'none' && /beat|aurora|pulse/i.test(n)) bad.push(el.className + pe + ':' + n);
        }
      }
      return { bad };
    });
    ok('no ambient background animation behind the question stem',
       quiet.bad && quiet.bad.length === 0, JSON.stringify(quiet.bad || quiet));
    ok('no console or page errors across the run', seen.length === 0, seen.join(' | '));
    await page.close();
  }

  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
