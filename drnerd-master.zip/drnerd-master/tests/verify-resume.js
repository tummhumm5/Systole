#!/usr/bin/env node
/*
 * A chapter you left is the chapter you come back to.
 *
 *   NODE_PATH=$(npm root -g) node tests/verify-resume.js <patched.html>
 *
 * THE CLAIM IS NOT "qIdx WAS RESTORED". startQuiz() shuffles, so an index on
 * its own names a different question every time; a suite that checked only the
 * counter would pass on a build that returned you to question twelve of a
 * completely different deck. So the checks below compare the DECK — the ids in
 * order — and the question actually on screen, which is the thing the fellow
 * noticed was wrong.
 *
 * The interesting cases are the refusals. A saved deck must not be dealt when
 * it would be the wrong deck: not for `due`, which is recomputed from the FSRS
 * schedule; not for `missed`, which shrinks as you improve; and not when the
 * question bank has moved under the record. Those are checked by making the
 * situation happen, not by reading the source.
 */
'use strict';
const path = require('path');
const { launch, isEngineNoise } = require('./_engine');
const { booted } = require('./_render.js');
const { onDeath } = require('./_deathnote.js');

const target = process.argv[2];
if (!target) { console.error('usage: node tests/verify-resume.js <patched.html>'); process.exit(1); }
const URL = /^https?:\/\//.test(target) ? target : 'file://' + path.resolve(target);

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

(async () => {
  const browser = await launch();
  const page = await browser.newPage({ viewport: { width: 1100, height: 950 } });
  const errors = [];
  const events = [];
  page.on('crash', () => events.push('the browser CRASHED the page'));
  page.on('close', () => events.push('the page closed'));
  page.on('requestfailed', r => {
    const why = (r.failure() || {}).errorText || '';
    if (why) events.push(`request failed: ${String(r.url()).slice(-50)} — ${why}`);
  });
  /* A crash and a close are different diagnoses; Playwright reports both
     as "Target page, context or browser has been closed" on the next call. */
  onDeath(() => ({ section, checks: passed + failed, errors,
                   events: events.length ? events.join(', ') : 'none' }));
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !isEngineNoise(m.text())) errors.push(m.text()); });

  await page.goto(URL, { waitUntil: 'load', timeout: 200000 });
  await booted(page);

  /* Answer `n` questions of a chapter, then go home. Returns the deck as it
     was dealt, so the next entry can be compared against it. */
  const workThrough = (n) => page.evaluate((n) => {
    const ch = CHAPTERS[0];
    startQuiz(ch);
    const ids = S.questions.map(q => q.id);
    for (let k = 0; k < n; k++) { selectOpt(0); nextQ(); }
    const at = S.qIdx, corr = S.quizCorrect, tot = S.quizTotal;
    goHome();
    return { ch, ids, at, corr, tot };
  }, n);

  head('leaving a chapter and coming back');
  const first = await workThrough(5);
  const again = await page.evaluate((ch) => {
    startQuiz(ch);
    return { ids: S.questions.map(q => q.id), at: S.qIdx, corr: S.quizCorrect, tot: S.quizTotal,
             shown: S.questions[S.qIdx] ? S.questions[S.qIdx].id : null, resumed: !!S.resumed };
  }, first.ch);

  ok('it opens where you left it, not at question one',
     again.at === first.at && again.at > 0, `left at ${first.at}, returned to ${again.at}`);
  /* The check that an index alone cannot make: the same deck, in the same
     order, so the index means what it meant. */
  ok('and the deck is the same deck, in the same order',
     again.ids.length === first.ids.length && again.ids.every((id, i) => id === first.ids[i]),
     `${again.ids.length} questions, ${again.ids.filter((id, i) => id === first.ids[i]).length} in place`);
  ok('so the question on screen is the one you were on',
     again.shown === first.ids[first.at], `${again.shown} vs ${first.ids[first.at]}`);
  ok('the running score comes back with it',
     again.corr === first.corr && again.tot === first.tot,
     `${again.corr}/${again.tot} vs ${first.corr}/${first.tot}`);
  ok('and the quiz knows it resumed', again.resumed === true);

  head('what a resumed deck remembers about the questions behind it');
  const back = await page.evaluate(() => {
    prevQ();
    return { answered: S.answered, selected: S.selected, idx: S.qIdx };
  });
  ok('stepping back finds the answer you already gave, not a fresh question',
     back.answered === true && back.selected !== null,
     `answered=${back.answered} selected=${back.selected}`);

  head('the way out');
  const restarted = await page.evaluate(() => {
    const old = S.resume['all|' + S.chapter] && S.resume['all|' + S.chapter].i;
    restartQuiz();
    const rec = S.resume['all|' + S.chapter];
    /* The deck is kept the moment it is dealt (round six), so after Start over a record exists: the NEW deck, at its
       first question. What must be gone is the old place. */
    return { at: S.qIdx, resumed: !!S.resumed, old,
             stored: !!rec && !(rec.i === 0 && rec.ids.join() === S.questions.map(q => q.id).join()) };
  });
  ok('start over deals from the beginning', restarted.at === 0);
  ok('and stops claiming to be resumed', restarted.resumed === false);
  ok('and forgets the place, so it does not spring back',
     restarted.old > 0 && restarted.stored === false, JSON.stringify(restarted));

  head('question one is a place too');
  /* Reported from the app (28 October 2026): open a chapter, answer the first question or only read it, go back, open
     the chapter again, and it was question one of a freshly shuffled deck. A record at index 0 was read as "nothing
     done", and the deck was not written down until the first answer or Next. */
  const one = await page.evaluate(() => {
    const ch = CHAPTERS[1] || CHAPTERS[0], out = {};
    for (const [name, answer] of [['read', false], ['answered', true]]) {
      clearResume(ch, 'all'); startQuiz(ch);
      const ids = S.questions.map(q => q.id);
      if (answer) selectOpt(0);
      goHome(); startQuiz(ch);
      out[name] = { same: S.questions.map(q => q.id).join() === ids.join(), at: S.qIdx, answered: S.answered };
    }
    return out;
  });
  ok('leaving from the first question, only read, comes back to it in the same deck', one.read.same && one.read.at === 0, JSON.stringify(one.read));
  ok('and leaving it answered comes back to it answered, not asked again', one.answered.same && one.answered.at === 0 && one.answered.answered === true,
     JSON.stringify(one.answered));

  head('a finished deck is not a deck you are in the middle of');
  const finished = await page.evaluate(() => {
    const ch = CHAPTERS[0];
    startQuiz(ch);
    const n = S.questions.length;
    for (let k = 0; k < n; k++) { selectOpt(0); nextQ(); }
    const screen = S.screen;
    const stored = !!S.resume['all|' + ch];
    startQuiz(ch);
    return { screen, stored, at: S.qIdx, resumed: !!S.resumed };
  });
  ok('working to the end reaches the results screen', finished.screen === 'results');
  ok('and clears the saved place', finished.stored === false, `stored=${finished.stored}`);
  ok('so the next entry starts over', finished.at === 0 && finished.resumed === false);

  head('the two modes that must never resume');
  const modes = await page.evaluate(() => {
    const out = {};
    /* Give `missed` something to hold, then leave it part-way. */
    S.missed = new Set(POOL.slice(0, 8).map(q => q.id));
    startQuiz(null, 'missed');
    if (S.screen === 'quiz' && S.questions.length > 2) {
      selectOpt(0); nextQ(); selectOpt(0); nextQ();
      out.missedAt = S.qIdx;
      goHome();
      startQuiz(null, 'missed');
      out.missedBack = S.qIdx;
      out.missedResumed = !!S.resumed;
    }
    out.keys = Object.keys(S.resume);
    return out;
  });
  ok('a missed-question run does not come back part-finished',
     modes.missedBack === 0 && modes.missedResumed === false,
     `left at ${modes.missedAt}, returned to ${modes.missedBack}`);
  ok('and nothing was written down for it',
     modes.keys.every(k => k.indexOf('all|') === 0), modes.keys.join(', ') || 'no records');

  head('a record the bank has moved under');
  const stale = await page.evaluate(() => {
    const ch = CHAPTERS[0];
    startQuiz(ch);
    selectOpt(0); nextQ(); selectOpt(0); nextQ();
    goHome();
    /* A question that retired between sessions. */
    S.resume['all|' + ch].ids[0] = 'NO_SUCH_QUESTION_ID';
    startQuiz(ch);
    return { at: S.qIdx, resumed: !!S.resumed, dealt: S.questions.length };
  });
  ok('a deck naming a question that no longer exists is refused, not dealt short',
     stale.at === 0 && stale.resumed === false, `qIdx=${stale.at} resumed=${stale.resumed}`);
  ok('and a full fresh deck is dealt instead', stale.dealt > 0, `${stale.dealt} questions`);

  head('it survives the app being closed');
  const beforeReload = await page.evaluate(() => {
    const ch = CHAPTERS[0];
    restartQuiz();
    startQuiz(ch);
    selectOpt(0); nextQ(); selectOpt(0); nextQ(); selectOpt(0); nextQ();
    const at = S.qIdx, ids = S.questions.map(q => q.id);
    goHome();
    return { ch, at, ids };
  });
  await page.reload({ waitUntil: 'load', timeout: 200000 });
  await booted(page);
  const afterReload = await page.evaluate((ch) => {
    startQuiz(ch);
    return { at: S.qIdx, ids: S.questions.map(q => q.id), resumed: !!S.resumed };
  }, beforeReload.ch);
  ok('a reload still knows where you were', afterReload.at === beforeReload.at,
     `${beforeReload.at} → ${afterReload.at}`);
  /* The same length first: every() over the deck after the reload passed on an empty or truncated one. */
  ok('and still has the same deck', beforeReload.ids.length > 0 && afterReload.ids.length === beforeReload.ids.length &&
     afterReload.ids.every((id, i) => id === beforeReload.ids[i]), `${beforeReload.ids.length} → ${afterReload.ids.length} questions`);

  head('the answer you gave before walking away');
  /* THE CASE EVERY SECTION ABOVE MISSES. All of them answer and then advance,
     and nextQ() is one of the two places that wrote the record — so the record
     was always written by the navigation, never by the answer. Answering and
     stopping, which is what closing the iPad on the question you just did looks
     like, went through selectOpt alone: save(), not saveResume().

     It worked anyway. S.resume[key].answers holds the LIVE S.answers object
     rather than a copy, so save() serialised the new answer through the alias.
     Correct by accident, and the obvious tidy-up — copying the answers
     defensively, which is what anyone thinking about aliasing would do — loses
     it silently. Nothing above would notice: goHome() and startQuiz() keep the
     same objects alive, so only a reload can tell the difference between a
     record that was written and an object that was still being shared. */
  const uncommitted = await page.evaluate(() => {
    const ch = CHAPTERS[0];
    restartQuiz();
    startQuiz(ch);
    selectOpt(0); nextQ();        // a record now exists, sitting at index 1
    selectOpt(1);                 // answer the one we are on — and stop here
    return { ch, idx: S.qIdx, selected: S.selected,
             id: S.questions[S.qIdx].id, opts: S.questions[S.qIdx].o.length };
  });
  ok('the question we stopped on offers the option we picked',
     uncommitted.opts > 1 && uncommitted.selected === 1, `${uncommitted.opts} options`);
  /* The store write is not synchronous, and reloading on top of it would be
     testing the race rather than the record. */
  /* WAITED FROM THE DRIVER, NOT INSIDE THE PAGE. This was
     `page.evaluate(() => new Promise(r => setTimeout(r, 500)))`, which holds an
     execution context open for half a second — and any navigation in that
     window destroys it. On the served build the app can navigate on its own:
     the service worker calls clients.claim() on activate, and index.html
     reloads when a worker takes over from a previous one. The suite then dies
     with "Execution context was destroyed, most likely because of a
     navigation", which describes the harness rather than the app.

     The wait exists to let an asynchronous store write land before reloading
     on top of it. Nothing about that needs to run in the page. */
  await page.waitForTimeout(500);
  await page.reload({ waitUntil: 'load', timeout: 200000 });
  await booted(page);
  const kept = await page.evaluate((ch) => {
    startQuiz(ch);
    return { idx: S.qIdx, answered: S.answered, selected: S.selected, resumed: !!S.resumed,
             id: S.questions[S.qIdx] ? S.questions[S.qIdx].id : null,
             nonAll: Object.keys(S.resume).filter(k => k.indexOf('all|') !== 0) };
  }, uncommitted.ch);

  ok('a reload lands on the question you were answering, not the one after it',
     kept.idx === uncommitted.idx && kept.id === uncommitted.id,
     `${uncommitted.idx}/${uncommitted.id} → ${kept.idx}/${kept.id}`);
  /* The check the alias was silently carrying. */
  ok('and the answer you gave on it is still given',
     kept.answered === true && kept.selected === uncommitted.selected,
     `answered=${kept.answered} selected=${kept.selected}`);
  ok('so it comes back revealed rather than asking again', kept.resumed === true);
  /* Due and missed decks still write nothing, across a reload as well as
     within a session: resumeKey() returns null for them, so recordResume()
     declines before it touches S.resume at all. */
  ok('and no mode but `all` left a record behind, reload included',
     kept.nonAll.length === 0, kept.nonAll.join(', ') || 'none');

  head('the screen says so');
  /* render() goes through startViewTransition, so the DOM it produces lands in
     an async callback and is NOT in the document when render() returns. Waiting
     on the counter agreeing with S.qIdx is the precondition for the assertion
     below — a fixed sleep would pass on a fast machine and lie on a slow one,
     and reading immediately (as this first did) reports a control as missing
     when it is merely late. */
  const settled = () => page.waitForFunction(() => {
    const c = document.querySelector('.q-counter');
    return !!c && c.textContent.trim() === (S.qIdx + 1) + ' of ' + S.questions.length + ' in this session';
  }, null, { timeout: 15000 });
  await settled();
  const chrome = await page.evaluate(() => ({
    hasRestart: !!document.querySelector('.q-restart'),
    live: (document.getElementById('srLive') || {}).textContent || '',
  }));
  ok('a resumed quiz shows the restart control', chrome.hasRestart);
  ok('and says out loud that it resumed', /Resumed at question/.test(chrome.live), chrome.live);
  await page.evaluate(() => { restartQuiz(); });
  await settled();
  const freshChrome = await page.evaluate(() => !!document.querySelector('.q-restart'));
  ok('a fresh quiz does not', freshChrome === false);

  head('a deck from search, a jump or Apex starts clean, and leaves saved places alone');
  /* quizFromSearch, jumpTo and Apex's start_quiz (flushNav) dealt their decks
     with Object.assign under mode 'all'. They kept the deck before's answers,
     which restoreQuizState() replayed by position (question 2 opened answered,
     its options locked), and they took the chapter's or the whole bank's saved
     place: overwritten at the first answer, deleted at the end. Each launcher
     here follows a deck left part-way with answers in it, so there is a place
     to lose and an answer to inherit. */
  const adhoc = await page.evaluate(() => {
    const place = key => S.resume[key] ? S.resume[key].i + '/' + S.resume[key].ids.length : null;
    const leaveWorked = ch => { startQuiz(ch); for (let k = 0; k < 3; k++) { selectOpt(0); nextQ(); } goHome(); };
    const out = {};
    const ch = CHAPTERS[0], key = 'all|' + ch;
    goHome(); S.resume = {};
    /* Apex: a deck of ids from the chapter left part-way */
    leaveWorked(ch);
    out.placeBefore = place(key);
    pendingNav = { kind: 'quiz', ids: POOL.filter(q => q.ch === ch).slice(0, 4).map(q => q.id) };
    S.shownAt = 0;   // a stamp no launch leaves behind, so an unstamped first question cannot pass
    flushNav();
    out.shownFresh = S.shownAt > 0;
    selectOpt(0); nextQ();
    out.apexSecond = { answered: S.answered, selected: S.selected };
    goHome();
    /* a jump to one question of the chapter, answered and finished */
    jumpTo(POOL.find(q => q.ch === ch).id);
    selectOpt(0); nextQ();
    out.placeAfterJump = place(key);
    /* search: the whole bank's place, left part-way */
    goHome(); leaveWorked(null);
    out.bankBefore = place('all|*');
    SQ.q = 'test'; SQ.hits = POOL.slice(0, 3).map(q => ({ q }));
    quizFromSearch();
    selectOpt(0); nextQ();
    out.searchSecond = { answered: S.answered };
    out.bankAfter = place('all|*');
    goHome();
    return out;
  });
  ok('(there were saved places to lose: a chapter’s and the whole bank’s)', !!adhoc.placeBefore && !!adhoc.bankBefore, JSON.stringify(adhoc));
  ok('Apex’s deck does not open its second question already answered', adhoc.apexSecond.answered === false && adhoc.apexSecond.selected === null, JSON.stringify(adhoc.apexSecond));
  ok('nor does a search’s deck', adhoc.searchSecond.answered === false, JSON.stringify(adhoc.searchSecond));
  ok('a jump to one question leaves the chapter’s place as it was', adhoc.placeAfterJump === adhoc.placeBefore, `${adhoc.placeBefore} → ${adhoc.placeAfterJump}`);
  ok('a search’s deck leaves the whole bank’s place as it was', adhoc.bankAfter === adhoc.bankBefore, `${adhoc.bankBefore} → ${adhoc.bankAfter}`);
  ok('and its first answer is timed from when it was shown', adhoc.shownFresh === true);

  ok('no console or page errors across the run', errors.length === 0, errors.slice(0, 3).join(' | '));
  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
