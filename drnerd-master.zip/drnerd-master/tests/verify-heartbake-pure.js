#!/usr/bin/env node
/*
 * The heart's mesh, baked at build time: is the copy the app loads exactly the
 * mesh it would have made, and is every other copy refused?
 *
 *   node tests/verify-heartbake-pure.js
 *
 * WHY. Meshing the heart's muscle and chambers was 78% of the launch — 6.3 s of
 * main thread on the owner's laptop at an iPad's CPU pace, before the home
 * screen could appear. scripts/heart-bake.js now meshes them during the build
 * with heart3d.js's own code, scripts/assemble-app.js embeds the result,
 * build-pwa moves it into a file of its own, and create() loads it instead of
 * meshing.
 *
 * WHAT IS CLAIMED, AND HELD HERE:
 *   · the copy is the mesh, value for value — not an approximation of it;
 *   · a copy made from other code, on another grid, cut short or padded, or
 *     not a mesh at all (a sign-in page) is refused, and the heart meshes
 *     itself as before;
 *   · the split build moves the copy out of app.js under a name derived from
 *     its bytes, so the service worker's cache can never serve an old one;
 *   · the loader hands it over before app.js runs, and nothing about it can
 *     stop a launch: a missing file, a failed fetch or a fetch that never
 *     answers all leave the app starting as before.
 * Everything under test is the shipped code — heart3d.js run as is, the bake
 * module required, build-pwa's function and loader lines lifted out of its
 * source. Nothing is a copy.
 *
 * NOT HERE: whether the built app really draws the baked copy. That needs the
 * licensed build and a browser; tests/verify-heroart.js asks the hero heart
 * which mesh it used.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const { blankComments } = require('./_source.js');

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
const head = t => console.log('\n── ' + t + ' ──');

const ROOT = path.join(__dirname, '..');
const HEART = fs.readFileSync(path.join(ROOT, 'src', 'core', 'heart3d.js'), 'utf8');
const load = src => { const box = {}; new Function('window', src)(box); return box; };
const box = load(HEART);
const M = box.Heart3D && box.Heart3D.mesh;
const { bake, keyOf, HERO_RES } = require('../scripts/heart-bake.js');

const FIELDS = ['positions', 'normals', 'weights', 'color', 'extra', 'indices'];
/* The valves carry their hinges and leaflet ids in place of colour and extra. */
const MESH_FIELDS = { outer: FIELDS, cav: FIELDS, coron: FIELDS, cond: FIELDS,
                      valves: ['positions', 'normals', 'weights', 'hingeP', 'hingeA', 'vid', 'indices'] };
/* Every value of every field of all five meshes, compared as what makeMesh()
   uploads: Float32 for the attributes, integers for the indices. The surfaces
   are built as Float32Arrays already; the coronaries as plain numbers, which
   makeMesh() turns into Float32 on the way to the GPU — so a raw comparison
   failed on the coronaries' first value while the copy held exactly the value
   drawn. Math.fround is the identity on the surfaces. */
const differences = (a, b) => {
  const out = [];
  for (const s of Object.keys(MESH_FIELDS)) for (const f of MESH_FIELDS[s]) {
    const x = a && a[s] && a[s][f], y = b && b[s] && b[s][f];
    if (!x || !y || x.length !== y.length) { out.push(`${s}.${f} length`); continue; }
    const same = f === 'indices' ? (u, v) => u === v : (u, v) => Math.fround(u) === v;
    for (let i = 0; i < x.length; i++) if (!same(x[i], y[i])) { out.push(`${s}.${f}[${i}]`); break; }
  }
  return out;
};

head('the mesh is there to bake');
ok('heart3d.js exposes its mesh builder', !!M && typeof M.build === 'function' && typeof M.pack === 'function');
const built = M.build(M.RES, M.LO, M.HI);
/* Vacuity guard: an empty mesh packs, unpacks and compares equal to itself. */
const nv = m => built[m] ? built[m].positions.length / 3 : 0;
const whole = nv('outer') > 5000 && nv('cav') > 5000 && nv('coron') > 1000 && nv('cond') > 200 && nv('valves') > 200;
ok('and it meshes two real surfaces, and builds the coronaries, conduction and valves', whole,
   ['outer', 'cav', 'coron', 'cond', 'valves'].map(m => `${m} ${nv(m)}`).join(', ') + ' vertices');
/* Everything below compares copies of this mesh. With a part missing there is
   nothing true to compare, and pack() would throw on it — so stop here and say
   so, rather than die without a summary. */
if (!whole) { console.log(`\n${passed} passed, ${failed} failed (stopped: the mesh is incomplete)`); process.exit(1); }

head('the packed copy is the mesh, value for value');
const KEY = keyOf(HEART);
const buf = M.pack(built, KEY, M.RES, M.LO, M.HI);
const back = M.unpack(buf, KEY, M.RES, M.LO, M.HI);
const diff = differences(built, back);
ok('every value of all five meshes survives packing', !!back && diff.length === 0, diff.slice(0, 3).join(', ') || 'none differ');

head('any other copy is refused');
ok('one baked from other code (another key)', M.unpack(buf, keyOf(HEART + ' '), M.RES, M.LO, M.HI) === null);
/* Not "presented with no key": that is refused by the key comparison alone,
   which a mutation removing the missing-key guard showed (33/0). The guard's
   own case is a copy baked with no key and asked for with none. */
ok('one baked with no key, asked for with none', M.unpack(M.pack(built, '', M.RES, M.LO, M.HI), undefined, M.RES, M.LO, M.HI) === null);
ok('one meshed on another grid', M.unpack(buf, KEY, [M.RES[0], M.RES[1], M.RES[2] + 1], M.LO, M.HI) === null);
ok('one over other bounds', M.unpack(buf, KEY, M.RES, [M.LO[0] - 0.1, M.LO[1], M.LO[2]], M.HI) === null);
/* A throw is reported as one rather than crashing the suite. */
const refuses = b => { try { return M.unpack(b, KEY, M.RES, M.LO, M.HI) === null ? 'refused' : 'accepted'; } catch (e) { return 'threw: ' + e.message.slice(0, 50); } };
const short = refuses(buf.slice(0, buf.byteLength - 4));
ok('one cut short', short === 'refused', short);
const padded = new Uint8Array(buf.byteLength + 4); padded.set(new Uint8Array(buf));
const spare = refuses(padded.buffer);
ok('one with bytes to spare', spare === 'refused', spare);
const page = Buffer.from('<!doctype html><title>Sign in</title>' + ' '.repeat(80));
ok('a sign-in page served in its place', M.unpack(new Uint8Array(page).buffer, KEY, M.RES, M.LO, M.HI) === null);
/* HM01 held two meshes, HM02 three; HM03 adds conduction and valves. A copy
   tagged with an old layout must be refused, not read as the new one. */
const tagged = t => { const o = buf.slice(0); new Uint32Array(o, 0, 1)[0] = t; return M.unpack(o, KEY, M.RES, M.LO, M.HI); };
ok('one tagged with the old two-mesh layout', tagged(0x31304d48) === null);    // 'HM01'
ok('one tagged with the old three-mesh layout', tagged(0x32304d48) === null);  // 'HM02'

head('the build bakes it with the shipped code');
const baked = bake(HEART);
ok('the bake is keyed to heart3d.js as it is', baked.key === KEY && /^[0-9a-f]{16}$/.test(baked.key), baked.key);
ok('and a one-character change to the code changes the key', keyOf(HEART.replace('sdCapsule(', 'sdCapsule (')) !== KEY);
const bakedBuf = new Uint8Array(Buffer.from(baked.b64, 'base64')).buffer;
/* The hero's grid, not heart3d.js's default: the first bake used the default,
   every check in this file passed, and the built hero meshed at every launch
   because it asks for another grid (verify-heroart: meshSource "computed"). */
const heroBuilt = M.build(HERO_RES, M.LO, M.HI);
ok('it is baked on the grid the hero asks for',
   String(baked.res) === String(HERO_RES) && !!M.unpack(bakedBuf, baked.key, HERO_RES, M.LO, M.HI), String(baked.res));
ok('what it embeds unpacks to the mesh, value for value',
   differences(heroBuilt, M.unpack(bakedBuf, baked.key, HERO_RES, M.LO, M.HI)).length === 0);
/* The page that ships, not the patch scripts that used to write it: since the
   chain was retired the hero's grid and the mesh's key are typed into
   app/systole.html, and the build fills only the mesh's bytes. A key that no
   longer matches heart3d.js is the original bug again — the copy is refused
   and the hero meshes at every launch — so it is held to a fresh bake here. */
const shipped = blankComments(fs.readFileSync(path.join(ROOT, 'app', 'systole.html'), 'utf8'));
const heroGrids = shipped.match(/resolution:\[[^\]]*\]/g) || [];
ok('the page mounts the hero at the grid the bake uses',
   heroGrids.length > 0 && heroGrids[heroGrids.length - 1] === `resolution:[${HERO_RES.join(',')}]`,
   heroGrids[heroGrids.length - 1] || 'no resolution:[…] in the page');
const pageKey = (shipped.match(/window\.HEART3D_MESH_KEY='([0-9a-f]+)';/) || [])[1];
ok('the key the page carries is the key of the heart3d.js it ships with',
   !!pageKey && pageKey === baked.key, `page ${pageKey || 'none'}, bake ${baked.key}`);
ok('and the mesh itself is a slot the build fills, not bytes frozen in the page',
   shipped.includes("window.HEART3D_MESH_B64='@@SLOT[payload:HEART_MESH]@@';"));
const assembler = blankComments(fs.readFileSync(path.join(ROOT, 'scripts', 'assemble-app.js'), 'utf8'));
ok('which the assembler fills by baking src/core/heart3d.js with this module',
   /require\('\.\/heart-bake\.js'\)/.test(assembler) &&
   /HEART_MESH:\s*\(\)\s*=>\s*bake\(fs\.readFileSync\(path\.join\(root, 'src', 'core', 'heart3d\.js'\)/.test(assembler));

head('create() takes the copy only when it is the one for this code');
/* take() is what create() calls: it reads the page's globals. */
const page1 = load(HEART);
page1.HEART3D_MESH_KEY = baked.key; page1.HEART3D_MESH_B64 = baked.b64;
const took = page1.Heart3D.mesh.take(HERO_RES, M.LO, M.HI);
ok('the single file\'s base64 is decoded and used', !!took && differences(heroBuilt, took).length === 0);
ok('and kept, so a second heart on the page does not decode it again',
   page1.HEART3D_MESH instanceof ArrayBuffer && page1.HEART3D_MESH.byteLength === baked.bytes);
const page2 = load(HEART);
page2.HEART3D_MESH_KEY = keyOf('some other heart3d.js'); page2.HEART3D_MESH_B64 = baked.b64;
ok('a copy with another key is left alone, and the heart meshes itself', page2.Heart3D.mesh.take(HERO_RES, M.LO, M.HI) === null);
const bad = buf.slice(0); new Uint32Array(bad, 56, 1)[0] = 1e7;   // a header claiming ten million vertices
const page4 = load(HEART);
page4.HEART3D_MESH_KEY = KEY; page4.HEART3D_MESH = bad;
let took4; try { took4 = page4.Heart3D.mesh.take(M.RES, M.LO, M.HI); } catch (e) { took4 = 'threw: ' + e.message; }
ok('a copy whose header claims more than it holds is refused, not thrown', took4 === null, String(took4).slice(0, 60));
const page3 = load(HEART);
page3.HEART3D_MESH_KEY = baked.key; page3.HEART3D_MESH = bakedBuf;
ok('the split build\'s fetched ArrayBuffer is used as it is', !!page3.Heart3D.mesh.take(HERO_RES, M.LO, M.HI));

head('the split build moves it out of app.js, named by its bytes');
const PWA = fs.readFileSync(path.join(ROOT, 'scripts', 'build-pwa.js'), 'utf8');
const lift = (src, name) => {
  const at = src.indexOf('function ' + name + '(');
  if (at < 0) return null;
  let depth = 0, end = -1;
  for (let k = src.indexOf('{', at); k < src.length; k++) {
    if (src[k] === '{') depth++;
    else if (src[k] === '}') { depth--; if (!depth) { end = k + 1; break; } }
  }
  return end > 0 ? new Function('crypto', 'Buffer', `${src.slice(at, end)}\nreturn ${name};`)(require('crypto'), Buffer) : null;
};
const split = lift(PWA, 'splitHeartMesh');
ok('splitHeartMesh was lifted out of build-pwa.js', typeof split === 'function');
const appCode = `var a=1;\nwindow.HEART3D_MESH_KEY='${baked.key}';\nwindow.HEART3D_MESH_B64='${baked.b64}';\nvar b=2;\n`;
const cut = split ? split(appCode) : null;
ok('the copy leaves app.js, and the key stays with the code',
   !!cut && !cut.code.includes(baked.b64) && cut.code.includes(`HEART3D_MESH_KEY='${baked.key}'`) && /HEART3D_MESH_B64=null;/.test(cut.code));
ok('what it writes is the copy\'s bytes', !!cut && Buffer.compare(cut.bin, Buffer.from(baked.b64, 'base64')) === 0);
ok('under content/, named by those bytes', !!cut && /^content\/heart-mesh-[0-9a-f]{12}\.bin$/.test(cut.name), cut && cut.name);
const other = split ? split(appCode.replace(baked.b64, Buffer.from('another mesh entirely').toString('base64'))) : null;
ok('so a different mesh gets a different name', !!other && !!cut && other.name !== cut.name, other && other.name);
ok('app code with no copy is left alone', split ? split('var a=1;') === null : false);
let threw = false; try { split(appCode + appCode); } catch (_) { threw = true; }
ok('two copies stop the build rather than shipping one of them', threw);

head('the loader hands it over before app.js, and never holds a launch');
const LOADER = (() => {
  const i = PWA.indexOf('const LOADER = `<script>'), j = PWA.indexOf('</script>`;', i);
  return i < 0 || j < 0 ? '' : PWA.slice(i, j).replace(/\\`/g, '`').replace(/\\\$/g, '$');
})();
const start = LOADER.indexOf("var HEART_MESH_URL = '__HEART_MESH__';");
const fetchEnd = LOADER.indexOf('\n    : null;', start);   // the ternary's own line, not the one inside the callback
const waitLine = (LOADER.match(/\n\s*if\(heartMesh\) await Promise\.race\(\[heartMesh, new Promise\(function\(r\)\{ setTimeout\(r, 5000\); \}\)\]\);/) || [''])[0];
ok('the loader fetches the mesh from a placeholder the build fills', start > -1 && fetchEnd > start && waitLine !== '');
ok('and waits for it before app.js is appended',
   waitLine !== '' && LOADER.indexOf(waitLine) < LOADER.indexOf("s.src = 'app.js'") && LOADER.indexOf(waitLine) > start);
/* Run those lines, as the build fills them, against stand-ins. */
const run = async (url, fetch, timer) => {
  const win = {};
  const body = LOADER.slice(start, fetchEnd + '\n    : null;'.length).replace("'__HEART_MESH__'", JSON.stringify(url)) + waitLine;
  await new Function('window', 'fetch', 'setTimeout', `return (async function(){ ${body} })();`)(win, fetch, timer || setTimeout);
  return win;
};
const ab = new ArrayBuffer(8);

(async () => {
  const w1 = await run('content/heart-mesh-abc.bin', () => Promise.resolve({ ok: true, arrayBuffer: () => Promise.resolve(ab) }));
  ok('a mesh that arrives is on window.HEART3D_MESH when app.js runs', w1.HEART3D_MESH === ab);
  const w2 = await run('content/heart-mesh-abc.bin', () => Promise.resolve({ ok: false, status: 404 }));
  ok('a 404 hands over nothing, and the launch goes on', w2.HEART3D_MESH === undefined);
  const w3 = await run('content/heart-mesh-abc.bin', () => Promise.reject(new TypeError('offline')));
  ok('a failed fetch hands over nothing, and the launch goes on', w3.HEART3D_MESH === undefined);
  let waited = null;
  const w4 = await run('content/heart-mesh-abc.bin', () => new Promise(() => {}), (f, ms) => { waited = ms; f(); });
  ok('a fetch that never answers holds the launch five seconds at most', w4.HEART3D_MESH === undefined && waited === 5000, `waited ${waited} ms`);
  let asked = 0;
  const w5 = await run('', () => { asked++; return Promise.resolve({ ok: true, arrayBuffer: () => Promise.resolve(ab) }); });
  ok('a build with no mesh fetches nothing', asked === 0 && w5.HEART3D_MESH === undefined, `${asked} fetches`);

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
