#!/usr/bin/env node
/*
 * The two copies problem: which one is newer, and what happens when the
 * database refuses a write.
 *
 *   node tests/verify-store-pure.js
 *
 * Pure Node against tests/_fakeweb.js. store.js holds annotations, notes, chat
 * and the review log, and until this file existed the only thing exercising it
 * needed a build, a browser and the licensed export — so the module that can
 * lose a fellow's work had no check that ran on a push.
 *
 * THE BUG THIS WAS WRITTEN FOR. migrate() found a value in localStorage and a
 * value in IndexedDB for the same key, and resolved it with:
 *
 *     "The database is the newer of the two by definition"
 *
 * It is not. That holds for one of the two ways both copies can exist — an
 * interrupted migration — and set() reaches the other one by itself: when the
 * database will not open, set() writes to localStorage instead. Next launch,
 * the database opens, migration finds both, keeps the OLD database copy and
 * deletes the newer local one. Everything the fellow did while the database
 * was unavailable is gone, and nothing anywhere says so.
 *
 * Both halves are tested here because they are one bug: the write that lands
 * somewhere else, and the migration that then picks wrong.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const { makeWeb, loadModule, settle } = require('./_fakeweb.js');

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
const head = t => console.log('\n── ' + t + ' ──');

const KEY = 'accsap12.notes';          // a MANAGED key
const LOG = 'accsap12.log';            // the array-shaped one
const loadStore = web => loadModule(fs, path, 'src/core/store.js', web).Store;

/* A reload: everything localStorage held survives, the database survives, the
   module's closure state does not. */
function reload(prev, opts) {
  const web = makeWeb(Object.assign({ seed: Object.fromEntries(prev.db) }, opts || {}));
  for (const [k, v] of prev.ls) web.ls.set(k, v);
  return web;
}

(async () => {

  head('the harness drives the real module, not a stand-in');
  {
    const web = makeWeb({});
    const S = loadStore(web);
    ok('store.js loaded and exports set/get', typeof S.set === 'function' && typeof S.get === 'function');
    ok('and the managed keys are the four that move',
       S.MANAGED.length === 4 && S.MANAGED.indexOf(KEY) > -1, S.MANAGED.join(', '));
    await S.ready();
    S.set(KEY, { a: 1 });
    await settle();
    ok('a normal write reaches the database', JSON.stringify(web.db.get(KEY)) === '{"a":1}',
       JSON.stringify(web.db.get(KEY)));
    ok('and does NOT stay in localStorage', web.ls.get(KEY) === undefined);
  }

  head('a write the database refuses is not lost');
  {
    /* The failure that used to be discarded: idbPut resolves false on an
       aborted transaction and the result went nowhere. */
    const web = makeWeb({ putFails: true });
    const S = loadStore(web);
    await S.ready();
    S.set(KEY, { work: 'an hour of it' });
    await settle();
    ok('the value is somewhere durable', web.ls.get(KEY) !== undefined,
       web.ls.get(KEY) === undefined ? 'LOST — neither store has it' : 'localStorage');
    ok('and it is the value that was written',
       String(web.ls.get(KEY)).indexOf('an hour of it') > -1);
    ok('the key is stamped as having fallen back',
       JSON.parse(web.ls.get('accsap12.store.fellback') || '[]').indexOf(KEY) > -1);
    ok('and health() says so rather than looking well', S.health().fellBack.indexOf(KEY) > -1,
       JSON.stringify(S.health()));
  }

  head('a database that will not open at all');
  {
    const web = makeWeb({ openFails: true });
    const S = loadStore(web);
    await S.ready();
    S.set(KEY, { offline: true });
    await settle();
    ok('the write still lands in localStorage', web.ls.get(KEY) !== undefined);
    ok('and is stamped', JSON.parse(web.ls.get('accsap12.store.fellback') || '[]').indexOf(KEY) > -1);
    ok('get() reads it back within the session', JSON.stringify(S.get(KEY)) === '{"offline":true}',
       JSON.stringify(S.get(KEY)));
  }

  head('THE BUG: the newer copy is the local one, and it survives');
  {
    /* Session A: no database. The work goes to localStorage. */
    const a = makeWeb({ openFails: true, seed: { [KEY]: { note: 'OLD' } } });
    const A = loadStore(a);
    await A.ready();
    A.set(KEY, { note: 'NEW' });
    await settle();

    /* Session B: the database is back, still holding the old value. */
    const b = reload(a, {});
    b.db.set(KEY, { note: 'OLD' });      // the database never saw session A
    const B = loadStore(b);
    await B.ready();
    await settle();

    ok('the newer value is what the app reads', JSON.stringify(B.get(KEY)).indexOf('NEW') > -1,
       JSON.stringify(B.get(KEY)));
    ok('and it is what the database now holds', JSON.stringify(b.db.get(KEY)).indexOf('NEW') > -1,
       JSON.stringify(b.db.get(KEY)));
    ok('the local copy is cleared once it is safely across', b.ls.get(KEY) === undefined);
    ok('and the stamp is cleared with it',
       JSON.parse(b.ls.get('accsap12.store.fellback') || '[]').indexOf(KEY) < 0);
  }

  head('fallback snapshots preserve deletions, including an empty map');
  for (const key of ['accsap12.notes', 'accsap12.ink', 'accsap12.chat']) {
    for (const value of [{ keep: [{ text: 'kept' }] }, {}]) {
      const a = makeWeb({ putFails: true, seed: { [key]: { keep: [{ text: 'kept' }], deleted: [{ text: 'removed' }] } } });
      const A = loadStore(a); await A.ready(); A.set(key, value); await settle();
      const b = reload(a), B = loadStore(b); await B.ready(); await settle();
      ok(key + ' restores the exact newer snapshot', JSON.stringify(B.get(key)) === JSON.stringify(value));
      ok('the deleted entry is absent from durable storage', !('deleted' in b.db.get(key)));
    }
  }

  head('an interrupted migration still lets the database win');
  {
    /* The other way both copies exist, and the one the old comment described.
       Nothing stamped it, so the local copy is litter from a migration that
       did not get to its last line — the database is authoritative and this
       must not regress into preferring localStorage. */
    const web = makeWeb({ seed: { [KEY]: { note: 'copied across' } } });
    web.ls.set(KEY, JSON.stringify({ note: 'copied across' }));
    const S = loadStore(web);
    await S.ready();
    await settle();
    ok('the database copy is kept', JSON.stringify(S.get(KEY)).indexOf('copied across') > -1);
    ok('and the leftover local copy is cleared', web.ls.get(KEY) === undefined);
  }

  head('the review log is folded, not chosen');
  {
    /* The array-shaped key. Choosing either side would drop reviews; merge()
       unions them, and it is the same merge() hydration already uses. */
    const a = makeWeb({ openFails: true });
    const A = loadStore(a);
    await A.ready();
    A.set(LOG, [{ q: 1 }, { q: 2 }, { q: 3 }]);
    await settle();

    const b = reload(a, {});
    b.db.set(LOG, [{ q: 1 }, { q: 9 }]);     // a row the local copy never had
    const B = loadStore(b);
    await B.ready();
    await settle();

    const rows = B.get(LOG) || [];
    const ids = rows.map(r => r.q).sort((x, y) => x - y);
    ok('every row from both sides survives', ids.join(',') === '1,2,3,9', ids.join(','));
    ok('and none is duplicated', rows.length === 4, String(rows.length));
  }

  head('a stamped key whose re-write also fails keeps its local copy');
  {
    /* Fail-safe on the recovery path itself: if migration cannot write the
       folded value, it must not delete the only copy that has it. */
    const a = makeWeb({ openFails: true });
    const A = loadStore(a);
    await A.ready();
    A.set(KEY, { note: 'NEW' });
    await settle();

    const b = reload(a, { putFails: true });
    b.db.set(KEY, { note: 'OLD' });
    const B = loadStore(b);
    await B.ready();
    await settle();

    ok('the local copy is still there', b.ls.get(KEY) !== undefined,
       b.ls.get(KEY) === undefined ? 'DELETED — the only newer copy is gone' : 'kept');
    ok('and it still carries its stamp, so the next launch retries',
       JSON.parse(b.ls.get('accsap12.store.fellback') || '[]').indexOf(KEY) > -1);
  }

  /* A deletion made while the database refused writes. The session that made
     it was hydrated from the database, so its fallback copy is whole: a key
     missing from it was deleted, and recovery must not fold it back in. */
  const CHAT = 'accsap12.chat';
  const deletedAcross = async (key, before, after) => {
    const a = makeWeb({ seed: { [key]: before }, putFails: true });
    const A = loadStore(a);
    await A.ready();
    ok('(the session was hydrated from the database)', JSON.stringify(A.get(key)) === JSON.stringify(before),
       JSON.stringify(A.get(key)));
    A.set(key, after);
    await settle();
    const b = reload(a, {});
    const B = loadStore(b);
    await B.ready();
    await settle();
    return { app: B.get(key), db: b.db.get(key), ls: b.ls.get(key),
             stamps: [b.ls.get('accsap12.store.fellback'), b.ls.get('accsap12.store.fellback.whole')] };
  };

  head('a deletion made while the database refused writes stays deleted');
  {
    const r = await deletedAcross(KEY, { keep: { t: 'kept' }, gone: { t: 'deleted' } }, { keep: { t: 'kept' } });
    ok('the deleted note does not come back to the app', JSON.stringify(r.app) === '{"keep":{"t":"kept"}}', JSON.stringify(r.app));
    ok('nor to the database', JSON.stringify(r.db) === '{"keep":{"t":"kept"}}', JSON.stringify(r.db));
    ok('the local copy is cleared once across', r.ls === undefined);
    ok('and both stamps with it', r.stamps[0] === undefined && r.stamps[1] === undefined, JSON.stringify(r.stamps));
  }

  head('deleting the last note leaves no notes');
  {
    const r = await deletedAcross(KEY, { only: { t: 'the last one' } }, {});
    ok('the app reads an empty map', JSON.stringify(r.app) === '{}', JSON.stringify(r.app));
    ok('and the database holds one', JSON.stringify(r.db) === '{}', JSON.stringify(r.db));
  }

  head('a conversation cleared while the database refused writes stays cleared');
  {
    const r = await deletedAcross(CHAT, { Q1: [{ content: 'cleared' }], Q2: [{ content: 'kept' }] },
                                  { Q2: [{ content: 'kept' }] });
    ok('the cleared conversation does not come back', JSON.stringify(r.app) === '{"Q2":[{"content":"kept"}]}', JSON.stringify(r.app));
    ok('nor to the database', JSON.stringify(r.db) === '{"Q2":[{"content":"kept"}]}', JSON.stringify(r.db));
  }

  head('a later session without the database, started from a whole copy, deletes too');
  {
    /* A: hydrated, writes refused, leaves a whole copy. C: no database at all,
       boots on that copy and deletes from it. B: the database is back. */
    const a = makeWeb({ seed: { [KEY]: { keep: 1, gone: 1 } }, putFails: true });
    const A = loadStore(a);
    await A.ready();
    A.set(KEY, { keep: 1, gone: 1, added: 1 });
    await settle();
    const c = reload(a, { openFails: true });
    const C = loadStore(c);
    await C.ready();
    ok('(C booted on the local copy)', JSON.stringify(C.get(KEY)) === '{"keep":1,"gone":1,"added":1}', JSON.stringify(C.get(KEY)));
    C.set(KEY, { keep: 1, added: 1 });
    await settle();
    const b = reload(c, {});
    const B = loadStore(b);
    await B.ready();
    await settle();
    ok('the note deleted in C stays deleted', JSON.stringify(B.get(KEY)) === '{"keep":1,"added":1}', JSON.stringify(B.get(KEY)));
  }

  head('a session that never saw the database still folds, and loses nothing');
  {
    /* The other side of the same line. The database will not open and
       localStorage has nothing (the key migrated long ago), so the app starts
       from an empty map: a note it writes is new, and the database's notes
       are ones it never saw, not ones it deleted. Taking its copy whole would
       throw all of them away. */
    const a = makeWeb({ openFails: true });
    const A = loadStore(a);
    await A.ready();
    A.set(KEY, { fresh: 1 });
    await settle();
    ok('(its copy is not marked whole)', a.ls.get('accsap12.store.fellback.whole') === undefined,
       String(a.ls.get('accsap12.store.fellback.whole')));
    const b = reload(a, {});
    b.db.set(KEY, { older: 1 });
    const B = loadStore(b);
    await B.ready();
    await settle();
    ok('the notes it never saw are kept, and its own is added', JSON.stringify(B.get(KEY)) === '{"older":1,"fresh":1}', JSON.stringify(B.get(KEY)));
  }

  head('a write that lands after a fallback retires the local copy');
  {
    /* One refused write leaves a whole local copy; the next write reaches the
       database. That copy is now OLDER than the database, and taken whole on
       the next launch it would throw away everything written after it. */
    const opts = { seed: { [KEY]: { a: 1 } }, putFails: true };
    const a = makeWeb(opts);
    const A = loadStore(a);
    await A.ready();
    A.set(KEY, { a: 1, b: 1 });
    await settle();
    ok('(the refused write fell back)', a.ls.get(KEY) !== undefined);
    opts.putFails = false;
    A.set(KEY, { a: 1, b: 1, c: 1 });
    await settle();
    ok('the stale local copy is removed once the database has the newer value', a.ls.get(KEY) === undefined,
       String(a.ls.get(KEY)));
    ok('and so are its stamps', a.ls.get('accsap12.store.fellback') === undefined &&
       a.ls.get('accsap12.store.fellback.whole') === undefined);
    const b = reload(a, {});
    const B = loadStore(b);
    await B.ready();
    await settle();
    ok('the next launch keeps what was written after the fallback', JSON.stringify(B.get(KEY)) === '{"a":1,"b":1,"c":1}',
       JSON.stringify(B.get(KEY)));
  }

  head('a local copy migration could not move is loaded, and survives the session');
  {
    /* X leaves a whole local copy. Y's migration cannot write it (the database
       still refuses), so it stays in localStorage — but Y must still load it,
       or Y works from the older database value, and whatever Y then writes is
       either missing the copy's entries or is overwritten by the copy later. */
    const x = makeWeb({ seed: { [KEY]: { a: 1 } }, putFails: true });
    const X = loadStore(x);
    await X.ready();
    X.set(KEY, { a: 1, b: 1 });
    await settle();
    /* Built by hand, not with reload(): reload() copies its options, so
       turning putFails off afterwards would never reach the fake. */
    const opts = { seed: Object.fromEntries(x.db), putFails: true };
    const y = makeWeb(opts);
    for (const [k, v] of x.ls) y.ls.set(k, v);
    const Y = loadStore(y);
    await Y.ready();
    await settle();
    ok('the session loads the entry only the local copy has', JSON.stringify(Y.get(KEY)) === '{"a":1,"b":1}',
       JSON.stringify(Y.get(KEY)));
    opts.putFails = false;
    Y.set(KEY, Object.assign({}, Y.get(KEY), { c: 1 }));
    await settle();
    ok('(the session\'s write reached the database)', JSON.stringify(y.db.get(KEY)) === '{"a":1,"b":1,"c":1}',
       JSON.stringify(y.db.get(KEY)));
    ok('and the copy it loaded is retired', y.ls.get(KEY) === undefined, String(y.ls.get(KEY)));
    const z = reload(y, {});
    const Z = loadStore(z);
    await Z.ready();
    await settle();
    ok('the next launch has both the copy\'s entry and the session\'s write', JSON.stringify(Z.get(KEY)) === '{"a":1,"b":1,"c":1}',
       JSON.stringify(Z.get(KEY)));
  }

  head('a write made before hydration that the database refuses is kept');
  {
    /* set() before ready() is flushed by ready() against the merged value. The
       flush's result was thrown away, so a refused flush left no copy at all. */
    const a = makeWeb({ seed: { [KEY]: { a: 1, gone: 1 } }, putFails: true });
    const A = loadStore(a);
    A.set(KEY, { a: 1, early: 1 });
    await A.ready();
    await settle();
    ok('the refused flush fell back to localStorage', a.ls.get(KEY) !== undefined,
       a.ls.get(KEY) === undefined ? 'LOST — neither store has it' : String(a.ls.get(KEY)));
    const b = reload(a, {});
    const B = loadStore(b);
    await B.ready();
    await settle();
    ok('and the next launch has the early write', JSON.stringify(B.get(KEY)).indexOf('early') > -1, JSON.stringify(B.get(KEY)));
  }

  /* ── the mirror ─────────────────────────────────────────────────────────
     accsap12.v2 — the FSRS cards, the chapter statistics, the streak — stays
     in localStorage because load() reads it synchronously at boot. That makes
     it the one irreplaceable key with no protection against iOS evicting a
     site's localStorage after seven days. The mirror keeps a copy in the
     database without touching the synchronous path.

     An eviction is modelled as what it actually is: the database survives and
     localStorage does not. reload() copies both, so these build the second
     session by hand. */
  const V2 = 'accsap12.v2';
  const PROGRESS = { schemaVersion: 1, srs: { COR_1: { d: 4.2, s: 91 } }, reviewStreak: 63 };
  const EMPTY = { schemaVersion: 1, srs: {}, reviewStreak: 0 };
  /* What a session that has been through ready() leaves in the database. */
  const afterASession = async (value) => {
    const web = makeWeb({});
    web.ls.set(V2, JSON.stringify(value));
    const S = loadStore(web);
    await S.ready();
    await settle();
    S.mirror(V2);
    await settle();
    return web;
  };
  /* An eviction: the database as it was, localStorage wiped. */
  const evict = prev => makeWeb({ seed: Object.fromEntries(prev.db) });

  head('the mirrored key is not a managed key');
  {
    const S = loadStore(makeWeb({}));
    ok('accsap12.v2 is mirrored', S.MIRRORED.indexOf(V2) > -1, S.MIRRORED.join(', '));
    ok('and is NOT managed — the synchronous boot read is untouched',
       S.MANAGED.indexOf(V2) < 0);
    ok('the copy is namespaced away from the managed keys',
       S.MIRROR_PREFIX.length > 0 && S.MANAGED.every(k => k !== S.MIRROR_PREFIX + V2));
  }

  head('a copy is kept, and localStorage is never taken over');
  {
    const web = await afterASession(PROGRESS);
    ok('the database holds a copy', JSON.stringify(web.db.get('mirror:' + V2)) === JSON.stringify(PROGRESS),
       JSON.stringify(web.db.get('mirror:' + V2)));
    ok('and localStorage still holds the original, untouched',
       web.ls.get(V2) === JSON.stringify(PROGRESS));
    ok('the key did not move into the managed store',
       web.db.get(V2) === undefined);
  }

  head('an eviction is survived — the whole point');
  {
    const first = await afterASession(PROGRESS);
    const web = evict(first);
    ok('localStorage really is empty at the start of the session',
       web.ls.get(V2) === undefined);
    const S = loadStore(web);
    const r = await S.ready();
    await settle();
    ok('ready() reports what it put back', !!r && (r.restored || []).indexOf(V2) > -1,
       JSON.stringify(r && r.restored));
    ok('and the streak is back in localStorage, where load() will find it',
       JSON.parse(web.ls.get(V2) || '{}').reviewStreak === 63,
       String(JSON.parse(web.ls.get(V2) || '{}').reviewStreak));
    ok('with the cards intact, which is the part nobody can rebuild',
       JSON.stringify(JSON.parse(web.ls.get(V2)).srs) === JSON.stringify(PROGRESS.srs));
  }

  head('a save during the evicted boot does not destroy the copy');
  {
    /* THE FAILURE THIS WHOLE DESIGN IS SHAPED AROUND. The app boots on an
       empty store and calls save() long before the database answers. If the
       mirror were live at that moment it would copy a blob of empty defaults
       over the only surviving progress — destroyed by the boot that was about
       to rescue it, and looking exactly like success. */
    const first = await afterASession(PROGRESS);
    const web = evict(first);
    const S = loadStore(web);
    const booting = S.ready();
    /* The app, mid-boot: empty S, and a save. */
    web.ls.set(V2, JSON.stringify(EMPTY));
    ok('the mirror refuses to write before the restore pass has run',
       S.mirror(V2) === false);
    ok('and says so in health(), rather than looking protected',
       S.health().mirroring === false);
    await booting;
    await settle();
    ok('the copy in the database is still the real progress',
       JSON.parse(JSON.stringify(web.db.get('mirror:' + V2))).reviewStreak === 63,
       JSON.stringify(web.db.get('mirror:' + V2)));
    ok('and the empty blob the boot wrote has been replaced by it',
       JSON.parse(web.ls.get(V2)).reviewStreak === 63,
       String(JSON.parse(web.ls.get(V2)).reviewStreak));
    ok('the mirror is armed once the pass is done', S.health().mirroring === true);
  }

  head('a live localStorage is always the authority');
  {
    /* The reverse direction, which must never happen: a stale copy must not
       come back over a store that has something in it. */
    const first = await afterASession(PROGRESS);
    const web = makeWeb({ seed: Object.fromEntries(first.db) });
    const NEWER = { schemaVersion: 1, srs: { COR_1: { d: 9.9, s: 400 } }, reviewStreak: 64 };
    web.ls.set(V2, JSON.stringify(NEWER));
    const S = loadStore(web);
    const r = await S.ready();
    await settle();
    ok('nothing is restored over a store that has a value',
       (r.restored || []).length === 0, JSON.stringify(r.restored));
    ok('localStorage still holds the newer value',
       JSON.parse(web.ls.get(V2)).reviewStreak === 64);
    ok('and the copy was refreshed from it, not the other way round',
       JSON.parse(JSON.stringify(web.db.get('mirror:' + V2))).reviewStreak === 64,
       JSON.stringify(web.db.get('mirror:' + V2)));
  }

  head('a first run is not mistaken for an eviction');
  {
    const web = makeWeb({});
    const S = loadStore(web);
    const r = await S.ready();
    await settle();
    ok('nothing is restored when there was never anything',
       (r.restored || []).length === 0, JSON.stringify(r.restored));
    ok('and localStorage is left empty rather than stamped with a default',
       web.ls.get(V2) === undefined);
  }

  head('no database means no false sense of safety');
  {
    const web = makeWeb({ openFails: true });
    web.ls.set(V2, JSON.stringify(PROGRESS));
    const S = loadStore(web);
    await S.ready();
    await settle();
    ok('health() says the mirror is not running', S.health().mirroring === false);
    ok('mirror() is a no-op rather than a thrown error', S.mirror(V2) === false);
    ok('and the data is exactly where the app left it',
       web.ls.get(V2) === JSON.stringify(PROGRESS));
  }

  head('a database that will not accept the copy loses nothing');
  {
    const web = makeWeb({ putFails: true });
    web.ls.set(V2, JSON.stringify(PROGRESS));
    const S = loadStore(web);
    await S.ready();
    await settle();
    S.mirror(V2);
    await settle();
    ok('localStorage is untouched by a refused copy',
       web.ls.get(V2) === JSON.stringify(PROGRESS));
    ok('and no copy was recorded', web.db.get('mirror:' + V2) === undefined);
  }

  head('mirroring is cheap enough to call on a timer');
  {
    /* The caller is a visibility handler and an interval, not save() — save()'s
       last line was the anchor scripts/resume-patch.js matched on. So mirror()
       has to be free when nothing changed. */
    const web = makeWeb({});
    web.ls.set(V2, JSON.stringify(PROGRESS));
    const S = loadStore(web);
    await S.ready();
    await settle();
    let writes = 0;
    const put = web.db.set.bind(web.db);
    web.db.set = (k, v) => { if (String(k).indexOf('mirror:') === 0) writes++; return put(k, v); };

    ok('the first call after a change copies', S.mirror(V2) === true);
    await settle();
    /* Counted as a DELTA around each phase. The first version of this asserted
       an absolute total and was simply wrong about when counting began — the
       code was right and the check was not. */
    const before = writes;
    ok('an unchanged blob is skipped', S.mirror(V2) === false);
    await settle();
    ok('and cost no transaction', writes - before === 0, `${writes - before} write(s)`);

    web.ls.set(V2, JSON.stringify({ ...PROGRESS, reviewStreak: 64 }));
    const beforeChange = writes;
    ok('a changed blob is copied again', S.mirror(V2) === true);
    await settle();
    ok('which did write exactly once', writes - beforeChange === 1, `${writes - beforeChange} write(s)`);
    ok('and the copy is the new value',
       JSON.parse(JSON.stringify(web.db.get('mirror:' + V2))).reviewStreak === 64);
  }

  head('a refused copy is retried rather than remembered as done');
  {
    /* The skip above must not make a failure permanent: if the write was
       refused, the next call has to try again. */
    const web = makeWeb({ putFails: true });
    web.ls.set(V2, JSON.stringify(PROGRESS));
    const S = loadStore(web);
    await S.ready();
    await settle();
    S.mirror(V2);
    await settle();
    ok('nothing was stored', web.db.get('mirror:' + V2) === undefined);
    ok('and the same unchanged blob is attempted again, not skipped',
       S.mirror(V2) === true);
  }

  head('an unmirrored key is refused by name');
  {
    const web = makeWeb({});
    web.ls.set(KEY, JSON.stringify({ a: 1 }));
    const S = loadStore(web);
    await S.ready();
    await settle();
    ok('mirror() only takes the keys it was told about', S.mirror(KEY) === false);
    ok('and wrote no copy of one it was not', web.db.get('mirror:' + KEY) === undefined);
  }

  head('a database whose open never answers');
  {
    /* indexedDB.open() firing none of success, error or blocked used to leave
       usable at null for the whole session: set() never took the fallback, so
       every write waited on a promise that never settled, and ready() — which
       Export and Import await — never resolved. The module's own setTimeout is
       swapped for one that runs its delay in a few milliseconds, and records
       the delay it was asked for, so the wait is checked without being spent.
       The fake web keeps the real timers. */
    const asked = [];
    const quick = (fn, ms) => { asked.push(ms); return setTimeout(fn, Math.min(ms, 30)); };
    const HUNG = 'still waiting after 2 s';
    const web = makeWeb({ openHangs: true });
    const S = loadModule(fs, path, 'src/core/store.js', web, { setTimeout: quick }).Store;
    const r = await Promise.race([S.ready(), new Promise(res => setTimeout(() => res(HUNG), 2000))]);
    ok('ready() settles instead of waiting for ever', r !== HUNG && !!r && r.available === false,
       JSON.stringify(r));
    ok('after giving the database a few seconds (1-10 s), not none',
       asked.some(ms => ms >= 1000 && ms <= 10000), asked.join(', ') || 'no timer was set');
    S.set(KEY, { kept: 'written while the database hung' });
    await settle();
    ok('a write then lands in localStorage', String(web.ls.get(KEY) || '').indexOf('hung') > -1,
       web.ls.get(KEY) === undefined ? 'LOST — neither store has it' : web.ls.get(KEY));
    ok('and is stamped as having fallen back',
       JSON.parse(web.ls.get('accsap12.store.fellback') || '[]').indexOf(KEY) > -1);
    /* No health().usable check here: it reads `usable === true`, so it is
       false for a session still waiting on the open too, and it stayed green
       with the timeout removed. */
  }

  head('a database that answers only after the session gave up on it');
  {
    /* The late connection is closed, not adopted: the session has already
       fallen back, and half of it on each store is the state migrate() exists
       to untangle, not one to create. */
    const quick = (fn, ms) => setTimeout(fn, Math.min(ms, 30));
    const web = makeWeb({ openAfter: 150 });
    const S = loadModule(fs, path, 'src/core/store.js', web, { setTimeout: quick }).Store;
    const r = await S.ready();
    ok('the session fell back first', r.available === false, JSON.stringify(r));
    await new Promise(res => setTimeout(res, 250));
    ok('the connection that arrived later was closed', web.closed === 1, `${web.closed} closed`);
    S.set(KEY, { after: 'late' });
    await settle();
    ok('and writes still go to localStorage, not the late database',
       String(web.ls.get(KEY) || '').indexOf('late') > -1 && web.db.get(KEY) === undefined,
       `ls=${web.ls.get(KEY)} db=${JSON.stringify(web.db.get(KEY))}`);
  }

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
