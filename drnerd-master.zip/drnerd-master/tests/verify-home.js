#!/usr/bin/env node
/*
 * Checks for the reworked home screen.
 *
 *   NODE_PATH=$(npm root -g) node tests/verify-home.js <patched.html|url>
 *
 * Four claims:
 *   · the welcome bar (the hero ECG strip) is genuinely larger than it was;
 *   · the Brain page's gauge reports the REAL state of the bank — its mastery
 *     ring is FSRS's own recall estimate and is drawn to the number it shows,
 *     and mastery never exceeds coverage (you cannot have mastered more than
 *     you have seen). The progress bar that said this on Home is gone (the
 *     owner's call: its numbers were the gauge's);
 *   · home says ONE thing: the trace and the pearl — the study material it
 *     used to carry is behind a door on the Labs page rather than below the
 *     fold;
 *   · S.homeLayout still persists and still reaches the home screen's own
 *     hero sizing on a cold load. It used to also drive a visible three-way
 *     switch — Signal/Focus/Grid — but studyflow removed that control: it
 *     lived on the Chapters page despite the name, governed only that page's
 *     rail/feed/tile density, and Chapters is now one fixed, uniform design.
 *     What is left of homeLayout is inert for Chapters and real for Home,
 *     and only the Home-real part is still asserted here.
 */
'use strict';
const path = require('path');
const { launch, isEngineNoise } = require('./_engine');
const { booted, watchTransitions, resized, settled } = require('./_render.js');
const { onDeath } = require('./_deathnote.js');

const target = process.argv[2];
if (!target) { console.error('usage: node tests/verify-home.js <patched.html|url>'); process.exit(1); }
const URL = /^https?:\/\//.test(target) ? target : 'file://' + path.resolve(target);

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

/* The array the last check asserts on, hoisted out of the closure so the death
   note can read it. This suite dies on WebKit against the served build, and
   `ok('no console or page errors across the run', …)` — the check that would
   have shown why — is the one check a death never reaches. */
const errors = [];
/* CRASH AND CLOSE ARE DIFFERENT DIAGNOSES and the runner cannot tell them
   apart: Playwright says "Target page, context or browser has been closed" for
   both, on the next call either way. If the crash event fired, the browser
   killed the page and the answer is not in the JavaScript. */
const events = [];
onDeath(() => ({ section, checks: passed + failed, errors,
                 events: events.length ? events.join(', ') : 'none' }));

(async () => {
  const browser = await launch();
  const page = await browser.newPage({ viewport: { width: 460, height: 1000 }, deviceScaleFactor: 2 });
  await watchTransitions(page);   /* before goto: see _render.js */
  page.on('crash', () => events.push('the browser CRASHED the page'));
  page.on('close', () => events.push('the page closed'));
  page.on('requestfailed', r => {
    const why = (r.failure() || {}).errorText || '';
    if (why) events.push(`request failed: ${String(r.url()).slice(-60)} — ${why}`);
  });
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !isEngineNoise(m.text())) errors.push(m.text()); });

  await page.goto(URL, { waitUntil: 'load', timeout: 250000 });
  await booted(page, { timeout: 150000 });

  /* Seed a realistic spread of progress so the gauge and the numbers are testable
     and mastery lands strictly below coverage. */
  await page.evaluate(() => {
    const now = todayISO();
    let i = 0;
    for (const q of POOL) {
      i++;
      /* every third card seen; give them a range of stabilities so recall — and
         therefore mastery — comes out well under coverage */
      if (i % 3 === 0) S.srs[q.id] = { stability: 0.6 + (i % 5) * 0.4, last: now, reps: 1 };
      if (i > 300) break;
    }
    save(); render();
  });
  /* The gauge's rings are drawn when the Brain page is first shown (homeFillBrain), and grow over 1.3s. Measured once
     they have stopped: a ring mid-growth is shorter than its value and would fail for a reason that has nothing to do
     with the number. */
  await page.evaluate(() => homeGo(1, true));
  await settled(page, () => { const c = document.querySelector('#homePage1 .bg-mast');
    return !!c && !!c.style.strokeDasharray && !document.getAnimations().some(a => a.playState === 'running' && a.effect && Number.isFinite(a.effect.getTiming().iterations)); },
    { timeout: 15000, label: 'the gauge to be drawn' });
  await page.evaluate(() => homeGo(0, true));
  /* Back on Home, and landed: a page still gliding is drawn scaled (it eases back as it arrives), which would read every
     size on it short. */
  await settled(page, () => !homeTween && document.getElementById('homePager').scrollLeft === 0 &&
    document.getElementById('homePage0').style.getPropertyValue('--hp-d') === '0.0000', { timeout: 15000, label: 'Home to land' });

  head('the welcome bar is larger');
  const ecgH = await page.evaluate(() => {
    const cv = document.getElementById('heroECG');
    return cv ? cv.getBoundingClientRect().height : 0;
  });
  ok('the hero ECG strip is taller than the old 104px ceiling at its minimum', ecgH >= 88, `${ecgH.toFixed(0)}px`);

  head('the Brain page\'s gauge reflects the real bank');
  const prog = await page.evaluate(() => {
    const seen = document.querySelector('#homePage1 .bg-seen'), mast = document.querySelector('#homePage1 .bg-mast');
    const drawn = c => parseFloat(getComputedStyle(c).strokeDasharray);
    return { seenFrac: +seen.dataset.frac, mastFrac: +mast.dataset.frac, seenDrawn: drawn(seen), mastDrawn: drawn(mast),
      mid: document.querySelector('#homePage1 .brain-mid b').textContent.trim(),
      label: document.querySelector('#homePage1 .brain-gauge').getAttribute('aria-label'),
      bar: !!document.querySelector('.hp-track') };
  });
  ok('the gauge has both a coverage ring and a mastery ring, and some of the bank is seen', prog.seenFrac > 0 && prog.mastFrac >= 0,
     `seen ${prog.seenFrac}, mastered ${prog.mastFrac}`);
  ok('mastery never exceeds coverage — you cannot master the unseen', prog.mastFrac <= prog.seenFrac,
     `${prog.mastFrac} ≤ ${prog.seenFrac}`);
  ok('the drawn mastery ring matches its number', Math.abs(prog.mastDrawn - prog.mastFrac) < 1 && prog.mid === prog.mastFrac + '%',
     `drawn ${prog.mastDrawn} of 100, number ${prog.mid}`);
  ok('and so does the coverage ring', Math.abs(prog.seenDrawn - prog.seenFrac) < 1, `drawn ${prog.seenDrawn}, ${prog.seenFrac}%`);
  ok('the gauge states both figures in words', /mastered/i.test(prog.label) && /seen/i.test(prog.label), prog.label);
  const homeProgress = await page.evaluate(() => {
    const meter=document.querySelector('.observatory-meter');
    const numbers=[...document.querySelectorAll('.observatory-stats strong')].map(el=>parseInt(el.textContent,10));
    const seen=startedCount(), percentage=TOTAL_Q?Math.min(100,Math.round(seen/TOTAL_Q*100)):0;
    return !!meter && Number(meter.getAttribute('aria-valuenow'))===seen &&
      Number(meter.getAttribute('aria-valuemax'))===Math.max(1,TOTAL_Q) &&
      meter.querySelector('span').style.width===percentage+'%' &&
      JSON.stringify(numbers)===JSON.stringify([percentage,(S.daily[todayISO()]||{a:0}).a,dueQuestions().length]);
  });
  const metricEdges = await page.evaluate(() => {
    const srs=S.srs, practice=S.practice, daily=S.daily, paused=atlasPaused;
    try {
      const first=POOL[0].id, foreign='__audit_absent_question__';
      if(POOL.some(q=>q.id===foreign))throw new Error('audit id must be absent');
      S.srs={[first]:{}};S.practice={[first]:{},[foreign]:{}};
      const coverage=startedCount()===1 && Object.hasOwn(S.practice,foreign);
      S.daily={[todayISO()]:{a:7,c:4,r:2}};
      const detached=document.createElement('div');detached.innerHTML=buildHome();
      const today=detached.querySelector('.observatory-stats>div:nth-child(2)');
      const label=today.querySelector('span').textContent==='Answers today' && today.querySelector('strong').textContent==='7';
      if(!atlasPaused)toggleAtlasMotion();
      const fill=document.querySelector('.observatory-meter>span');
      fill.style.animation='none';void fill.offsetWidth;fill.style.animation='';
      const css=getComputedStyle(fill);
      const motion=css.animationName==='none'||css.animationPlayState==='paused';
      return {coverage,label,motion};
    } finally {
      S.srs=srs;S.practice=practice;S.daily=daily;
      if(atlasPaused!==paused)toggleAtlasMotion();
    }
  });
  ok('Home metrics count current-bank answers, label them accurately and respect pause',
    homeProgress && metricEdges.coverage && metricEdges.label && metricEdges.motion,JSON.stringify(metricEdges));

  head('it fills the display, like an app');
  /* Added to the Home Screen, iPadOS gives a web app the whole screen and draws
     the status bar over it. The bar lived inside #app — a 960px reading
     measure, centred — so on a 1366px iPad it was a floating strip with 203px
     of page showing either side: a browser with the chrome hidden, not an app. */
  const chrome = await page.evaluate(() => {
    const bar = document.getElementById('navbar');
    const nav = document.querySelector('.nav');
    if (!bar || !nav) return null;
    const b = bar.getBoundingClientRect(), n = nav.getBoundingClientRect();
    return {
      barL: b.left, barR: b.right, vw: innerWidth,
      navL: n.left, navW: n.width,
      outsideApp: !document.getElementById('app').contains(nav),
      overflow: document.documentElement.scrollWidth <= document.documentElement.clientWidth + 1,
    };
  });
  ok('the bar is outside the reading column', chrome && chrome.outsideApp);
  ok('and its colour reaches both edges of the display',
     chrome.barL <= 0 && chrome.barR >= chrome.vw, `${chrome.barL}–${chrome.barR} of ${chrome.vw}`);
  /* Full bleed must not mean full width: a wordmark alone in the far corner of
     a 1366px screen is not what a native app does either. */
  ok('while its contents keep the measure the page below it keeps',
     chrome.navW <= chrome.vw, `${Math.round(chrome.navW)}px in ${chrome.vw}px`);
  /* Fixed, not 100vw — 100vw counts the scrollbar and would add a sideways
     scroll on a desktop. */
  ok('and nothing spills sideways', chrome.overflow);

  /* env() cannot be given a value from a test, which is why the insets are
     named variables. Set a real one and the chrome must move: the colour stays
     welded to the top edge, the contents step below the clock, and the screen
     starts below all of it. */
  const inset = await page.evaluate(() => {
    document.documentElement.style.setProperty('--sat', '24px');
    return new Promise(r => setTimeout(() => {
      const b = document.getElementById('navbar').getBoundingClientRect();
      const n = document.querySelector('.nav').getBoundingClientRect();
      const app = document.getElementById('app').getBoundingClientRect();
      document.documentElement.style.removeProperty('--sat');
      r({ barTop: b.top, barH: b.height, navTop: n.top, appTop: app.top });
    }, 200));
  });
  ok('with a status bar, the colour still starts at the very top', inset.barTop <= 0.5, `${inset.barTop}px`);
  ok('the bar grows by exactly the inset', inset.barH >= 58 + 24 - 1, `${Math.round(inset.barH)}px`);
  ok('its contents clear the clock', inset.navTop >= 23.5, `${Math.round(inset.navTop)}px`);
  ok('and the screen begins below the bar', inset.appTop >= inset.barH - 1,
     `app at ${Math.round(inset.appTop)}, bar ${Math.round(inset.barH)}`);

  /* AND env() CANNOT TELL US ABOUT AN IPAD. iPadOS reports
     safe-area-inset-top: 0 for an installed web app, because a device with no
     notch has no geometrically unsafe area — yet the status bar is still drawn
     over the page, so the clock landed on the wordmark. Being installed is the
     fact that matters, and .installed on <html> carries it. */
  const home = await page.evaluate(() => {
    const read = () => {
      const bar = document.getElementById('navbar').getBoundingClientRect();
      const nav = document.querySelector('.nav').getBoundingClientRect();
      return { barH: bar.height, navTop: nav.top };
    };
    const inBrowser = read();
    document.documentElement.classList.add('installed');
    const installed = read();
    document.documentElement.classList.remove('installed');
    return { inBrowser, installed, tall: innerHeight >= 600 };
  });
  ok('in a browser tab nothing is reserved — the browser draws its own chrome',
     home.inBrowser.navTop < 1, `${home.inBrowser.navTop}px`);
  ok('but installed, the bar reserves the strip the status bar is drawn in',
     !home.tall || home.installed.navTop >= 23.5, `${home.installed.navTop}px`);
  ok('and grows rather than shifting, so the colour still meets the top edge',
     !home.tall || home.installed.barH > home.inBrowser.barH + 20,
     `${Math.round(home.inBrowser.barH)} → ${Math.round(home.installed.barH)}`);

  head('home says one thing, and the rest is behind a door');
  const homeShape = await page.evaluate(() => ({
    hero: !!document.querySelector('.hero-live #heroECG'),
    pearl: !!document.querySelector('.pearl-card'),
    pearlPV: !!document.querySelector('.pearl-card #pearlPV'),
    pearlCurrent: !!document.querySelector('.pearl-card #pearlCurrent'),
    homeDoors: document.querySelectorAll('#homePage0 .door').length,
    doors: document.querySelectorAll('#homePage2 .door-row .door').length,
    rail: !!document.querySelector('.story-rail'),
    feed: !!document.querySelector('.feed'),
    tiles: document.querySelectorAll('.ch-tile').length,
    /* The doors label where they lead; a row of bare icons would be a puzzle. */
    labels: [...document.querySelectorAll('.door .door-txt b')].map(b => b.textContent.trim()),
  }));
  ok('the trace and the pearl are on it, and no doors',
     homeShape.hero && homeShape.pearl && homeShape.homeDoors === 0, `${homeShape.homeDoors} doors on Home`);
  /* The pressure-volume loop was a good drawing in a bad place — 104px pinned
     in the corner of the prose column. It is now a full-width ECG trace running
     behind the words, which is what the card wanted along its foot. */
  ok('the pearl carries a current of its own', homeShape.pearlCurrent);
  ok('and the corner loop it replaced is gone', homeShape.pearlPV === false);
  ok('the doors are a row on the Labs page, under the labs', homeShape.doors >= 5, String(homeShape.doors));
  const firstDoor = await page.evaluate(() => {
    const d = document.querySelector('#homePage2 .door-row .door');
    return { wide: d.classList.contains('door-wide'),
             widerThanNext: d.getBoundingClientRect().width >
                            document.querySelectorAll('#homePage2 .door-row .door')[1].getBoundingClientRect().width };
  });
  ok('Chapters is the first door, and the widest',
     homeShape.labels[0] === 'Chapters' && firstDoor.wide && firstDoor.widerThanNext,
     homeShape.labels.join(', '));
  ok('the study material is NOT on the home screen any more',
     !homeShape.rail && !homeShape.feed && homeShape.tiles === 0,
     `rail ${homeShape.rail}, feed ${homeShape.feed}, ${homeShape.tiles} tiles`);

  /* render() runs inside document.startViewTransition, so the DOM is not
     updated by the time the click handler returns — wait for the screen the
     door opens onto rather than reading straight after. */
  await page.evaluate(() => document.querySelector('.door-wide').click());
  await page.waitForFunction(() => typeof S !== 'undefined' && S.screen === 'study'
    && !!document.querySelector('.ch-tile'), null, { timeout: 15000 });
  const study = await page.evaluate(() => ({
    screen: S.screen,
    tiles: document.querySelectorAll('.ch-tile').length,
    rail: document.querySelectorAll('.story-rail .story').length,
    review: !!document.querySelector('.review-card'),
    shuffle: !!document.querySelector('.all-card'),
    back: !!document.querySelector('.study-back'),
    chapters: typeof CHAPTERS !== 'undefined' ? CHAPTERS.length : 0,
  }));
  ok('the door opens a page of its own', study.screen === 'study');
  ok('every chapter has a tile there', study.tiles === study.chapters, `${study.tiles} of ${study.chapters}`);
  ok('and a ring on the rail', study.rail === study.chapters, `${study.rail} of ${study.chapters}`);
  ok('the review queue and the full shuffle came with them', study.review && study.shuffle);
  ok('there is a way back', study.back);

  head('chapters is one fixed design now, not a switch between three');
  /* studyflow removed the only control that ever called setHomeLayout() from
     the UI. The rail/feed/tile density it used to govern all lived on this
     page, so the honest claim now is "the switch is gone and Chapters no
     longer varies", not "Focus/Grid still work" — calling setHomeLayout
     directly and checking for an effect on this screen would be asserting a
     behavior no user can ever reach again. */
  const gone = await page.evaluate(async () => {
    const before = document.querySelectorAll('.hl-seg').length;
    const railBefore = getComputedStyle(document.querySelector('.story-rail')).display;
    /* 'focus' specifically, not 'grid': focus is the one value that used to
       hide the rail outright, so this is the value that actually exercises
       whether calling the function still reaches this page at all. */
    setHomeLayout('focus');                     // still callable — see "the choice persists" below
    await new Promise(r => setTimeout(r, 260));
    const railAfter = getComputedStyle(document.querySelector('.story-rail')).display;
    return {
      segsOnPage: before,
      studyWrapAttr: document.querySelector('.study-wrap').getAttribute('data-home'),
      railUnaffectedByGrid: railBefore === railAfter,
    };
  });
  ok('no layout switch remains on the page', gone.segsOnPage === 0, String(gone.segsOnPage));
  ok('the study wrapper carries no data-home for anything to key off',
     gone.studyWrapAttr === null, String(gone.studyWrapAttr));
  ok('calling the old function directly no longer changes this page',
     gone.railUnaffectedByGrid);

  head('the choice persists');
  const persisted = await page.evaluate(() => {
    setHomeLayout('focus');
    return JSON.parse(localStorage.getItem('accsap12.v2')).homeLayout;
  });
  ok('the layout is saved', persisted === 'focus', persisted);

  await page.reload({ waitUntil: 'load', timeout: 250000 });
  await page.waitForFunction(() => typeof S !== 'undefined' && !!document.querySelector('.home-wrap'), null, { timeout: 150000 });
  /* A cold load lands on home, which still carries data-home — the one real
     survivor of the old switch, since it sizes buildHome()'s own hero. This
     is genuinely Home's behavior, not Chapters', so it stays asserted. */
  const afterReload = await page.evaluate(() => ({
    state: S.homeLayout,
    attr: document.querySelector('.home-wrap').getAttribute('data-home'),
  }));
  ok('the persisted state itself survives a cold load', afterReload.state === 'focus', afterReload.state);
  ok('and the home screen wears the restored layout too', afterReload.attr === 'focus', afterReload.attr);


  head('the home screen fills the iPad it is on');
  {
    /* Named so the message below quotes the cap it actually waited for
       rather than a number typed beside it. */
    const SETTLE_MS = 15000;
    /* Read back only when the wait has already failed, so it costs a healthy
       run nothing. Serialised into the page by page.evaluate, which is why it
       is a plain declaration and reads nothing from this scope. */
    async function stillMoving() {
      const read = () => {
        const a = document.getElementById('app');
        const r = a ? a.getBoundingClientRect() : { width: 0, height: 0 };
        return [innerWidth, innerHeight, Math.round(r.width), Math.round(r.height),
                document.documentElement.scrollHeight].join(',');
      };
      /* TWO SAMPLES, A FRAME APART, and this is the whole point of the read.
         One sample and the counter is all there is, and the two together can
         look self-contradictory: a first version reported "0/5 frames" beside
         a key identical to the last one the predicate saw, which reads as
         "nothing was moving, and it never settled". Two samples answer the
         actual question — is it STILL moving, right now — rather than leaving
         it to be inferred. Not a sleep: the frame is what is being measured
         over, and a value is read on the other side of it. */
      const before = read();
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
      const after = read();
      const anims = document.getAnimations()
        .filter(x => x.playState === 'running'
                  && Number.isFinite(x.effect && x.effect.getTiming().iterations))
        .map(x => {
          const t = x.effect && x.effect.target;
          const who = x.animationName || (t && t.className && String(t.className).split(' ')[0]) || 'anim';
          return who + '@' + Math.round(Number(x.currentTime) || 0) + 'ms';
        })
        .slice(0, 6);
      return { frames: window.__s || 0, before, after, moved: before !== after, anims };
    }
    /* MEASURED BEFORE THIS WAS BUILT, on 1366x1024: #app was capped at 960px —
       406px of dead space down the sides — and the four stacked blocks ran to
       1142px against a 1024px viewport, so it scrolled by 118px. Both numbers
       are asserted here, from the other side. */
    const settle = async () => {
      await page.evaluate(() => { window.__s = 0; window.__l = null; });
      await page.waitForFunction(() => {
        const a = document.getElementById('app');
        const r = a.getBoundingClientRect();
        /* The document's own height belongs in this key. #app can settle to a
           stable box while a child — the pearl card, the hero canvas — is
           still growing the page under it, and `over` is measured on
           documentElement.scrollHeight, not on #app. Waiting for less than the
           check asserts is what made this suite pass alone and fail under
           load: the same defect verify-assets had. */
        const k = [innerWidth, innerHeight, Math.round(r.width), Math.round(r.height),
                   document.documentElement.scrollHeight].join(',');
        /* A box that has held still for five frames is not settled if the
           animation that will move it has not started yet — which is what a
           loaded machine produces. Finite animations only: the shimmer and the
           hero ECG loop forever and would never let this return. */
        const busy = document.getAnimations().some(a =>
          a.playState === 'running' &&
          Number.isFinite(a.effect && a.effect.getTiming().iterations));
        window.__s = (window.__l === k && !busy) ? (window.__s || 0) + 1 : 0;
        window.__l = k;
        return window.__s >= 5;
      }, null, { timeout: SETTLE_MS, polling: 'raf' }).catch(async e => {
        /* WHAT WAS STILL MOVING. The wait above is unchanged — same key, same
           five frames, same animation test, same cap. Only its failure speaks
           now.

           It had to, because this suite fails intermittently under sustained
           load and passes cold, and a Playwright timeout says "waiting for
           function failed" and nothing else. The death note added for this
           suite names the section and then reports that the page logged
           nothing at all — true, and exactly as unhelpful as home's original
           failure was before it had one.

           Geometry, frame count and animation names only: no page text, so
           the line is safe to paste out of a run. */
        const d = await page.evaluate(stillMoving).catch(() => null);
        throw new Error('settle() never held still' + (d
          ? ` — ${d.frames}/5 frames; ` + (d.moved
              ? `still moving: [${d.before}] → [${d.after}] one frame later`
              : `not moving now: [${d.after}]`)
            + (d.anims.length ? `; running: ${d.anims.join(' ')}`
                              : '; no finite animation running')
          : ' — and the page could not be read afterwards')
          + ` (gave up after ${SETTLE_MS}ms)`);
      });
    };
    const at = async (w, h) => {
      await resized(page, w, h);
      /* A precondition: settled()'s standard timeout and a named failure, not 8 s of its own (the same
         wait ran out in verify-apex on the owner's laptop on the 92 MB build). */
      await settled(page, ([w, h]) => Math.abs(innerWidth - w) <= 2 && Math.abs(innerHeight - h) <= 2,
        { arg: [w, h], label: `the viewport to become ${w}x${h}` });
      await page.evaluate(() => { goHome(); render(); });
      await settle();
      return page.evaluate(() => {
        const app = document.getElementById('app');
        const R = s => { const el = document.querySelector(s); if (!el) return null;
          const r = el.getBoundingClientRect(); return { x: Math.round(r.x), y: Math.round(r.y),
            w: Math.round(r.width), h: Math.round(r.height) }; };
        return { appW: Math.round(app.getBoundingClientRect().width), vw: innerWidth,
                 over: document.documentElement.scrollHeight - innerHeight,
                 screen: app.dataset.screen,
                 hero: R('.hero-live'), pearl: R('.pearl-card'), doors: R('.door-row'), col: R('#homePage0 .home-page-in'),
                 homeDoors: document.querySelectorAll(document.getElementById('homePage0') ? '#homePage0 .door' : '#app .door').length, labDoors: document.querySelectorAll('#homePage2 .door').length };
      });
    };

    const pro = await at(1366, 1024);
    ok('the shell says which screen it is showing', pro.screen === 'home', String(pro.screen));
    ok('a landscape iPad Pro uses its whole width',
       pro.appW / pro.vw > 0.9, `${pro.appW} of ${pro.vw}`);
    ok('and the home screen fits in one screen, with nothing to scroll',
       pro.over <= 0, `${pro.over}px over`);
    ok('the live heart leads the pearl in landscape',
       pro.pearl.x >= pro.hero.x + pro.hero.w - 4, `pearl x${pro.pearl.x} vs hero right ${pro.hero.x + pro.hero.w}`);
    ok('and it runs taller than the letterbox it used to be',
       pro.pearl.h > 400, `${pro.pearl.h}px tall`);
    /* The doors moved off Home: it is the hero and the pearl now, and the doors are on the Labs page, two swipes away
       (verify-homepager). */
    ok('no doors under the hero any more: they are on the Labs page',
       pro.homeDoors === 0 && pro.labDoors >= 5, `${pro.homeDoors} on Home, ${pro.labDoors} on Labs`);

    const air = await at(1194, 834);
    ok('an 11-inch iPad in landscape fits too',
       air.over <= 0 && air.appW / air.vw > 0.9, `${air.appW}/${air.vw}, ${air.over}px over`);

    /* THE CHECK ABOVE MEASURES WHICHEVER PEARL WAS DRAWN, and the pearl is one
       of a few hundred picked at random. A tall one opened the grid's 1fr row
       and pushed this exact screen 9px past the viewport — on 1 launch in 4 on
       the owner's laptop, so 3 runs in 4 of the check above never met the
       case it exists for. It passed a full green run that way. That is a
       check passing without measuring, and the fix for it is not to run it
       more often: it is to stop depending on the draw.

       So the tall case is manufactured. The drawn pearl's text is repeated
       until it is far taller than any in the library, and the screen must
       still fit — the pearl scrolls inside its own card (homewide-patch,
       .pearl-card contain:size) rather than growing the row. The height floor
       is the precondition: without it, a pearl that failed to get taller
       would pass this by being short, which is the check above's problem
       again. Measure the content's scrollHeight: the reading area is now
       constrained so its topic and actions remain visible. Its viewport
       height is deliberately fixed even when the content gets longer.

       REPEATED UNTIL, not a fixed count. It was `.repeat(8)`, and a pearl
       can be as short as 90 characters (src/core/pearl.js MIN): eight of
       those at this width is ~300px, under the floor. So the precondition
       itself failed on a short draw — on the owner's run with 727 older
       questions merged, which change no pearl — and the check read red for
       the dice again, the other way round. Doubling until past 600px, up to
       256 copies, takes the draw out of it. The precondition and the claim
       are two checks now, so a red one says which. */
    const tall = await page.evaluate(() => {
      const pb = document.getElementById('pearlBody');
      if (!pb) return null;
      const one = pb.textContent.trim() + ' ';
      let n = 8;
      do { pb.textContent = one.repeat(n); n *= 2; }
      while (pb.scrollHeight <= 600 && n <= 256);
      return { over: document.documentElement.scrollHeight - innerHeight,
               h: pb.scrollHeight, copies: n / 2 };
    });
    ok('a pearl made far taller than any in the library (precondition)',
       !!tall && tall.h > 600, tall ? `${tall.h}px from ${tall.copies} copies` : 'no pearl on screen');
    ok('and a pearl far taller than any in the library still does not push it',
       !!tall && tall.h > 600 && tall.over <= 0,
       tall ? `${tall.over}px over, with a ${tall.h}px pearl` : 'no pearl on screen');

    /* PORTRAIT MUST NOT MOVE. It already fitted, and a second layout for it
       would be change for its own sake. */
    const port = await at(1024, 1366);
    ok('portrait still stacks, and still fits',
       port.over <= 0 && port.pearl.x < port.hero.x + 40, `pearl x${port.pearl.x}`);
    /* The pages run the full width now, and Home's column is the fixed measure (.home-page-in, 900px). */
    ok('and its column reserves space for the navigation rail',
       !!port.col && port.col.w === port.vw - 128, port.col ? `${port.col.w}px` : 'no column');

    /* THE ONE THAT WOULD QUIETLY RUIN THE APP. The reading measure exists so a
       vignette is readable; widening the home screen must not widen a stem.
       The stem's column is the reader's own width setting (Wide by default),
       never Home's full width. */
    await resized(page, 1366, 1024);
    const quiz = await page.evaluate(() => {
      const q = ALL_Q.find(x => !x.bad);
      jumpTo(q.id); render();
      const app = document.getElementById('app');
      const w = () => Math.round(app.getBoundingClientRect().width);
      const wide = w();
      setReadWidth(1); const medium = w(); setReadWidth(2);
      return { wide, medium, screen: app.dataset.screen };
    });
    ok('a question stem keeps the Wide reading measure on the same wide screen, not Home\'s width',
       quiz.screen === 'quiz' && quiz.wide <= 1200, `${quiz.wide}px on ${quiz.screen}`);
    ok('and the Medium setting gives it the narrower measure',
       quiz.screen === 'quiz' && quiz.medium <= 980, `${quiz.medium}px on ${quiz.screen}`);
    await page.evaluate(() => { goHome(); render(); });
  }

  head('the first-run hint appears for a newcomer and for nobody else');
  /* Three gates, and each is tested on its own rather than trusting the one
     that is easiest to set. The flag alone would have been the obvious
     implementation and the wrong one: it would hand a "New here?" card to
     every existing reader the first time they loaded a build containing this
     step — exactly the audience it is not for — so the empty-scheduler and
     empty-log gates are the ones actually worth proving. */
  {
    const r = await page.evaluate(async () => {
      const fresh = () => { try { localStorage.removeItem('accsap12.welcomed'); } catch (_) {} };
      const shown = () => !!document.getElementById('homeHello');

      fresh(); S.srs = {}; if (typeof LOG !== 'undefined') LOG.length = 0;
      goHome(); render();
      const forNewcomer = shown();

      // gate 2: a reader with scheduled cards is not new, flag unset or not
      fresh(); S.srs = { X: { difficulty: 5, stability: 10, ivl: 5, reps: 1, lapses: 0, last: '2026-08-20', due: '2026-09-01' } };
      goHome(); render();
      const withHistory = shown();

      // gate 3: a reader with a review log is not new either
      fresh(); S.srs = {};
      let loggedShown = null;
      if (typeof LOG !== 'undefined') { LOG.length = 0; LOG.push({ id: 'X', r: 3, t: Date.now() }); goHome(); render(); loggedShown = shown(); LOG.length = 0; }

      // gate 1: the dismissal flag
      S.srs = {};
      try { localStorage.setItem('accsap12.welcomed', '1'); } catch (_) {}
      goHome(); render();
      const afterFlag = shown();

      // and dismissing it really does persist across a re-render
      fresh(); goHome(); render();
      const beforeTap = shown();
      dismissHello();
      await new Promise(res => setTimeout(res, 340));
      const goneAfterTap = !shown();
      goHome(); render();
      const stillGone = !shown();
      let flagWritten = null;
      try { flagWritten = localStorage.getItem('accsap12.welcomed'); } catch (_) {}

      fresh(); S.srs = {}; goHome(); render();
      return { forNewcomer, withHistory, loggedShown, afterFlag, beforeTap, goneAfterTap, stillGone, flagWritten };
    });
    ok('a genuine newcomer is shown it', r.forNewcomer === true);
    ok('someone with cards already scheduled never sees it', r.withHistory === false);
    ok('nor does someone with a review log, even on a clean flag',
       r.loggedShown === false || r.loggedShown === null, String(r.loggedShown));
    ok('and it stays away once the flag is set', r.afterFlag === false);
    ok('tapping Got it removes it', r.beforeTap === true && r.goneAfterTap === true,
       `shown ${r.beforeTap} → gone ${r.goneAfterTap}`);
    ok('and it does not come back on the next render', r.stillGone === true);
    ok('because the dismissal was actually written down', r.flagWritten === '1', String(r.flagWritten));
  }

  head('the dismiss button is never buried under the Apex button');
  /* Found by screenshotting the card rather than by reading its CSS. Apex's
     button is position:fixed in the bottom-right corner, so it floats over
     whatever is scrolled beneath it — and the first version of this card put
     "Got it" at its own right-hand edge, which on an iPad in portrait put the
     FAB exactly on top of it: elementFromPoint at the button's centre came
     back as aiFab, so the control whose only job is dismissing the card could
     not be pressed.

     WHAT THIS ASSERTS, AND WHY IT IS NOT THE OBVIOUS THING. The first version
     of this check compared the button's rectangle against the FAB's and
     demanded they not intersect — and it PASSED against the broken
     right-aligned layout, because whether those two rectangles happen to meet
     depends on how tall the page is and where it is scrolled, neither of
     which the suite controls. A guard that only fires when the page happens
     to be the right height is not a guard. So this checks the property that
     actually makes the collision impossible instead: the button keeps more
     clearance from its card's right edge than the FAB is wide, so no amount
     of scrolling can put the FAB over it. That is scroll-independent,
     content-independent, and fails on the original layout. */
  {
    const prev = page.viewportSize();
    const rows = [];
    for (const [w, h, label] of [[390, 844, 'phone'], [834, 1112, 'iPad portrait'], [1194, 834, 'iPad landscape']]) {
      await resized(page, w, h);
      const r = await page.evaluate(async () => {
        try { localStorage.removeItem('accsap12.welcomed'); } catch (_) {}
        S.srs = {}; if (typeof LOG !== 'undefined') LOG.length = 0;
        goHome(); render();
        await new Promise(res => setTimeout(res, 280));
        const card = document.getElementById('homeHello');
        const btn = card && card.querySelector('.hello-x');
        const fab = document.getElementById('aiFab');
        if (!btn) return { err: 'hint missing' };
        const c = card.getBoundingClientRect(), a = btn.getBoundingClientRect();
        const fabW = fab && getComputedStyle(fab).display !== 'none' ? fab.getBoundingClientRect().width : 0;
        return { clearance: Math.round(c.right - a.right), fabW: Math.round(fabW) };
      });
      rows.push({ label, ...r });
    }
    if (prev) await resized(page, prev.width, prev.height);
    for (const r of rows) {
      ok(`${r.label}: "Got it" keeps more room from the card's right edge than the Apex button is wide`,
         !r.err && r.clearance > r.fabW, r.err || `${r.clearance}px clear vs a ${r.fabW}px button`);
    }
  }

  head('on a phone, the Apex button stands beside the tab bar, never over the pages');
  /* Lifted above the bar, the button stood over the page's first lines on arrival, and with some pearls over the
     pearl's key statement. Which words it covered depended on the pearl and on the scroll, so the same reasoning as
     the check above applies: assert the property that makes covering impossible, not that today's page happened to be
     clear. The pages scroll inside #homePager; a button whose box never meets the pager's box covers none of them. */
  {
    const prev = page.viewportSize();
    const rows = [];
    for (const [w, h] of [[390, 844], [375, 667], [320, 568]]) {
      await resized(page, w, h);
      await page.evaluate(() => { goHome(); render(); });
      await settled(page, () => { const f = document.getElementById('aiFab'), p = document.getElementById('homePager');
        /* Still means no finite animation left: the button's glow runs for ever and is not a move. */
        const moving = !!f && f.getAnimations().some(a => a.playState === 'running' && a.effect && a.effect.getComputedTiming().iterations !== Infinity);
        return S.screen === 'home' && !!f && !!p && !moving && p.getBoundingClientRect().height > 0; },
        { label: 'Home drawn with the Apex button still' });
      rows.push(await page.evaluate(() => {
        const r = e => e.getBoundingClientRect(), f = r(document.getElementById('aiFab')), p = r(document.getElementById('homePager'));
        const meet = (a, b) => a.right > b.left && a.left < b.right && a.bottom > b.top && a.top < b.bottom;
        const bar = r(document.querySelector('.home-tabs')), tabs = [...document.querySelectorAll('.home-tab')].map(r);
        return { vw: innerWidth, vh: innerHeight, shown: getComputedStyle(document.getElementById('aiFab')).display !== 'none',
          overPages: meet(f, p), onTab: tabs.some(t => meet(f, t)), inView: f.left >= 0 && f.right <= innerWidth && f.bottom <= innerHeight,
          rowShared: f.top < bar.bottom && f.bottom > bar.top, size: [Math.round(f.width), Math.round(f.height)],
          tabW: Math.round(Math.min(...tabs.map(t => t.width))), name: document.getElementById('aiFab').getAttribute('aria-label') };
      }));
    }
    if (prev) await resized(page, prev.width, prev.height);
    for (const g of rows) {
      const at = `${g.vw}x${g.vh}`;
      ok(`${at}: the Apex button is shown and its box never meets the pages'`, g.shown && !g.overPages, JSON.stringify(g));
      ok(`${at}: it stands in the tab bar's row, clear of every tab, on screen`, g.rowShared && !g.onTab && g.inView, JSON.stringify(g));
      ok(`${at}: it stays a touch target with a name, and the tabs keep theirs`,
         g.size[0] >= 44 && g.size[1] >= 44 && /Apex/.test(g.name || '') && g.tabW >= 44, JSON.stringify(g));
    }
  }

  head('and the hint itself is readable, on every theme');
  /* The AA floor, applied to the new card rather than assumed of it — this is
     the component most likely to be
     written in whatever colour looked nice. */
  {
    const rows = await page.evaluate(async () => {
      const lin = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
      const lum = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
      const ratio = (a, b) => { const la = lum(a), lb = lum(b); return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05); };
      const parse = s => { const m = String(s).match(/rgba?\(([^)]+)\)/); if (!m) return null;
        const p = m[1].split(/[,\s/]+/).filter(Boolean).map(Number);
        return { rgb: [p[0], p[1], p[2]], a: p.length > 3 ? p[3] : 1 }; };
      const over = (fg, bg) => fg.rgb.map((c, i) => Math.round(c * fg.a + bg[i] * (1 - fg.a)));
      const stack = el => { let a = 1, n = el;
        while (n && n !== document.documentElement) { a *= parseFloat(getComputedStyle(n).opacity || '1'); n = n.parentElement; } return a; };
      const out = [];
      for (const t of THEMES) {
        try { localStorage.removeItem('accsap12.welcomed'); } catch (_) {}
        S.theme = t.id; applyTheme(); S.srs = {}; goHome(); render();
        let card = null;
        for (let i = 0; i < 60; i++) {
          card = document.getElementById('homeHello');
          if (card && stack(card) > 0.999) break;
          await new Promise(res => requestAnimationFrame(res));
        }
        if (!card) { out.push({ theme: t.id, error: 'hint not rendered' }); continue; }
        const pageRaw = parse(getComputedStyle(document.body).backgroundColor);
        const pageBg = pageRaw && pageRaw.a === 1 ? pageRaw.rgb : [255, 255, 255];
        const cardRaw = parse(getComputedStyle(card).backgroundColor);
        const cardBg = cardRaw ? over(cardRaw, pageBg) : pageBg;
        let worst = Infinity;
        for (const el of card.querySelectorAll('b,i,button')) {
          const c = parse(getComputedStyle(el).color);
          if (!c) continue;
          worst = Math.min(worst, ratio(over({ rgb: c.rgb, a: c.a * stack(el) }, cardBg), cardBg));
        }
        out.push({ theme: t.id, worst: +worst.toFixed(2) });
      }
      S.theme = 'auto'; applyTheme();
      try { localStorage.setItem('accsap12.welcomed', '1'); } catch (_) {}
      goHome(); render();
      return out;
    });
    for (const r of rows) {
      ok(`${r.theme}: every word in the hint clears AA`, !r.error && r.worst >= 4.5, r.error || `${r.worst}:1`);
    }
  }

  ok('no console or page errors across the run', errors.length === 0, errors.slice(0, 3).join(' | '));

  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
