#!/usr/bin/env node
/*
 * Behavioural checks for the polish pass: Pencil feel, the hero heart, the
 * rotating rhythm strip, and the expanded arrhythmia library.
 *
 *   NODE_PATH=$(npm root -g) node tests/verify-polish.js /path/to/patched.html
 */
'use strict';
const path = require('path');
const { launch, isEngineNoise } = require('./_engine');
const { onDeath, watch } = require('./_deathnote.js');
const { booted, settled, watchTransitions } = require('./_render.js');

const target = process.argv[2];
if (!target) { console.error('usage: node tests/verify-polish.js <patched.html>'); process.exit(1); }
/* Accepts a path (single-file build) or an http URL (the Stage 1 PWA
   build, which has to be served because it fetches its content). */
const URL = /^https?:\/\//.test(target) ? target : 'file://' + path.resolve(target);

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

(async () => {
  const browser = await launch();
  const errors = [], events = [];
  onDeath(() => ({ section, checks: passed + failed, errors,
                   events: events.length ? events.join(', ') : 'none' }));
  const page = watch(await browser.newPage({ viewport: { width: 900, height: 1000 } }), events, 'main');
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !isEngineNoise(m.text())) errors.push(m.text()); });
  await watchTransitions(page);

  await page.goto(URL, { waitUntil: 'load', timeout: 200000 });
  /* The Stage 1 build injects app.js only after its content fetch resolves,
     so 'load' no longer implies the app has booted. Wait for it explicitly —
     a no-op on the single-file build, where this is already true. */
  await booted(page);
  await page.waitForTimeout(1000);

  head('rhythm library: the new arrhythmias are real, everywhere the old 12 were');
  const registry = await page.evaluate(() => ({
    total: RHYTHM_KEYS.length,
    hasNew: ['avb1', 'mobitz1', 'mobitz2', 'wpw', 'lbbb', 'rbbb', 'hyperk', 'longqt',
             'pericarditis', 'svt', 'bigeminy', 'pac', 'junctional', 'idioventricular',
             'sinus_arrhythmia'].every(k => k in RHYTHMS),
    labChipCount: (() => { goLab(); render(); return document.querySelectorAll('.lab-chips .chip').length; })(),
  }));
  ok('registry grew from 12 to 27 rhythms', registry.total === 27, registry.total);
  ok('all 15 new arrhythmias are in RHYTHMS', registry.hasNew);
  ok('Rhythm Lab chip list reflects all 27', registry.labChipCount === 27, registry.labChipCount);

  const waveforms = await page.evaluate(() => {
    const out = {};
    for (const k of ['avb1', 'wpw', 'lbbb', 'hyperk', 'pericarditis', 'svt']) {
      let min = 1e9, max = -1e9, nan = 0;
      const st = {};
      for (let t = 0; t < 8000; t += 5) {
        const v = rhythmMV(k, t, st);
        if (Number.isNaN(v)) { nan++; continue; }
        if (v < min) min = v; if (v > max) max = v;
      }
      out[k] = { range: max - min, nan };
    }
    return out;
  });
  for (const k in waveforms) {
    ok(`${k} produces a real, finite waveform through the app's own dispatcher`,
       waveforms[k].nan === 0 && waveforms[k].range > 0.05, JSON.stringify(waveforms[k]));
  }

  head('hero: rotates through a non-repeating playlist, mini heart syncs');
  const heroState = await page.evaluate(() => {
    goHome(); render();
    return {
      hasLabel: !!document.getElementById('heroRhythmLabel'),
      labelText: document.getElementById('heroRhythmLabel')?.textContent || '',
      /* The hero's 3D canvas is gone — heroart-patch.js replaced it with the
         photograph. What this suite still owns is the rotation; that the
         picture is mounted and beats is tests/verify-heroart.js's ground and
         is deliberately not restated here. */
      hasPlate: !!document.querySelector('#heroHeart.hero-heart-plate'),
      firstKind: heroCurrentKind,
      inRegistry: heroCurrentKind in RHYTHMS,
    };
  });
  ok('rhythm label is present and populated', heroState.hasLabel && heroState.labelText.trim().length > 0,
     heroState.labelText);
  ok('the hero art is mounted for the rotation to drive', heroState.hasPlate);
  /* This line used to read `ok('first rhythm is a real playlist entry', HeroList => true)`
     — an arrow function, which is truthy, so the check passed unconditionally
     and its own comment deferred the real work to a check further down that
     never covered the FIRST rhythm. Made into the assertion it claimed. */
  ok('the first rhythm is a real registry entry', heroState.inRegistry, heroState.firstKind)

  const rotation = await page.evaluate(async () => {
    const seen = [heroCurrentKind];
    for (let i = 0; i < 4; i++) {
      heroCurrentKind = HeroRhythm.nextInPlaylist(heroCurrentKind);
      heroMon.setRhythm(heroCurrentKind);
      setHeroBeatRate(heroCurrentKind);
      paintHeroLabel(heroCurrentKind);
      seen.push(heroCurrentKind);
    }
    const noBackToBack = seen.every((k, i) => i === 0 || k !== seen[i - 1]);
    const allInRegistry = seen.every(k => k in RHYTHMS);
    const excludesAlarming = !seen.includes('vfib') && !seen.includes('asystole') &&
      HeroRhythm.HERO_PLAYLIST.every(k => k !== 'vfib' && k !== 'asystole');
    return { seen, noBackToBack, allInRegistry, excludesAlarming,
             labelAfter: document.getElementById('heroRhythmLabel').textContent,
             beatMs: document.querySelector('#heroHeart .h-beat')?.style.animationDuration };
  });
  ok('rotation never repeats the immediately preceding rhythm', rotation.noBackToBack, rotation.seen.join(' → '));
  ok('every rotated-to rhythm is a real registry entry', rotation.allInRegistry);
  ok('vfib/asystole excluded from ambient rotation', rotation.excludesAlarming);
  ok('label updates on rotation', rotation.labelAfter.trim().length > 0, rotation.labelAfter);
  ok('the picture\'s beat duration is set from the rhythm\'s actual rate', /ms$/.test(rotation.beatMs || ''),
     rotation.beatMs);

  /* SIX HERO-3D LIFECYCLE CHECKS USED TO SIT HERE, AND ARE GONE. They asserted
     that one live Heart3D instance survived a rapid re-render, that it was
     bound to the current canvas node rather than a detached one, that it was
     destroyed on leaving home and re-mounted on returning. heroart-patch.js
     replaced the hero canvas with an <img>: there is no instance to keep, to
     bind, to destroy, or to re-mount, and every one of those checks now
     references an identifier that does not exist.

     What survives the swap is the rotation above and the picture's beat, and
     both are asserted — here for the playlist, and in verify-heroart.js for the
     beat's coupling to it. The re-render race those checks defended cannot
     recur: an <img> in the markup is rebuilt with the markup. */

  head('pencil: width responds to pressure, tilt, and size — verified against the real paint path');
  const widths = await page.evaluate(() => ({
    baseline: PencilFX.widthFor(2.6, 0.5, 0, 'M'),
    reproducesOldFormula: Math.abs(PencilFX.widthFor(2.6, 0.5, 0, 'M') - 2.6 * (0.45 + 0.5 * 1.25)) < 1e-9,
    small: PencilFX.widthFor(2.6, 0.5, 0, 'S'),
    large: PencilFX.widthFor(2.6, 0.5, 0, 'L'),
    flatTilt: PencilFX.widthFor(2.6, 0.2, 1, 'M'),
    uprightTilt: PencilFX.widthFor(2.6, 0.2, 0, 'M'),
  }));
  ok('Medium at mid-pressure/no-tilt reproduces the pre-existing fixed width exactly',
     widths.reproducesOldFormula, widths.baseline.toFixed(4));
  ok('Small < Medium < Large at the same pressure', widths.small < widths.baseline && widths.baseline < widths.large,
     `${widths.small.toFixed(2)} < ${widths.baseline.toFixed(2)} < ${widths.large.toFixed(2)}`);
  ok('a flatter tilt broadens the stroke beyond pressure alone', widths.flatTilt > widths.uprightTilt,
     `${widths.uprightTilt.toFixed(2)} → ${widths.flatTilt.toFixed(2)}`);

  head('pencil: an old stroke (no sz, no tilt) renders exactly as before, through the real ink layer');
  const legacyStroke = await page.evaluate(() => {
    S.resume = {}; startQuiz('Arrhythmias');
    const q = S.questions[0];
    const key = q.id + ':q';
    INK[key] = [{ t: 'pen', c: '#EF4444', p: [[0.1, 0.1, 0.6], [0.3, 0.3, 0.8], [0.5, 0.2, 0.4]] }];
    // no .sz field at all — simulating a stroke saved before this patch
    saveJSON(INK_KEY, INK);
    render();
    return new Promise(res => setTimeout(() => {
      const canvas = document.querySelector('.q-card .ink-canvas');
      res({ hasCanvas: !!canvas, noThrow: true });
    }, 400));
  });
  ok('a pre-existing stroke with no size/tilt fields still renders without error',
     legacyStroke.hasCanvas && legacyStroke.noThrow);

  head('pencil: size picker in the real rail UI');
  const sizePicker = await page.evaluate(() => {
    S.resume = {}; startQuiz('Arrhythmias');
    render();
    railMin(false);
    const dots = [...document.querySelectorAll('.size-dot')].map(d => d.dataset.sz);
    document.querySelector('[data-sz="L"]').click();
    const afterClick = T.sizeKey;
    const persisted = localStorage.getItem('accsap12.inksize');
    return { dots, afterClick, persisted };
  });
  ok('three size options are shown, in order', sizePicker.dots.join(',') === 'S,M,L', sizePicker.dots.join(','));
  ok('clicking a size updates T.sizeKey', sizePicker.afterClick === 'L');
  ok('size choice is persisted', sizePicker.persisted === 'L');

  head('pencil: a stroke drawn right now actually carries the current size');
  /* Real input, not a hand-dispatched PointerEvent: page.mouse goes through
     Chromium's actual input pipeline, so setPointerCapture() sees a genuine
     active pointer (a synthetic dispatchEvent does not, and throws — that
     is a limitation of simulating input, not a bug in the app's existing
     capture call). Scrolling into view matters too: the ink canvas sits
     below the fold at this viewport size, and page.mouse coordinates are
     absolute, unlike locator.click()'s auto-scroll. */
  /* T.active alone isn't enough — the canvas only accepts pointer events once
     its host carries .ink-on (pointer-events:auto), which syncInkMode() sets
     from T.active. Every real path that flips T.active (tool buttons, color
     swatches) calls syncInkMode() itself; poking T directly here has to do
     the same or the click passes straight through with no error at all. */
  await page.evaluate(() => { T.tool = 'pen'; T.active = true; T.erase = false; T.sizeKey = 'L'; syncInkMode(); });
  await page.waitForTimeout(300);
  /* PRECONDITION: no screen transition still in flight. synthetic-webkit
     once died here with "Element is not attached to the DOM": a view
     transition started earlier (home to quiz) committed its renderNow()
     while the canvas below was being scrolled to, and the card it belonged
     to was replaced. Waiting on the live transition's `finished` is the
     same precondition resized() uses; it asserts nothing. */
  await page.evaluate(() => (window.__vtLive && window.__vtLive.finished
    ? window.__vtLive.finished.catch(() => {}) : null));
  const inkCanvas = page.locator('.q-card .ink-canvas');
  await inkCanvas.scrollIntoViewIfNeeded();
  const inkBox = await inkCanvas.boundingBox();
  await page.mouse.move(inkBox.x + 10, inkBox.y + 10);
  await page.mouse.down();
  await page.mouse.move(inkBox.x + 50, inkBox.y + 50, { steps: 5 });
  await page.mouse.up();
  await page.waitForTimeout(200);
  const strokeCarriesSize = await page.evaluate(() => {
    const q = currentQ(), key = q.id + ':q';
    const last = (INK[key] || [])[INK[key].length - 1];
    return { sz: last && last.sz, pointCount: last && last.p.length };
  });
  ok('the freshly drawn stroke is tagged with the active size', strokeCarriesSize.sz === 'L',
     JSON.stringify(strokeCarriesSize));

  head('pencil: auto-minimize toggle and the Pencil-triggered expand+draw');
  const autoMin = await page.evaluate(() => {
    document.querySelector('[data-a="automin"]').click();
    return { onAfterFirstClick: T.autoMin, persisted: localStorage.getItem('accsap12.autominimize') };
  });
  ok('toggle flips T.autoMin', autoMin.onAfterFirstClick === true);
  ok('auto-minimize preference persists', autoMin.persisted === '1');

  /* These three checks dispatch synthetic PointerEvents directly (rather than
     page.mouse, which goes through Chromium's real input pipeline) because
     they need pointerType:'pen' specifically, which page.mouse cannot
     produce. A synthetic dispatch has no genuine active-pointer session, so
     the app's pre-existing cv.setPointerCapture(e.pointerId) call throws —
     that requires real hardware-originated input and is a limitation of
     simulating a Pencil touch, not app behavior (the state changes under
     test — T.min, T.active, autoMinTimer — all happen in the handler BEFORE
     that call, so the throw doesn't affect what's being asserted). Stubbed
     to a no-op for just these checks so the throw doesn't pollute the
     error log the final regression check reads.
     Real Pencil-driven size tagging is verified above, through page.mouse. */
  const armed = await page.evaluate(() => {
    const origCapture = Element.prototype.setPointerCapture;
    Element.prototype.setPointerCapture = function(){};
    T.tool = 'pen'; T.active = true;
    const cv = document.querySelector('.q-card .ink-canvas');
    const rect = cv.getBoundingClientRect();
    cv.dispatchEvent(new PointerEvent('pointerdown', { clientX: rect.left + 5, clientY: rect.top + 5, pointerType: 'mouse', bubbles: true }));
    cv.dispatchEvent(new PointerEvent('pointerup', { clientX: rect.left + 5, clientY: rect.top + 5, pointerType: 'mouse', bubbles: true }));
    Element.prototype.setPointerCapture = origCapture;
    return !!autoMinTimer;
  });
  ok('finishing a pointer sequence with auto-minimize on arms a countdown', armed);

  const expandOnPencil = await page.evaluate(() => {
    const origCapture = Element.prototype.setPointerCapture;
    Element.prototype.setPointerCapture = function(){};
    railMin(true);           // simulate the countdown having fired
    const before = T.min;
    const cv = document.querySelector('.q-card .ink-canvas');
    const rect = cv.getBoundingClientRect();
    cv.dispatchEvent(new PointerEvent('pointerdown', { clientX: rect.left + 20, clientY: rect.top + 20,
      pointerType: 'pen', pressure: 0.5, bubbles: true }));
    const result = { before, after: T.min, active: T.active };
    Element.prototype.setPointerCapture = origCapture;
    return result;
  });
  ok('rail was minimized before the Pencil touch', expandOnPencil.before === true);
  ok('a Pencil touch (pointerType=pen) with auto-minimize on re-expands the rail', expandOnPencil.after === false,
     JSON.stringify(expandOnPencil));
  ok('and starts drawing in the same touch, not a second one', expandOnPencil.active === true);

  const autoOffNoExpand = await page.evaluate(() => {
    const origCapture = Element.prototype.setPointerCapture;
    Element.prototype.setPointerCapture = function(){};
    T.autoMin = false;
    railMin(true);
    const cv = document.querySelector('.q-card .ink-canvas');
    const rect = cv.getBoundingClientRect();
    cv.dispatchEvent(new PointerEvent('pointerdown', { clientX: rect.left + 20, clientY: rect.top + 20,
      pointerType: 'pen', pressure: 0.5, bubbles: true }));
    const result = T.min;
    Element.prototype.setPointerCapture = origCapture;
    return result;
  });
  ok('with auto-minimize OFF, a Pencil touch does not force-expand the rail', autoOffNoExpand === true);

  head('the heart module is embedded whole');
  /* This has followed the heart around twice. It used to open the lab, switch
     to cutaway and check the blood particles drew; when the lab lost its
     heart it moved to the hero's instance; when the hero briefly became a
     still photograph there was no mounting screen left at all, so it moved
     onto a canvas this test creates itself.

     The hero mounts the module again now, in the specimen style — but the
     evidence stays on this test's own canvas deliberately. What is held here
     is heart3d.js embedded in one piece, and that claim should not depend on
     which screen happens to use it this month.
     tests/verify-heroart.js owns the hero. */
  const heartModule = await page.evaluate(() => {
    goHome(); render();
    return new Promise(res => setTimeout(() => res({
      moduleLoaded: typeof Heart3D !== 'undefined' && typeof Heart3D.create === 'function',
      cycleFn: typeof Heart3D !== 'undefined' && typeof Heart3D.cycle === 'function',
      heroCanvas: !!document.getElementById('heroECG'),
      /* THE MESH IS BUILT ON A CANVAS THIS TEST OWNS. It used to read
         heroHeart3d.stats.triangles off the hero's live instance — but the
         hero is a photograph now and no screen mounts Heart3D at all, so the
         only way left to prove the module arrived whole rather than merely
         parseable is to drive it. Which also states the situation plainly:
         after heroart-patch.js this 79 KB renderer has no callers in the app.
         It is still embedded on purpose (see that step's header); this is what
         keeps it from rotting silently while that decision is outstanding. */
      tris: (() => {
        try {
          const cv = document.createElement('canvas');
          cv.width = cv.height = 128;
          const h = Heart3D.create(cv, { rhythm: 'sinus', mode: 'whole', resolution: [24, 32, 20] });
          if (!h) return -1;                      // no WebGL2 in this environment
          const n = h.stats ? h.stats.triangles : 0;
          h.destroy();
          return n;
        } catch (_) { return -2; }
      })(),
      noLabHeart: !document.getElementById('labHeartCanvas'),
    }), 900));
  });
  ok('Heart3D module is loaded and exposes create()', heartModule.moduleLoaded);
  ok('and the cardiac clock the rest of the app reads', heartModule.cycleFn);
  ok('its mesh still builds triangles — the module came through whole',
     heartModule.tris > 5000, `${heartModule.tris} triangles`);
  ok('and no heart is left in the Rhythm Lab', heartModule.noLabHeart);
  ok('no errors from mounting it', errors.length === 0, JSON.stringify(errors.slice(0, 2)));

  head('the 3D heart and physio.js agree on where systole begins');
  /* heart3d.js's cycle() carries its own literal 0.10 offset to align its
     clock with physio.js's convention — a comment there says the two "cannot
     disagree" because both call the instant ventricular contraction starts
     mitral closure. But that offset and physio.js's T.mc are two separately
     typed numbers that happen to agree today, not one shared constant — the
     exact shape of drift this codebase has been bitten by before (a chain
     array and its own doc comment, once). This is what actually holds the
     comment's claim to account, rather than trusting two files to stay in
     sync by memory. */
  const align = await page.evaluate(() => {
    const PR = 160;   // sinus PR interval, exactly as cycle() itself uses
    const c = Heart3D.cycle(PR, 'sinus', {});
    return { cyc: c.cyc, mc: Physio.T.mc };
  });
  ok('heart3d\'s cycle at ventricular-contraction onset lands on physio.js\'s own mitral-closure constant',
     Math.abs(align.cyc - align.mc) < 1e-9, `heart3d ${align.cyc} vs physio ${align.mc}`);

  head('a felt pulse alongside the correct/wrong feedback');
  {
    const right = await page.evaluate(() => {
      window.__vibes = [];
      navigator.vibrate = p => { window.__vibes.push(p); return true; };
      goHome(); render();
      S.resume = {}; startQuiz('Arrhythmias');
      const q = S.questions[0];
      selectOpt(q.ci);
      return window.__vibes.slice();
    });
    ok('answering correctly fires a single pulse',
       right.length === 1 && typeof right[0] === 'number' && right[0] > 0, JSON.stringify(right));

    const wrong = await page.evaluate(() => {
      window.__vibes = [];
      navigator.vibrate = p => { window.__vibes.push(p); return true; };
      goHome(); render();
      S.resume = {}; startQuiz('Arrhythmias');
      const q = S.questions[0];
      selectOpt((q.ci + 1) % q.o.length);
      return window.__vibes.slice();
    });
    ok('answering wrong fires a three-beat pattern',
       wrong.length === 1 && Array.isArray(wrong[0]) && wrong[0].length === 3, JSON.stringify(wrong));
  }

  head('haptics respect reduced motion and missing-API feature detection');
  {
    const reducedPage = watch(await browser.newPage({ viewport: { width: 900, height: 1000 } }), events, 'reduced-motion');
    await reducedPage.emulateMedia({ reducedMotion: 'reduce' });
    await reducedPage.goto(URL, { waitUntil: 'load', timeout: 200000 });
    await booted(reducedPage);
    const underReduced = await reducedPage.evaluate(() => {
      window.__vibes = [];
      navigator.vibrate = p => { window.__vibes.push(p); return true; };
      S.resume = {}; startQuiz('Arrhythmias');
      selectOpt(S.questions[0].ci);
      return window.__vibes.length;
    });
    ok('no vibration is requested under prefers-reduced-motion', underReduced === 0, String(underReduced));
    await reducedPage.close();

    const noVibratePage = watch(await browser.newPage({ viewport: { width: 900, height: 1000 } }), events, 'no-vibrate');
    await noVibratePage.addInitScript(() => {
      Object.defineProperty(window.navigator, 'vibrate', { value: undefined, configurable: true });
    });
    await noVibratePage.goto(URL, { waitUntil: 'load', timeout: 200000 });
    await booted(noVibratePage);
    const noThrow = await noVibratePage.evaluate(() => {
      try { S.resume = {}; startQuiz('Arrhythmias'); selectOpt(S.questions[0].ci); return 'ok'; }
      catch (e) { return 'threw: ' + e.message; }
    });
    ok('answering never throws where the Vibration API does not exist — iOS Safari\'s real case',
       noThrow === 'ok', noThrow);
    await noVibratePage.close();
  }

  head('the app says what it is, in a structure a screen reader can navigate');
  {
    await page.evaluate(()=>{homePage=0;goHome();});
    await settled(page,()=>S.screen==='home'&&!!document.getElementById('homePage0')&&!window.__vtLive,{label:'Home semantics'});
    const doc = await page.evaluate(() => {
      const h1s = [...document.querySelectorAll('h1')].filter(h=>!h.closest('[inert],[hidden]')&&h.getClientRects().length);
      const mains = document.querySelectorAll('main');
      const hero = document.getElementById('pearlConcept')||document.getElementById('atlasTitle');

      const cs = hero ? getComputedStyle(hero) : null;
      const heroWeight = cs ? cs.fontWeight : null;
      const heroMarginTop = cs ? cs.marginTop : null;
      // Screen-reader heading text excludes the CSS capitalization of innerText.
      const h1Text=h1s.length?h1s[0].textContent.replace(/\s+/g,' ').trim():null;
      return {
        h1Count: h1s.length,
        h1Text,
        h1IsHero: !!hero && hero.tagName === 'H1',
        expectedTitle: pearlCurrent?(pearlCurrent.concept||pearlCurrent.title):'Make one idea stick.',

        mainCount: mains.length,
        mainIsApp: mains.length ? mains[0].id : null,
        heroWeight, heroMarginTop,
      };
    });
    await page.evaluate(()=>goStats());
    await settled(page,()=>S.screen==='stats'&&!window.__vtLive&&!!document.querySelector('.app-disclaim'),{label:'Progress disclaimer'});
    Object.assign(doc,await page.evaluate(()=>{
      const hd=document.querySelector('.app-disclaim');
      return {
        disclaimText: hd ? hd.textContent.replace(/\s+/g, ' ').trim() : null,
        disclaimColor: hd ? getComputedStyle(hd).color : null,
        muted: getComputedStyle(document.documentElement).getPropertyValue('--muted').trim(),
        dim: getComputedStyle(document.documentElement).getPropertyValue('--dim').trim(),
      };
    }));
    const hex = h => {
      const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(h.replace('#', '#'));
      return m ? `rgb(${parseInt(m[1], 16)}, ${parseInt(m[2], 16)}, ${parseInt(m[3], 16)})` : h;
    };

    ok('the active page exposes exactly one visible <h1>', doc.h1Count === 1, String(doc.h1Count));
    ok('and it names the visible pearl or empty-library invitation',
       doc.h1IsHero && doc.h1Text === doc.expectedTitle, JSON.stringify({ isHero: doc.h1IsHero, actual: doc.h1Text, expected: doc.expectedTitle }));

    ok('the page has exactly one <main> landmark', doc.mainCount === 1, String(doc.mainCount));
    ok('and it is the app region itself', doc.mainIsApp === 'app', String(doc.mainIsApp));
    /* The tag swap must not be a visual change: a bare <h1> would inherit the
       user agent's bold and .67em top margin. */
    ok('the pearl heading uses its intended serif weight and spacing',
       doc.heroWeight === '400' && doc.heroMarginTop === '0px',

       JSON.stringify({ weight: doc.heroWeight, marginTop: doc.heroMarginTop }));

    ok('the Progress screen carries a disclaimer', !!doc.disclaimText && /education|board preparation/i.test(doc.disclaimText),
       (doc.disclaimText || '').slice(0, 70));
    ok('and it says it is not clinical decision support',
       !!doc.disclaimText && /not a clinical|not clinical|not a substitute/i.test(doc.disclaimText));
    ok('and it is painted in the legible --muted tier, never --dim',
       doc.disclaimColor === hex(doc.muted) && doc.disclaimColor !== hex(doc.dim),
       `${doc.disclaimColor} (muted ${hex(doc.muted)}, dim ${hex(doc.dim)})`);
  }

  head('the Apex panel carries its own disclaimer, in BOTH of its states');
  {
    /* buildAI() early-returns to a setup screen when no key is configured, so
       the two states render entirely different markup. The disclaimer has to
       survive both — the un-set-up state is the first thing anyone sees. */
    const setup = await page.evaluate(() => {
      AI[AI.provider].key = '';
      if (typeof toggleAI === 'function' && !document.getElementById('shell').classList.contains('ai-open')) toggleAI();
      buildAI();
      const d = document.querySelector('.ai-disclaim');
      return {
        onSetupScreen: !!document.querySelector('.setup, [class*="setup"]'),
        text: d ? d.textContent.replace(/\s+/g, ' ').trim() : null,
        color: d ? getComputedStyle(d).color : null,
        muted: getComputedStyle(document.documentElement).getPropertyValue('--muted').trim(),
      };
    });
    ok('before a key is entered, the setup screen still carries it',
       !!setup.text && /not clinical advice/i.test(setup.text), (setup.text || 'ABSENT').slice(0, 60));

    const connected = await page.evaluate(() => {
      AI[AI.provider].key = 'test-key-not-real';
      buildAI();
      const d = document.querySelector('.ai-disclaim');
      const out = {
        text: d ? d.textContent.replace(/\s+/g, ' ').trim() : null,
        beforeModelLine: !!(d && d.nextElementSibling && d.nextElementSibling.classList.contains('ai-powered')),
        color: d ? getComputedStyle(d).color : null,
      };
      AI[AI.provider].key = '';
      return out;
    });
    ok('once connected, it states that it is not clinical advice',
       !!connected.text && /not clinical advice/i.test(connected.text), (connected.text || 'ABSENT').slice(0, 60));
    ok('and that it can be wrong', !!connected.text && /can be wrong|check anything/i.test(connected.text));
    ok('and it sits directly above the model line, where the answers end',
       connected.beforeModelLine, String(connected.beforeModelLine));
    ok('both placements say the same thing, so they cannot drift apart',
       setup.text === connected.text, `setup ${(setup.text || '').length} chars, connected ${(connected.text || '').length}`);
  }


  /* ── the quiz announces itself ──────────────────────────────────────────
     From the fifth external audit, which was right about this: a screen
     reader was being told the answer. aria-pressed carried `i===q.ci` — the
     answer key — so on a wrong answer VoiceOver announced the CORRECT option
     as pressed and the user's own choice as not. It gave the answer away and
     misreported what the user did, in one attribute. */
  head('a11y: aria-pressed reports what the user chose, not what was correct');
  const pressed = await page.evaluate(() => {
    goHome(); render();
    S.resume = {}; startQuiz(CHAPTERS[0], 'all');
    const q = S.questions[S.qIdx];
    const wrongIdx = (q.ci + 1) % q.o.length;
    selectOpt(wrongIdx);
    const opts = [...document.querySelectorAll('.opt')];
    return {
      ci: q.ci, chose: wrongIdx,
      onChosen: opts[wrongIdx] ? opts[wrongIdx].getAttribute('aria-pressed') : null,
      onCorrect: opts[q.ci] ? opts[q.ci].getAttribute('aria-pressed') : null,
      trueCount: opts.filter(o => o.getAttribute('aria-pressed') === 'true').length,
    };
  });
  ok('the option the user actually chose is aria-pressed="true"',
     pressed.onChosen === 'true', JSON.stringify(pressed));
  ok('the correct-but-unchosen option is NOT aria-pressed',
     pressed.onCorrect === 'false', JSON.stringify(pressed));
  ok('exactly one option is pressed', pressed.trueCount === 1, String(pressed.trueCount));

  head('a11y: the result is announced, not just painted');
  /* The region must exist BEFORE the text lands — a live region injected
     already-populated is not announced by any screen reader. So it is checked
     in both states, empty first. */
  const live = await page.evaluate(() => {
    goHome(); render();
    S.resume = {}; startQuiz(CHAPTERS[0], 'all');
    const before = document.querySelector('[aria-live]');
    const beforeText = before ? before.textContent.trim() : null;
    const q = S.questions[S.qIdx];
    selectOpt(q.ci);
    const after = document.querySelector('[aria-live]');
    return {
      existedBefore: !!before, beforeText,
      politeness: after ? after.getAttribute('aria-live') : null,
      afterText: after ? after.textContent.trim() : null,
    };
  });
  ok('a live region is already in the DOM before the answer', live.existedBefore, JSON.stringify(live));
  ok('and it is empty until there is something to say', live.beforeText === '', JSON.stringify(live.beforeText));
  ok('it is polite, not assertive', live.politeness === 'polite', String(live.politeness));
  ok('after answering it states the verdict', /correct/i.test(live.afterText || ''), live.afterText);

  head('a11y: focus follows the reading order through the quiz');
  const focus = await page.evaluate(() => {
    goHome(); render();
    S.resume = {}; startQuiz(CHAPTERS[0], 'all');
    const q = S.questions[S.qIdx];
    selectOpt(q.ci);
    const afterAnswer = document.activeElement ? document.activeElement.className : null;
    nextQ();
    const afterNext = document.activeElement ? document.activeElement.className : null;
    return { afterAnswer, afterNext };
  });
  ok('answering moves focus to the reveal', /reveal-header/.test(focus.afterAnswer || ''), focus.afterAnswer);
  ok('moving on moves focus to the new question', /q-card/.test(focus.afterNext || ''), focus.afterNext);

  head('keyboard: Previous has a key, the way Next has two');
  const keys = await page.evaluate(async () => {
    goHome(); render();
    S.resume = {}; startQuiz(CHAPTERS[0], 'all');
    nextQ(); nextQ();
    const start = S.qIdx;
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true }));
    const afterLeft = S.qIdx;
    /* The guard that keeps typing in Apex from driving the quiz must still
       hold for the new key — guards-patch.js added SELECT for exactly this. */
    const sel = document.createElement('select');
    document.body.appendChild(sel); sel.focus();
    sel.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true }));
    const afterGuarded = S.qIdx;
    sel.remove();
    return { start, afterLeft, afterGuarded };
  });
  ok('ArrowLeft steps back a question', keys.afterLeft === keys.start - 1, JSON.stringify(keys));
  ok('but not while a <select> has focus', keys.afterGuarded === keys.afterLeft, JSON.stringify(keys));

  head('contrast: the last --dim on read text is gone');
  /* contrastfix-patch.js moved 46 sites off --dim (2.56:1, fails AA at every
     theme). This one escaped the sweep: the peer-response percentage on every
     option that is neither correct nor selected — a number the learner reads
     to compare against their own choice. */
  const pct = await page.evaluate(() => {
    goHome(); render();
    S.resume = {}; startQuiz(CHAPTERS[0], 'all');
    const q = S.questions[S.qIdx];
    const chose = (q.ci + 1) % q.o.length;
    selectOpt(chose);
    const opts = [...document.querySelectorAll('.opt')];
    const otherIdx = opts.findIndex((_, i) => i !== q.ci && i !== chose);
    const el = otherIdx > -1 ? opts[otherIdx].querySelector('.opt-pct') : null;
    const cs = getComputedStyle(document.documentElement);
    return {
      color: el ? el.style.color : null,
      dim: cs.getPropertyValue('--dim').trim(),
      muted: cs.getPropertyValue('--muted').trim(),
    };
  });
  ok('an unselected option\'s percentage is not painted with --dim',
     !/--dim/.test(pct.color || ''), JSON.stringify(pct));
  ok('it uses the legible --muted tier instead',
     /--muted/.test(pct.color || ''), JSON.stringify(pct));


  head('touch: the double-tap trap is scoped, not global');
  /* Three consecutive audits flagged a document-wide touchend that
     preventDefaults any second tap — it suppressed iOS double-tap zoom on
     figures too, the gesture a fellow reaches for on an ECG.

     Its own page, with hasTouch, for two reasons this test learned the hard
     way: without touch support Chromium does not deliver synthetic
     TouchEvents to the listener at all (so the check passes whether the fix
     is there or not), and the handler needs now-lastTap to be BOTH <350 and
     >0, so two dispatches in the same millisecond never trigger it. */
  {
    const touchPage = watch(await browser.newPage({ viewport: { width: 900, height: 1000 }, hasTouch: true }), events, 'touch');
    await touchPage.goto(URL, { waitUntil: 'load', timeout: 250000 });
    await booted(touchPage, { timeout: 150000 });
    const onPlainSurface = await touchPage.evaluate(async () => {
      const wait = ms => new Promise(r => setTimeout(r, ms));
      /* WATCH THE CALL, NOT THE FLAG. This read `second.defaultPrevented`,
         which is only true if the browser HONOURS preventDefault() on a
         synthetic TouchEvent — and the two checks below cannot tell that apart
         from the app not suppressing: the first expects false and passes
         either way, the second expects true. A check that cannot separate
         "the app did not suppress" from "this browser will not let us see it"
         is measuring the harness.

         I GUESSED WHICH IT WAS AND GUESSED WRONG. The commit that made this
         change said WebKit "appears not to" honour cancelable. It does:
         measured on the served build, cancelable came back TRUE and `asked`
         came back FALSE. So the browser was willing and the app never asked,
         which is the opposite of what I wrote. The new reading is still the
         right one — it separates the two — but it did not find what I said it
         would.

         Wrapping the instance's own preventDefault records whether the APP
         called it, which is the app's side of the contract and is the same on
         every engine. cancelable and defaultPrevented are reported alongside
         so the browser's half is visible rather than assumed. */
      /* RE-RESOLVED BETWEEN TAPS, because the first tap changes the DOM.
         Measured: connected came back FALSE for the option — selecting it
         re-renders the card, the original row leaves the document, and an
         event dispatched at a node that is no longer in the tree never
         reaches the document-level listener the app installs. The handler was
         not failing to suppress; it was never being asked, because the test
         was tapping a node that no longer existed.

         Taking a getter rather than an element is what makes the second tap
         land on whatever is on screen NOW, which is what a finger does. */
      const doubleTap = async (get) => {
        const at = () => (typeof get === 'function' ? get() : get);
        const mk = () => new TouchEvent('touchend', { bubbles: true, cancelable: true });
        const first = at();
        if (!first) return { asked: false, honoured: false, cancelable: null, connected: null, missing: true };
        const t1 = Date.now();
        first.dispatchEvent(mk());
        await wait(60);
        const el = at() || first;
        /* The app suppresses a second tap within 350 ms of the first, by Date.now(). A busy
           page can hold this 60 ms wait past that; the gap goes in the detail so the reader
           can tell a stretched wait from a handler that did not ask. */
        const gap = Date.now() - t1;
        const second = mk();
        let asked = false;
        const orig = second.preventDefault;
        second.preventDefault = function () { asked = true; try { return orig.call(this); } catch (_) {} };
        /* CONNECTED, BECAUSE A DETACHED NODE HAS NO PATH TO THE DOCUMENT. The
           app's handler is a single document-level touchend listener. An event
           dispatched on a node that is no longer in the tree does not bubble
           to the document at all, so the handler never runs — which is
           indistinguishable, from `asked` alone, from a handler that ran and
           returned early. The first tap can cause a render that replaces the
           option row, and then the second tap is fired at a corpse.

           Reported rather than worked around: if this comes back false, the
           check is measuring a stale reference and the fix is to re-resolve
           the element between taps, not to change what the app does. */
        const connected = el.isConnected;
        el.dispatchEvent(second);
        return { asked, honoured: second.defaultPrevented,
                 cancelable: second.cancelable, connected, gap };
      };
      goHome(); render();
      const loose = document.createElement('div');
      document.body.appendChild(loose);
      /* A plain div nothing re-renders, so the element itself is stable. */
      const r = await doubleTap(loose);
      loose.remove();
      /* Kept for the second half below, which runs after a wait this
         evaluate cannot make. */
      window.__doubleTap = doubleTap;
      return r;
    });

    /* render() runs inside a view transition on a screen change, so the quiz
       DOM is not there synchronously. This was sixty 50 ms polls inside the
       page; on the real build they take about 9 s, measured, not the 3 s
       they read as. Late in one full run the option had not arrived by then,
       foundOption came back false, and the check below went red without
       saying whether the quiz was slow or the handler was wrong. Why that
       render was so late was not established. The option row is a
       precondition of that check and not what it asserts (it asserts that
       preventDefault was called), so it takes settled(): its standard
       timeout, and a failure that names the wait. */
    await touchPage.evaluate(() => { S.resume = {}; startQuiz(CHAPTERS[0], 'all'); });
    await settled(touchPage, () => !!document.querySelector('.opt'), { label: 'the first quiz option, for the double tap' });
    const touch = await touchPage.evaluate(async (onPlainSurface) => {
      const optEl = document.querySelector('.opt');
      /* By selector, so the second tap finds the row the re-render left.
         A DOUBLE TAP IS A PRECONDITION HERE, NOT THE CLAIM. On CI's WebKit the
         page was still busy after the quiz drew, and the 60 ms wait between
         the taps stretched to 685 and 694 ms in two runs: past the app's 350 ms
         window, so no double tap was made and the check went red without
         measuring the handler. So the pair is retried until one lands inside
         the window, a pause between attempts so each starts afresh; the
         assertion reads only that attempt. If none ever lands, `inWindow` is
         false and the check fails saying so, rather than passing. */
      let onOption = null; const gaps = [];
      for (let i = 0; optEl && i < 6; i++) {
        if (i) await new Promise(r => setTimeout(r, 400));
        onOption = await window.__doubleTap(() => document.querySelector('.opt'));
        gaps.push(onOption.gap);
        if (onOption.gap < 350) break;
      }
      return { onPlainSurface, onOption, foundOption: !!optEl, gaps, inWindow: !!onOption && onOption.gap < 350 };
    }, onPlainSurface);
    await touchPage.close();
    ok('a rapid double tap on a plain surface is no longer swallowed',
       touch.onPlainSurface.asked === false, JSON.stringify(touch.onPlainSurface));
    /* "asks to suppress", not "is suppressed": whether the browser acts on it
       is the browser's half, and a synthetic event cannot answer for a real
       finger. The app's half is exactly this call, and it is what the scoping
       in curate-patch changed. */
    ok('but the app still asks to suppress it on a quiz option, where it misfires',
       touch.foundOption === true && touch.inWindow === true && touch.onOption && touch.onOption.asked === true,
       JSON.stringify(touch));
  }

  head('perf: the hero rotation stops while the page is hidden');
  const vis = await page.evaluate(() => {
    goHome(); render();
    const running = heroRotateTimer !== null;
    document.dispatchEvent(new Event('visibilitychange'));
    return { running, afterEvent: heroRotateTimer };
  });
  ok('the rotation timer is running on the home screen', vis.running, JSON.stringify(vis));
  await page.evaluate(() => Object.defineProperty(document, 'visibilityState',
    { configurable: true, get: () => 'hidden' }));
  const hidden = await page.evaluate(() => {
    document.dispatchEvent(new Event('visibilitychange'));
    return heroRotateTimer;
  });
  ok('hiding the page clears it', hidden === null, String(hidden));
  const shown = await page.evaluate(() => {
    Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'visible' });
    document.dispatchEvent(new Event('visibilitychange'));
    return heroRotateTimer !== null;
  });
  ok('returning to a visible home screen restarts it', shown === true, String(shown));

  head('a11y: the question card says which question it is');
  const named = await page.evaluate(async () => {
    const wait = ms => new Promise(r => setTimeout(r, ms));
    goHome(); render();
    /* render() goes through a view transition on a screen change, so the quiz
       DOM is not present synchronously — reading it straight away returns the
       home screen and the check passes or fails for the wrong reason. */
    S.resume = {}; startQuiz(CHAPTERS[0], 'all');
    for (let i = 0; i < 60 && !document.querySelector('.q-card'); i++) await wait(50);
    const card = document.querySelector('.q-card');
    const id = card ? card.getAttribute('aria-labelledby') : null;
    const label = id ? document.getElementById(id) : null;
    return { id, text: label ? label.textContent.trim() : null };
  });
  ok('.q-card is labelled by an element that exists', !!named.text, JSON.stringify(named));
  ok('and that label names the question', /Question\s*\d+/.test(named.text || ''), named.text);

  head('regression: everything prior still functions');
  const reg = await page.evaluate(() => {
    goHome(); render();
    const home = !!document.querySelector('.hero-h1');
    S.resume = {}; startQuiz('Arrhythmias');
    const q = S.questions[0];
    selectOpt(q.ci);
    goLab(); render();
    return { home, answered: S.answered, labMounted: typeof physio !== 'undefined' };
  });
  ok('home renders', reg.home);
  ok('quiz still answers', reg.answered);
  ok('the lab still mounts its diagram', reg.labMounted);
  ok('no console/page errors across the whole run', errors.length === 0, errors.slice(0, 4).join(' | '));

  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
