#!/usr/bin/env node
/*
 * Layout invariants, on every screen, at every frame a real device produces.
 *
 *   NODE_PATH=$(npm root -g) node tests/verify-layout.js <patched.html>
 *
 * WHY THIS EXISTS. Every bug that has reached the fellow was a layout bug, and
 * before this suite exactly three of forty-six files asserted that anything
 * fits anything: verify-home, verify-chat, and verify-figzoom — one screen, one
 * panel, one viewer. The quiz screen, the notes, the stats, the Rhythm Lab and
 * the search had no such check at all, and the figure viewer's own bug lived
 * for a day in the gap between a portrait test viewport and a landscape iPad.
 *
 * So this is deliberately one suite rather than a check bolted onto forty: the
 * invariants are the same everywhere, and a screen added later should be caught
 * by adding one line to SCREENS rather than by remembering to write assertions.
 *
 * WHAT IT ASSERTS, AND WHY NOT MORE. Two candidate invariants were measured
 * first and thrown away, because a check that cries wolf gets ignored:
 *
 *   "no element extends past the viewport" fires on .fc-glow, which is inset
 *   -50% -20% on purpose, pointer-events:none, and clipped by its parent;
 *
 *   "scrollHeight must not exceed clientHeight" fires on .hero and .hero-live,
 *   whose ::before and .hero-ecg layers bleed by design. scrollHeight counts
 *   absolutely-positioned decoration, so it is simply the wrong instrument.
 *
 * What survived is precise: a MEDIA element clipped by an ancestor that cannot
 * scroll is content the fellow cannot reach by any gesture, which is exactly
 * the shape of the figure-viewer bug. Everything else here is cheap and
 * unambiguous.
 */
'use strict';
const path = require('path');
const { launch, isEngineNoise, routablePage } = require('./_engine');
const { booted, watchTransitions, resized } = require('./_render.js');
const { onDeath } = require('./_deathnote.js');

const target = process.argv[2];
if (!target) { console.error('usage: node tests/verify-layout.js <patched.html>'); process.exit(1); }
const URL = /^https?:\/\//.test(target) ? target : 'file://' + path.resolve(target);

let passed = 0, failed = 0;
const ok = (label, cond, detail = '') => {
  cond ? passed++ : failed++;
  console.log((cond ? '  PASS  ' : '  FAIL  ') + label + (detail ? '  → ' + detail : ''));
};
let section = '';
const head = t => { section = t; console.log('\n── ' + t + ' ──'); };

/* The frames that exist in the fellow's hands, plus a desktop for the split
   build. Landscape first: it is where the figure viewer broke and the only
   orientation no other suite here exercises. */
const FRAMES = [
  ['iPad 11" landscape', 1194, 834],
  ['iPad 11" portrait', 834, 1194],
  ['iPad 12.9" landscape', 1366, 1024],
  ['iPhone portrait', 390, 844],
  ['desktop', 1440, 900],
];
const SCREENS = ['home', 'stats', 'lab', 'refs', 'memory', 'study', 'search', 'quiz', 'quizflag', 'annotations', 'echo', 'mock', 'mockreport'];

/* Enough of a reply to overflow any panel, so "does it scroll" is a real
   question rather than one the fixture answers for us. */
const sse = text => [
  'data: ' + JSON.stringify({ candidates: [{ content: { role: 'model', parts: [{ text: text }] } }] }),
  'data: [DONE]', '',
].join('\n\n');

(async () => {
  const browser = await launch();
  const page = await routablePage(browser, { viewport: { width: 1194, height: 834 } });
  await watchTransitions(page);   /* before goto: see _render.js */
  await page.route('**/generativelanguage.googleapis.com/**', route => route.fulfill({
    status: 200, headers: { 'content-type': 'text/event-stream' },
    body: sse('Long answer. '.repeat(80)),
  }));
  const errors = [];
  const events = [];
  page.on('crash', () => events.push('the browser CRASHED the page'));
  page.on('close', () => events.push('the page closed'));
  page.on('requestfailed', r => {
    const why = (r.failure() || {}).errorText || '';
    if (why) events.push(`request failed: ${String(r.url()).slice(-50)} — ${why}`);
  });
  /* A crash and a close are different diagnoses; Playwright reports both
     as "Target page, context or browser has been closed" on the next call. */
  onDeath(() => ({ section, checks: passed + failed, errors,
                   events: events.length ? events.join(', ') : 'none' }));
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !isEngineNoise(m.text())) errors.push(m.text()); });

  await page.goto(URL, { waitUntil: 'load', timeout: 250000 });
  await booted(page, { timeout: 150000 });

  /* WAIT FOR THE BOX TO STOP MOVING, NOT FOR A CLOCK. #ai transitions its
     flex-basis over .28s, so a measurement taken on a fixed timer catches the
     panel mid-open on a loaded machine — this suite reported the panel as 1px
     wide and its input off-screen on one full run and passed the next, which
     is not a bug in the app and not a flake to shrug at either. Polling until
     two consecutive frames agree removes the timing from the question. */
  await page.addInitScript(() => {
    window.__settle = async (sel, tries) => {
      let last = -1;
      for (let i = 0; i < (tries || 60); i++) {
        await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
        const el = document.querySelector(sel);
        const w = el ? Math.round(el.getBoundingClientRect().width) : -1;
        if (w === last && w > 0) return w;
        last = w;
      }
      return last;
    };
  });
  await page.reload({ waitUntil: 'load', timeout: 250000 });
  await booted(page, { timeout: 150000 });

  /* One pass per frame, aggregated: a line per invariant naming every screen
     that broke it, rather than forty near-identical PASS lines to scroll past. */
  const sweep = screens => page.evaluate(async screens => {
    const wait = ms => new Promise(r => setTimeout(r, ms));
    const go = {
      home: () => goHome(), stats: () => goStats(), lab: () => goLab(), refs: () => goRefs(),
      memory: () => goMemory(), study: () => goStudy(), search: () => openSearch(),
      quiz: () => (S.resume = {}, startQuiz)(CHAPTERS[0], 'all'),
      /* The quiz with its question flagged (the badge beside the stem, the button pressed), and the list of what has been
         written on: a note long enough to wrap, one with only pencil, and a flagged and a missed question among them. */
      quizflag: () => { (S.resume = {}, startQuiz)(CHAPTERS[0], 'all'); S.flagged.add(S.questions[0].id); render(); },
      annotations: () => {
        NOTES = {}; INK = {};
        NOTES[POOL[0].id] = [{ id: 'n1', x: .1, y: .1, text: 'A long note about the first question that goes on for more than one line so that a row has to wrap it, with a long-unbroken-token-' + 'x'.repeat(60), color: '' }];
        INK[POOL[1].id + ':q'] = [{ t: 'pen', c: '#EF4444', p: [[.1, .1, .5], [.4, .4, .5]], sz: 'M' }];
        S.flagged = new Set([POOL[0].id]); S.missed = new Set([POOL[1].id]);
        goAnnotations();
      },
      /* Echo Studio. Its two tabs share one screen and the calculator is the
         wider of them, but the sweep opens what goEcho() opens, which is the
         reference tab — so this covers the tab the fellow lands on, not both.
         Narrower than "the echo screen fits", and said here rather than
         implied by the screen's name appearing in the list. */
      echo: () => goEcho(),
      /* The mock exam: a block open (the clock stopped, so the sweep is not counting seconds against it), and the
         report of a block handed in. The report is built from a finished record rather than by handing one in,
         so five frames do not each add a block to the history and a score to the progress. */
      mock: () => { mockStopTicker(); S.mock = MockExam.start({ ids: POOL.slice(0, 12).map(q => q.id), secPerQ: 60, now: Date.now() }); S.mockView = 'q'; S.screen = 'mock'; render(); mockStopTicker(); },
      mockreport: () => { S.mock = null; S.mockLast = MockExam.finish(MockExam.start({ ids: POOL.slice(0, 12).map(q => q.id), secPerQ: 60, now: Date.now() }), Date.now() + 1000, false); S.screen = 'mockreport'; render(); },
    };
    /* WHAT overflowed, not just by how much. "refs +9px" names a number and
       nothing else, and the only way to turn it into a cause was to open the
       build by hand and go looking — which is exactly what a suite is for.
       This runs only when the page has already failed, so a green run never
       reaches it.

       IT IS A LEAD, NOT A VERDICT, and it carries its own number so the
       reader can tell which. When the bracketed figure matches the screen's
       (`refs +9px [... +9px]`) the named element is the thing overflowing.
       When it is smaller, something this deliberately ignores — decoration,
       or a box clipped by an ancestor — is contributing to scrollWidth too,
       and that mismatch is worth knowing rather than worth hiding.

       Deepest wins a tie, because a parent is only as wide as the content
       forcing it. The chain skips ancestors with neither id nor class: a bare
       walk up three parents is often `tbody > tr > td`, which identifies
       nothing, while the name worth having is usually a class further up. */
    function widestOverflow() {
      const doc = document.documentElement;
      const w = doc.clientWidth;
      let worst = null, worstBy = 0, worstDepth = -1;
      for (const el of document.querySelectorAll('body *')) {
        const cs = getComputedStyle(el);
        if (cs.display === 'none' || cs.visibility === 'hidden') continue;
        /* Decoration is not the culprit. This suite's own header names
           .fc-glow — inset -50% -20% on purpose, pointer-events:none, clipped
           by its parent — as the reason a naive overflow check was thrown
           away. Naming it here would resurrect that wolf-crying in the one
           message somebody reads while already debugging. */
        if (cs.pointerEvents === 'none') continue;
        const r = el.getBoundingClientRect();
        if (r.width < 1 || r.height < 1) continue;
        /* RIGHT EDGE ONLY. The symptom is scrollWidth, which a left-hand
           overhang does not grow, and the offLeft check below owns that case.
           A first draft took max(right - w, -left) and would have named a
           30px left-hand overhang as the cause of a 9px sideways scroll. */
        const by = Math.round(r.right - w);
        if (by < 2) continue;
        /* Nor is a box an ancestor clips. A table header inside its own
           scrolling frame reaches 251px past the edge and grows nothing; named
           here, it hid the real 25px (the owner's run, refs on an iPhone). A
           clipping ancestor that itself ends on screen contains it. */
        let clipped = false;
        for (let a = el.parentElement; a && a !== document.body; a = a.parentElement) {
          if (getComputedStyle(a).overflowX !== 'visible' && a.getBoundingClientRect().right <= w + 1) { clipped = true; break; }
        }
        if (clipped) continue;
        let depth = 0; for (let n = el.parentElement; n; n = n.parentElement) depth++;
        if (by > worstBy || (by === worstBy && depth > worstDepth)) {
          worst = el; worstBy = by; worstDepth = depth;
        }
      }
      if (!worst) return '';
      const name = e => e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') +
        (e.className && typeof e.className === 'string' && e.className.trim()
          ? '.' + e.className.trim().split(/\s+/)[0] : '');
      const chain = [name(worst)];
      for (let n = worst.parentElement; n && n !== document.body && chain.length < 4; n = n.parentElement) {
        if (n.id || (n.className && typeof n.className === 'string' && n.className.trim())) chain.push(name(n));
      }
      return ' [' + chain.reverse().join(' > ') + ' +' + worstBy + 'px]';
    }

    const sideways = [], clipped = [], offLeft = [];
    let media = 0;
    for (const s of screens) {
      try { go[s](); } catch (e) { sideways.push(s + ' (threw: ' + e.message.slice(0, 30) + ')'); continue; }
      /* WAIT FOR THE COUNT TO HOLD STILL, NOT FOR 380 ms. A fixed wait is a
         guess about the machine you are not running on: on a real GPU the
         canvases on lab and stats paint later than they do on this container's
         software renderer, and the sweep counted the screen before they
         existed — 18 media elements on a desktop where all of them render.
         This file already had __settle for exactly this reason and the sweep
         was the one place not using it. Finite animations only: looping
         decorations never finish. Bounded, so a screen that never settles
         still fails rather than hangs. */
      {
        const visible = m => {
          const cs = getComputedStyle(m);
          if (cs.pointerEvents === 'none' || cs.display === 'none' || cs.visibility === 'hidden') return false;
          const r = m.getBoundingClientRect();
          return r.width >= 8 && r.height >= 8;
        };
        let last = -1, held = 0;
        for (let i = 0; i < 90 && held < 3; i++) {
          await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
          const busy = document.getAnimations().some(a => a.playState === 'running'
            && Number.isFinite(a.effect && a.effect.getTiming().iterations));
          const n = [...document.querySelectorAll('#app img, #app canvas')].filter(visible).length;
          held = (n === last && !busy) ? held + 1 : 0;
          last = n;
        }
      }

      const d = document.documentElement;
      const over = Math.round(d.scrollWidth - d.clientWidth);
      if (over > 1) sideways.push(s + ' +' + over + 'px' + widestOverflow());

      for (const m of document.querySelectorAll('#app img, #app canvas')) {
        const cs = getComputedStyle(m);
        if (cs.pointerEvents === 'none' || cs.display === 'none' || cs.visibility === 'hidden') continue;
        const mr = m.getBoundingClientRect();
        if (mr.width < 8 || mr.height < 8) continue;
        media++;
        /* The nearest ancestor that CLIPS. A scrolling ancestor is fine — the
           content is still reachable — so the walk stops at one. */
        let n = m.parentElement, clip = null;
        while (n && n !== document.documentElement) {
          const c = getComputedStyle(n);
          if (c.overflowY === 'hidden' || c.overflowY === 'clip' || c.overflowX === 'hidden' || c.overflowX === 'clip') { clip = n; break; }
          if (c.overflowY === 'auto' || c.overflowY === 'scroll' || c.overflowX === 'auto' || c.overflowX === 'scroll') break;
          n = n.parentElement;
        }
        if (!clip) continue;
        const cr = clip.getBoundingClientRect();
        const esc = Math.max(0, cr.top - mr.top, mr.bottom - cr.bottom, cr.left - mr.left, mr.right - cr.right);
        if (esc > 2) clipped.push(s + ': ' + m.tagName.toLowerCase() + ' escapes .' +
          String(clip.className || clip.tagName).split(' ')[0] + ' by ' + Math.round(esc) + 'px');
      }

      /* Content starting left of the viewport cannot be scrolled back to on a
         page that only scrolls down. */
      for (const el of document.querySelectorAll('#app > *, #app > * > *')) {
        const cs = getComputedStyle(el);
        if (cs.position === 'fixed' || cs.display === 'none' || cs.visibility === 'hidden') continue;
        const r = el.getBoundingClientRect();
        if (r.width < 8 || r.height < 8) continue;
        if (r.left < -2) offLeft.push(s + ': ' + String(el.className || el.tagName).split(' ')[0] + ' at x=' + Math.round(r.left));
      }
    }
    return { sideways, clipped, offLeft, media };
  }, screens);

  let totalMedia = 0; const perFrame = [], perFrameN = [];
  for (const [name, w, h] of FRAMES) {
    await resized(page, w, h);
    await page.waitForTimeout(240);
    head(`${name} — ${w}x${h}`);
    const r = await sweep(SCREENS);
    totalMedia += r.media;
    perFrame.push(`${name.split(' ')[0]} ${r.media}`); perFrameN.push(r.media);
    ok('no screen scrolls sideways', r.sideways.length === 0,
       r.sideways.join('; ') || `${SCREENS.length} screens clean`);
    ok('no figure is clipped by something that cannot scroll', r.clipped.length === 0,
       r.clipped.slice(0, 2).join('; ') || `${r.media} media elements checked`);
    ok('nothing sits off the left edge', r.offLeft.length === 0,
       r.offLeft.slice(0, 2).join('; ') || 'all content starts on screen');
  }
  /* THE 20 THIS ASKED FOR WAS A COIN FLIP, not a measurement. The sweep opens
     the quiz with startQuiz(CHAPTERS[0], 'all'), and startQuiz shuffles: which
     question is shown varies per run, and so does whether it carries a figure.
     One element per frame, five frames — the total swings by up to five. Three
     consecutive runs here gave 18, 20 and 22. A floor at 20 therefore passed or
     failed on the shuffle, and the desktop report that started this was not a
     machine difference at all; it was a run that landed low.
     (The settle above is a separate, real fix: a flat 380 ms was sampling two
     of the frames mid transition. It is worth having on its own, and it is not
     what made this check unstable.)
     So the vacuity claim the check's own name makes is now asserted directly —
     no frame found nothing — with a total floor set below the shuffle's range
     rather than inside it. Per-frame is the sharper guard anyway: a total can
     look respectable while one viewport renders nothing at all.
     The per-frame numbers travel with the total, because when this failed it
     took a round trip to learn which frames were short — the runner prints
     only failures, and the breakdown lived in a passing check. */
  ok('the sweep actually looked at media, rather than finding none to check',
     totalMedia >= 15 && perFrameN.every(n => n > 0),
     `${totalMedia} media elements across ${FRAMES.length} frames — ${perFrame.join(', ')}`);

  head('the overlays, which sit above every screen');
  {
    await resized(page, 1194, 834);
    await page.waitForTimeout(240);
    /* The figure viewer with a REAL figure: the exact case that shipped
       broken, held here at the exact frame it shipped broken in. */
    const fig = await page.evaluate(async () => {
      const wait = ms => new Promise(r => setTimeout(r, ms));
      goHome(); await wait(200);
      let url = null;
      try { for (const id in IMGS) { const l = IMGS[id]; if (l && l.length && typeof l[0] === 'string') { url = l[0]; break; } } } catch (_) {}
      if (!url) return null;
      closePeek();
      const ps = await openFigure(url, 'Layout check', 'Bank');
      if (!ps || !ps.currSlide) return null;
      /* At rest: after the opening animation, which grows the figure out of
         nothing, and once the picture has loaded. */
      await new Promise(r => { if (ps.opener && ps.opener.isOpen) return r(); ps.on('openingAnimationEnd', r); setTimeout(r, 4000); });
      const img = ps.currSlide.content.element;
      if (img && img.tagName === 'IMG' && !(img.complete && img.naturalWidth)) {
        await new Promise(r => { let d = 0; const f = () => { if (!d++) r(); };
          img.addEventListener('load', f, { once: true }); setTimeout(f, 4000); });
      }
      await wait(80);
      let out = null;
      if (img && img.naturalWidth) {
        const i = img.getBoundingClientRect(), b = ps.element.getBoundingClientRect();
        out = { over: Math.max(0, b.left - i.left, i.right - b.right, b.top - i.top, i.bottom - b.bottom),
                nat: img.naturalWidth + 'x' + img.naturalHeight };
      }
      closePeek();
      return out;
    });
    ok('a real figure fits the viewer at Fit', !!fig && fig.over <= 1,
       fig ? `${fig.nat}, overflow ${Math.round(fig.over)}px` : 'no figure to open');

    /* The Apex panel takes width from the app beside it; if it can push the
       document sideways the whole layout is wrong at that width. */
    const apex = await page.evaluate(async () => {
      const wait = ms => new Promise(r => setTimeout(r, ms));
      /* A provider has to be configured or the panel renders its setup screen,
         which has no textarea — the first version of this check asserted the
         input was on screen in a state where the input does not exist. No key
         is used: nothing here sends a request. */
      AI.provider = 'gemini';
      AI.gemini = { key: 'layout-check', model: 'gemini-2.5-flash' };
      const sh = document.getElementById('shell');
      if (!sh.classList.contains('ai-open')) toggleAI();
      buildAI();
      await window.__settle('#ai');
      await wait(80);
      const d = document.documentElement;
      const panel = document.getElementById('ai');
      const input = document.getElementById('aiIn');
      const ir = input ? input.getBoundingClientRect() : null;
      const pr = panel ? panel.getBoundingClientRect() : null;
      const out = {
        sideways: Math.round(d.scrollWidth - d.clientWidth),
        panelOnScreen: !!pr && pr.left >= -2 && pr.right <= innerWidth + 2 && pr.width > 100,
        panel: pr ? Math.round(pr.left) + '→' + Math.round(pr.right) + ' of ' + innerWidth : 'no panel',
        hasInput: !!input,
        inputOnScreen: !!ir && ir.left >= -2 && ir.right <= innerWidth + 2 && ir.width > 40,
        input: ir ? Math.round(ir.left) + '→' + Math.round(ir.right) : 'none',
      };
      if (sh.classList.contains('ai-open')) toggleAI();
      await wait(200);
      return out;
    });
    ok('the Apex panel does not push the page sideways', apex.sideways <= 1, `+${apex.sideways}px`);
    ok('the panel itself sits inside the viewport', apex.panelOnScreen === true, apex.panel);
    ok('the question box is rendered once a provider is set', apex.hasInput === true);
    ok('and it stays on screen', apex.inputOnScreen === true, apex.input);
  }

  head('the Apex answer keeps room, with the figures open, at every frame');
  {
    /* REPORTED FROM AN IPAD, WITH A PHOTOGRAPH: the figures "cover the
       explanation". Chain step 68 made the strip foldable but left the answer
       with no floor, so opening it took .ai-body to 43px on an iPad held
       portrait — one line. This suite did not catch it because it only ever
       looked at the panel as a side rail at desktop width, where the crush is
       mild, and never with the figures open. Both were the fixture being
       kinder than the device, for the third time this week. */
    const FLOOR = 100;
    const rows = [];
    for (const [name, w, h] of FRAMES) {
      await resized(page, w, h);
      await page.waitForTimeout(240);
      const r = await page.evaluate(async () => {
        const wait = ms => new Promise(r => setTimeout(r, ms));
        AI.provider = 'gemini';
        AI.gemini = { key: 'layout-check', model: 'gemini-2.5-flash' };
        const note = REF.find(x => /refimg:\/\//.test(x.body || ''));
        const sh = document.getElementById('shell');
        if (!sh.classList.contains('ai-open')) toggleAI();
        buildAI();
        await window.__settle('#ai');
        fire('explain this'); await wait(1700);
        lastHits = note ? [{ kind: 'r', id: note.id, title: note.title }] : [];
        lastHitsKey = '_general';
        buildAI(); await window.__settle('#ai'); await wait(120);
        /* Only if it is not already open. apexFigsOpen is module-level and
           survives the panel's re-render — deliberately, so a fellow who opens
           the figures keeps them open — which means a blind click on the
           second frame CLOSES them. That alternated true/false/true across the
           sweep and made the floor numbers a mixture of both states. */
        const t = document.getElementById('aiFigs');
        if (t && !document.querySelector('.fig-strip.open')) t.click();
        await wait(400);
        const body = document.querySelector('.ai-body');
        const input = document.getElementById('aiIn');
        const ir = input ? input.getBoundingClientRect() : null;
        if (!body) return null;
        body.scrollTop = 99999; await wait(60);
        const out = {
          open: !!document.querySelector('.fig-strip.open'),
          bodyH: body.clientHeight,
          scrolls: body.scrollHeight - body.clientHeight > 0 ? body.scrollTop > 0 : true,
          inputVisible: !!ir && ir.width > 40 && ir.bottom <= innerHeight + 2,
        };
        if (sh.classList.contains('ai-open')) toggleAI();
        await wait(150);
        return out;
      });
      rows.push([name, r]);
    }
    const opened = rows.filter(([, r]) => r && r.open);
    ok('the figures could be opened at every frame', opened.length === rows.length,
       `${opened.length} of ${rows.length}`);
    const crushed = rows.filter(([, r]) => !r || r.bodyH < FLOOR)
                        .map(([n, r]) => `${n}: ${r ? r.bodyH + 'px' : 'no panel'}`);
    ok(`the answer keeps at least ${FLOOR}px with the figures open`, crushed.length === 0,
       crushed.join('; ') || rows.map(([n, r]) => `${n.split(' ')[0]} ${r.bodyH}px`).join(', '));
    const stuck = rows.filter(([, r]) => !r || !r.scrolls).map(([n]) => n);
    ok('and still scrolls when the answer is longer than the room', stuck.length === 0,
       stuck.join('; ') || 'every frame scrolls');
    const hidden = rows.filter(([, r]) => !r || !r.inputVisible).map(([n]) => n);
    ok('and the question box is never pushed off the bottom', hidden.length === 0,
       hidden.join('; ') || 'visible at every frame');
  }

  head('regression');
  ok('no console or page errors across the sweep', errors.length === 0, errors.slice(0, 3).join(' | '));

  await browser.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})();
