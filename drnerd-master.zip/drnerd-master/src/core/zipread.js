/* ═══════════════════════════════════════════════════════════════════════════
   zipread.js — read a .zip in the browser, without a library.

   The packages this app is fed already come as zips: a chapter's Markdown next
   to a folder of the figures it cites. Asking someone to unzip on an iPad and
   then multi-select two hundred files is not a workflow, so the importer needs
   to open the zip itself.

   Fifty lines rather than a dependency, because the format's useful half is
   small and the alternative is 90 KB of JSZip inlined into a file that is
   already 32 MB. Deflate is done by DecompressionStream, which the browser has
   had since Safari 16.4 — the part that would actually have justified a
   library is the part the platform now provides.

   READS THE CENTRAL DIRECTORY, NOT THE LOCAL HEADERS, for sizes. A local
   header is allowed to carry zeroes and defer the real sizes to a data
   descriptor after the payload, which is exactly what streaming zip writers
   emit; the central directory is always authoritative. Reading the wrong one
   is the classic way a hand-rolled zip reader works on your files and fails on
   someone else's.

   Not supported, deliberately: zip64 (>4 GB), encryption, and compression
   methods other than stored and deflate. Each is reported as a skipped entry
   rather than a silent empty file.

   MAX_INFLATED CAPS WHAT ANY ONE ENTRY IS ALLOWED TO EXPAND TO. Deflate can
   reach roughly 1000:1 on pathological input — a zip bomb — so a chapter
   package a fellow drags in off their own iPad could, if malformed or
   malicious, ask a phone-class browser tab to hold gigabytes it never
   downloaded. The central directory's own uncompressed-size field is read
   first as a cheap early skip, but it is declared by whoever built the zip
   and cannot be trusted — the real backstop is the running total measured
   while the DecompressionStream is actually read, which aborts the instant
   it crosses the cap regardless of what the header claimed.
   ═══════════════════════════════════════════════════════════════════════════ */
(function (root) {
'use strict';

const EOCD_SIG = 0x06054b50, CEN_SIG = 0x02014b50;
const MAX_INFLATED = 256 * 1024 * 1024;  // per entry — generous for a chapter's figures, nowhere near a bomb's target

/* AND THE ARCHIVE AS A WHOLE. MAX_INFLATED bounds any single entry, which is
   what stops one deflate bomb, but every entry that survives it is pushed into
   an array and held until read() returns. An archive of many individually
   legal entries therefore had no ceiling at all: 4,000 entries of 200 KB is
   800 MB of live Uint8Array on a device whose whole tab budget is smaller
   than that. Not an exploit — this reads a file the fellow chose — but an
   out-of-memory on an iPad is indistinguishable from a crash, and a chapter
   import is exactly when someone has picked a folder without counting it.

   Overridable so the tests can drive the behaviour with small numbers. What
   is worth protecting is that the cap is enforced and that exceeding it
   degrades to `skipped` rather than throwing; the specific byte count is a
   judgement about iPad memory, and a test that pinned it would only be a copy
   of this line. */
const MAX_ENTRIES = 4096;
const MAX_TOTAL_INFLATED = MAX_INFLATED;   // the whole archive may not exceed what one entry already could

function u16(v, p) { return v.getUint16(p, true); }
function u32(v, p) { return v.getUint32(p, true); }

/* The end-of-central-directory record sits at the very end, unless there is a
   trailing comment — hence the scan back over the largest comment allowed. */
function findEOCD(view) {
  const max = Math.min(view.byteLength, 0xffff + 22);
  for (let i = 22; i <= max; i++) {
    const p = view.byteLength - i;
    if (u32(view, p) === EOCD_SIG && p + 22 + u16(view, p + 20) === view.byteLength) return p;
  }
  return -1;
}

async function inflateRaw(bytes, limit) {
  if (typeof DecompressionStream === 'undefined') throw new Error('no DecompressionStream');
  const stream = new Response(bytes).body.pipeThrough(new DecompressionStream('deflate-raw'));
  const reader = stream.getReader();
  const chunks = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > limit) { reader.cancel(); throw new Error('inflated entry exceeds the size limit'); }
    chunks.push(value);
  }
  const out = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) { out.set(c, off); off += c.byteLength; }
  return out;
}

/* Returns [{name, bytes}] for every file it could read, plus the names it
   could not, so the caller can say so rather than pretend the zip was empty. */
async function read(arrayBuffer, opts) {
  const maxEntries = (opts && opts.maxEntries) || MAX_ENTRIES;
  const maxTotal   = (opts && opts.maxTotal)   || MAX_TOTAL_INFLATED;
  let totalOut = 0;
  const view = new DataView(arrayBuffer);
  const all = new Uint8Array(arrayBuffer);
  const eocd = findEOCD(view);
  if (eocd < 0) throw new Error('not a zip file');

  const total = u16(view, eocd + 10);
  let p = u32(view, eocd + 16);
  const dec = new TextDecoder();
  const files = [], skipped = [];

  for (let i = 0; i < total && p + 46 <= view.byteLength; i++) {
    if (u32(view, p) !== CEN_SIG) break;
    const flags = u16(view, p + 8);
    const method = u16(view, p + 10);
    const compSize = u32(view, p + 20);
    const uncompSize = u32(view, p + 24);
    const nameLen = u16(view, p + 28);
    const extraLen = u16(view, p + 30);
    const cmtLen = u16(view, p + 32);
    const localAt = u32(view, p + 42);
    const name = dec.decode(all.subarray(p + 46, p + 46 + nameLen));
    p += 46 + nameLen + extraLen + cmtLen;

    if (!name || name.endsWith('/')) continue;                  // a directory
    if (compSize === 0xffffffff || localAt === 0xffffffff) { skipped.push(name); continue; }  // zip64
    if (flags & 0x41) { skipped.push(name); continue; }  // traditional or strong encryption
    if (method !== 0 && method !== 8) { skipped.push(name); continue; }
    if (files.length >= maxEntries) { skipped.push(name); continue; }

    /* The remaining budget, not the per-entry cap. An entry that fits
       MAX_INFLATED on its own can still be more than what is left, and the
       inflate limit below has to be the smaller of the two or a single late
       entry could spend the whole archive's allowance after the count check
       has already passed it. */
    const budget = maxTotal - totalOut;
    const allow = Math.min(MAX_INFLATED, budget);
    if (budget <= 0) { skipped.push(name); continue; }
    if (uncompSize > allow) { skipped.push(name); continue; }  // declared size alone rules it out

    /* The local header repeats the name and extra fields, and its extra field
       length may differ from the central one — so it has to be read here
       rather than assumed. */
    if (localAt + 30 > view.byteLength || u32(view, localAt) !== 0x04034b50 ||
        (u16(view, localAt + 6) & 0x41) || u16(view, localAt + 8) !== method) {
      skipped.push(name); continue;
    }
    const lNameLen = u16(view, localAt + 26);
    const lExtraLen = u16(view, localAt + 28);
    const start = localAt + 30 + lNameLen + lExtraLen;
    if (start + compSize > view.byteLength) { skipped.push(name); continue; }
    const raw = all.subarray(start, start + compSize);

    try {
      const bytes = method === 0 ? raw : await inflateRaw(raw, allow);
      if (bytes.length > allow || bytes.length !== uncompSize) {
        skipped.push(name); continue;
      }
      totalOut += bytes.length;
      files.push({ name, bytes });
    } catch (_) { skipped.push(name); }
  }
  return { files, skipped };
}

root.ZipRead = { read, findEOCD };

})(typeof window !== 'undefined' ? window : this);
