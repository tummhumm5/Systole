#!/usr/bin/env node
/*
 * Carve a piece of app/systole.html into its own file: step 3 of retiring the
 * patch chain (docs/BUILD.md, "How it got here").
 *
 *   node scripts/carve.js <from> <to> app/<path>
 *
 * Lines <from>..<to> of the shell (1-based, inclusive, whole lines) move to
 * app/<path>, and one token, @@SLOT[app:app/<path>]@@, stands where they
 * were. scripts/app-slots.js fills it back at assembly, so the assembled app
 * is the same bytes before and after, and that is checked here before
 * anything is kept: if it is not, or the shell cannot be written, the piece is
 * removed and the shell is left as it was.
 *
 * A carve is refused when
 *   - the lines hold a slot token (a piece is plain text; nothing is filled
 *     inside one),
 *   - their text stands in the shell more than once (freeze-shell could not
 *     tell which site to claim, as with a src module),
 *   - the path is not under app/, is the shell, or already exists.
 *
 * This proves the carve loses nothing. It cannot prove the result is still
 * the chain's build: only `node scripts/assemble-app.js --compare` beside a
 * chain build shows that, on the owner's machine.
 *
 * auditApp() is the standing check on the committed app/: every token
 * resolves, every piece is cited once, no piece holds a token.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const Slots = require('./app-slots.js');

const ROOT = path.join(__dirname, '..');
const SHELL = 'app/systole.html';

/* A name is forward-slash segments under app/, as slot names are written: on
   Windows a backslash is a separator to path.join, and "app/..\x" would leave
   app/ unnoticed. Held to a new piece by carve() and to every app token by
   auditApp(), so the two cannot disagree about what a piece's name is. */
const validName = name => /^app\/[^@\]\\]+$/.test(name) && !name.split('/').some(s => s === '' || s === '.' || s === '..');

/* carve({ shell, from, to, name }) → { shell, piece }. Pure: writes nothing. */
function carve({ shell, from, to, name }) {
  if (!validName(name)) throw new Error(`"${name}" is not a path under app/`);
  if (name === SHELL) throw new Error('the shell cannot be carved into itself');
  /* repoSources() does not offer these as pieces, so a freeze would neither
     claim the file nor report it: the carve would be silently dropped. */
  if (Slots.isMetadata(name.slice('app/'.length))) throw new Error(`"${name}" is a name the pieces of app/ skip (a dotfile, a dot-directory, Thumbs.db, desktop.ini)`);
  const lines = shell.split('\n');
  /* A shell ending in a newline splits to a last empty entry, which is not a line. */
  const total = shell.endsWith('\n') ? lines.length - 1 : lines.length;
  if (!Number.isInteger(from) || !Number.isInteger(to) || from < 1 || to < from || to > total)
    throw new Error(`lines ${from}..${to} are not a range of the shell's ${total} lines`);
  const before = lines.slice(0, from - 1).map(l => l + '\n').join('');
  const piece = lines.slice(from - 1, to).map(l => l + '\n').join('');
  const after = shell.slice(before.length + piece.length);
  if (before + piece + after !== shell) throw new Error(`lines ${from}..${to} do not end in a newline`);
  if (piece.includes('@@SLOT[')) throw new Error('the lines hold a slot token: a piece holds none');
  const times = countIn(shell, piece);
  if (times !== 1) throw new Error(`the lines' text stands in the shell ${times} times: a piece must be found exactly once`);
  return { shell: before + Slots.token('app', name) + after, piece };
}

/* Every start offset, overlapping ones included (see app-slots.js): of three
   identical lines a two-line piece starts at two offsets, and a count that
   found one would accept it at either while cut() later took the first. The
   freeze's count and this one are the same function, so they cannot disagree. */
const countIn = Slots.countAll;

/* destinationProblem(root, name) → text, or null when nothing stands in the way.
   Judged before anything is written. existsSync follows links, so a dangling
   link at the destination reads as absent and the write would create its target
   wherever it points; and a parent that is a link can lead out of app/. So the
   destination is looked at as it stands (lstat), and the nearest parent that
   exists must resolve to somewhere inside app/. */
function destinationProblem(root, name) {
  const file = path.join(root, name);
  try { fs.lstatSync(file); return `${name} already exists`; } catch (e) { if (e.code !== 'ENOENT') return `${name} could not be examined: ${e.message}`; }
  let dir = path.dirname(file);
  for (;;) {
    try { fs.lstatSync(dir); break; } catch (e) {
      if (e.code !== 'ENOENT') return `${name} could not be examined: ${e.message}`;
      const up = path.dirname(dir);
      if (up === dir) return `${name} has no parent directory that exists`;
      dir = up;
    }
  }
  let real, base;
  try { real = fs.realpathSync(dir); base = fs.realpathSync(path.join(root, 'app')); } catch (e) { return `${name} stands under a link that leads nowhere`; }
  const rel = path.relative(base, real);
  if (rel.split(path.sep)[0] === '..' || path.isAbsolute(rel)) return `${name} would be written outside app/: a directory above it is a link`;
  return null;
}

/* Payloads stand as themselves: a carve is judged on the app, not the content. */
const withPayloadsLeft = root => {
  const repo = Slots.repoResolver(null, root);
  return (kind, name) => (kind === 'payload' ? `<payload ${name}>` : repo(kind, name));
};

/* carveFile({ root, from, to, name }) → { bytes }. Writes the piece and the shell.
   `cut` is a parameter so the suite can hand it a carve that loses a line and
   see the same-bytes check refuse it, and `write` so it can fail either
   write and see the piece taken back; nothing else passes either.

   The shell is replaced by rename, so it is the old one or the new one, never
   part of each, and a write that fails takes the piece back with it. A process
   killed between the two writes still leaves a piece beside the old shell:
   auditApp names it as cited by no token, and deleting it is the whole repair. */
function carveFile({ root = ROOT, from, to, name, cut = carve, write = fs.writeFileSync }) {
  const shellFile = path.join(root, SHELL), pieceFile = path.join(root, name);
  const old = fs.readFileSync(shellFile, 'utf8');
  const r = cut({ shell: old, from, to, name });
  const blocked = destinationProblem(root, name);
  if (blocked) throw new Error(blocked);
  const was = Slots.assemble(old, withPayloadsLeft(root));
  /* Found once in the shell is not enough. A chain build has every piece inline,
     and cut() takes pieces in filename order: text that also stands inside a
     piece already carved is found twice by whichever of the two sorts first, and
     a freeze then refuses a build that is byte for byte the app. So the count
     is of the whole assembled app. */
  const whole = countIn(was, r.piece);
  if (whole !== 1) throw new Error(`the lines' text stands in the assembled app ${whole} times (once here, the rest inside pieces already carved): a piece must be found exactly once there`);
  fs.mkdirSync(path.dirname(pieceFile), { recursive: true });
  try { write(pieceFile, r.piece); } catch (e) {
    fs.rmSync(pieceFile, { force: true });
    throw new Error('the piece could not be written, so nothing was kept: ' + e.message);
  }
  let same = false;
  try { same = Slots.assemble(r.shell, withPayloadsLeft(root)) === was; } catch (e) { same = false; }
  if (!same) {
    fs.rmSync(pieceFile, { force: true });
    throw new Error('assembling the carved shell does not give the same bytes: nothing was kept');
  }
  const next = shellFile + '.carving';
  try {
    write(next, r.shell);
    fs.renameSync(next, shellFile);
  } catch (e) {
    fs.rmSync(next, { force: true });
    fs.rmSync(pieceFile, { force: true });
    throw new Error('the shell could not be written, so the piece was removed: ' + e.message);
  }
  return { bytes: r.piece.length };
}

function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  /* Regular files only, as app-slots' walk: a link is neither followed nor a piece. */
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(e =>
    e.isDirectory() ? walk(path.join(dir, e.name)) : e.isFile() ? [path.join(dir, e.name)] : []);
}

/* auditApp(root) → { problems: [text], pieces: [name], tokens: n }
   The committed app/, with no export and no build: what assembling it will
   need from the repository is there, and nothing under app/ is left over. */
function auditApp(root = ROOT) {
  const problems = [];
  const shell = fs.readFileSync(path.join(root, SHELL), 'utf8');
  const repo = Slots.repoResolver(null, root);
  const payloads = new Set(Slots.PAYLOADS.map(p => p.name));
  const cited = new Map(), payloadSeen = new Map();
  let tokens = 0;
  for (const m of shell.matchAll(Slots.TOKEN_RE)) {
    const [, kind, name] = m;
    tokens++;
    if (kind === 'payload') {
      if (!payloads.has(name)) problems.push(`payload:${name} is not a payload app-slots knows`);
      else payloadSeen.set(name, (payloadSeen.get(name) || 0) + 1);
      continue;
    }
    if (!['src', 'asset', 'app'].includes(kind)) { problems.push(`${kind}:${name} is not a kind of slot`); continue; }
    /* repo() would read app:package.json or app:src/x.js if the file exists, and
       assembly would inject a file that is not a piece of app/. */
    if (kind === 'app' && !validName(name)) { problems.push(`app:${name} is not a path under app/`); continue; }
    if (typeof repo(kind, name) !== 'string') problems.push(`${kind}:${name} has no file in the repository, or none inside ${Slots.KIND_DIR[kind]}/`);
    if (kind === 'app') {
      cited.set(name, (cited.get(name) || 0) + 1);
      if (Slots.isMetadata(name.slice('app/'.length))) problems.push(`${name} is cited, but it is a name the pieces of app/ skip: a freeze would not claim it`);
    }
  }
  /* A token removed by hand leaves nothing for the loop above to see. A
     payload the shell repeats is not counted here: assembling it throws, and
     the assembly check below records that. */
  for (const p of Slots.PAYLOADS) {
    if (p.required && !payloadSeen.get(p.name)) problems.push(`payload:${p.name} is required and the shell has 0 of it: assembling would write a build without it`);
  }
  const pieces = walk(path.join(root, 'app')).map(f => path.relative(root, f).split(path.sep).join('/'))
    .filter(n => n !== SHELL && !Slots.isMetadata(n.slice('app/'.length))).sort();
  for (const name of pieces) {
    const n = cited.get(name) || 0;
    if (n !== 1) problems.push(`${name} is cited by ${n} tokens: a piece is cited by exactly one`);
    const text = fs.readFileSync(path.join(root, name), 'utf8');
    if (text.includes('@@SLOT[')) problems.push(`${name} holds a slot token`);
    if (text.includes('\r')) problems.push(`${name} has a carriage return: the chain's output has none`);
  }
  /* The same rule carveFile holds a new piece to, held to the pieces already
     there: a tree can break it by hand or by two carves that each looked fine. */
  let assembled = null;
  try { assembled = Slots.assemble(shell, withPayloadsLeft(root)); } catch (e) {
    /* A slot with nothing to fill it was named in the loop above. Any other
       failure (a repeated slot, a malformed token) is one assemble-app would
       stop on too, and the audit must not pass a shell that cannot assemble. */
    if (!/has nothing to fill it/.test(e.message)) problems.push(`the shell does not assemble: ${e.message}`);
  }
  /* Only pieces a token cites: an uncited one is named above, and assembling
     never writes it, so what the app holds of it is nothing to count. */
  if (assembled !== null) for (const name of pieces.filter(n => cited.get(n))) {
    const text = fs.readFileSync(path.join(root, name), 'utf8');
    /* An empty piece is counted by nothing: cut() never matches it, so a freeze
       would report it inline and assembling would silently drop its region. */
    if (text === '') { problems.push(`${name} is empty`); continue; }
    const n = countIn(assembled, text);
    if (n !== 1) problems.push(`${name}'s text stands in the assembled app ${n} times: a piece is found exactly once there, or a freeze depends on filename order`);
  }
  return { problems, pieces, tokens };
}

if (require.main === module) {
  const [from, to, name] = process.argv.slice(2);
  if (!name) { console.error('usage: node scripts/carve.js <from> <to> app/<path>'); process.exit(2); }
  try {
    const r = carveFile({ from: Number(from), to: Number(to), name });
    console.log(`carved lines ${from}..${to} → ${name}  (${(r.bytes / 1e3).toFixed(1)} KB). Assembles to the same bytes.`);
    console.log('Nothing is staged. Beside a chain build: node scripts/assemble-app.js --compare build/systole.html');
  } catch (e) {
    console.error('carve: ' + e.message);
    process.exit(1);
  }
}

module.exports = { carve, carveFile, auditApp };
