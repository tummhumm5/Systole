#!/usr/bin/env node
/*
 * Stage 1, step 2 — assemble the installable app around the extracted content.
 *
 *   node scripts/extract-content.js <standalone.html>     # first
 *   node scripts/build-pwa.js       <standalone.html>     # then this
 *
 * Produces dist/:
 *
 *     index.html              the shell — CSS, fonts, icons, splash. No content.
 *     app.js                  the application code, unchanged apart from the
 *                             two content constants and the vision call
 *     content/questions.json  the bank
 *     content/figures/*.webp  408 figures, fetched on demand and cached
 *     manifest.webmanifest    so Add to Home Screen produces an app
 *     sw.js                   precache the shell, runtime-cache the figures
 *     icons/*.png
 *
 * WHY THE APP CODE STAYS A CLASSIC SCRIPT. The obvious move is
 * <script type="module"> with a top-level await on the content. It would
 * work, but module scope is not global scope: every top-level function and
 * binding would stop being reachable by name, which is how the six existing
 * test suites drive the app (page.evaluate(() => { goLab(); render(); })).
 * Rewriting all six to reach through an export object would be a lot of
 * churn for no user-visible gain. So instead the loader fetches the content,
 * puts it on window, and only then injects app.js as an ordinary script —
 * whose top-level declarations land in global scope exactly as they do today.
 *
 * WHAT THIS CHANGES ABOUT DELIVERY. A fetch() will not cross file:// origins,
 * so this build has to be served over http(s); it is not a thing you drop in
 * Files and open. That is inherent to splitting content out, not incidental
 * to how it is done here, and it is why the single-file build stays exactly
 * where it is — that remains the artifact for the Files-app workflow.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

/* --no-content: the CODE-ONLY DEPLOY. dist/ gets no questions.json, no
   manifest.json and no figures/ — nothing licensed is uploaded to a host. The
   bank reaches the iPad as a package the owner imports from Files
   (tools/pack-content.js → src/core/bankstore.js), and the loader shows an
   import screen until it has one. content/ is still read, locally, for the
   digest checks and the build stamp: the build is the same build, it only
   ships less. Without the flag nothing below changes. */
const NO_CONTENT = process.argv.includes('--no-content');
const SRC = process.argv.slice(2).find((a, i, all) => !a.startsWith('--') && all[i - 1] !== '--package');
if (!SRC) {
  console.error('usage: node scripts/build-pwa.js <standalone.html> [--no-content [--package out.zip]]');
  process.exit(1);
}
const ROOT = path.join(__dirname, '..');
const CONTENT = path.join(ROOT, 'content');
const DIST = path.join(ROOT, 'dist');
const CSP = require('./csp.js');

if (!fs.existsSync(path.join(CONTENT, 'questions.json'))) {
  console.error('content/questions.json is missing — run scripts/extract-content.js first');
  process.exit(1);
}

/* ── the two halves of a split build must be the same build ─────────────────
 *
 * THE WINDOW THIS CLOSES, and it is wider than it looks. This script reads
 * two things: the single-file build named on the command line, and whatever
 * happens to be sitting in content/. Until now it checked only that content/
 * EXISTED. Nothing checked that it came from the file being split.
 *
 * So: rebuild build/systole.html — the app's code changed, a key was corrected, a
 * figure was re-cut — and then run
 *
 *     node scripts/build-pwa.js build/systole.html
 *
 * without re-running extract-content.js in between. dist/index.html and
 * dist/app.js are the new build. dist/content/questions.json and the 408
 * figures are the old one. And it is SILENT, because every downstream guard
 * still agrees with itself: BUILD_ID is computed fresh in this run and
 * stamped into all three files, so the shell, the app and the worker pass
 * "all three are the same build" while the bank underneath them is a
 * different extraction entirely.
 *
 * That sequence is not hypothetical — it is the sequence docs/IPAD.md printed,
 * two commands with no extract step between them, which is correct only on a
 * clean checkout where content/ does not yet exist.
 *
 * The comparison is exact and the failure is loud: the same digest
 * extract-content.js already writes into content/manifest.json, recomputed
 * here over the same bytes, and a refusal that names the fix.
 */
function staleContent(srcDigest, manifest) {
  const have = manifest && manifest.sourceDigest;
  if (!have) {
    return 'content/manifest.json carries no sourceDigest, so there is no way to tell '
         + 'which build it was extracted from — re-run scripts/extract-content.js';
  }
  if (String(have) !== String(srcDigest)) {
    return 'content/ was extracted from a DIFFERENT build (content says ' + have
         + ', this build is ' + srcDigest + ') — re-run scripts/extract-content.js '
         + 'on this file before splitting it';
  }
  return null;
}

/* Over the file as it is on disk, because extract-content.js hashes it that
   way and this script is about to start cutting pieces out of `html`. */
const SRC_DIGEST = crypto.createHash('sha256')
  .update(fs.readFileSync(SRC)).digest('hex').slice(0, 16);
const contentManifest = JSON.parse(fs.readFileSync(path.join(CONTENT, 'manifest.json'), 'utf8'));
{
  const stale = staleContent(SRC_DIGEST, contentManifest);
  if (stale) { console.error(stale); process.exit(1); }
}

/* ── which commit produced this ──────────────────────────────────────────────
 *
 * BUILD_ID answers "are these files from the same deploy?" and answers it
 * well — but it is a digest of bytes, so it cannot answer "which commit do I
 * open to see what is in this?". Three months after a deployment that is the
 * question, and until now the only place it was recorded was
 * build/release-report.md, which is gitignored, never uploaded, and exists
 * only on the machine that built it.
 *
 * So the commit rides along, BESIDE the existing stamps and never folded into
 * them: BUILD_ID keeps meaning exactly what it meant, and the cache keys
 * (SHELL_V, CONTENT_V) do not move because a commit message changed.
 *
 * A build from a tarball with no .git is a legitimate build, so a missing git
 * is 'unknown' rather than a failure. A dirty tree is marked, because a
 * commit id over uncommitted changes is a claim the repository cannot honour.
 */
function gitCommit() {
  try {
    const at = execFileSync('git', ['rev-parse', '--short=12', 'HEAD'],
                            { cwd: ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    if (!/^[0-9a-f]{7,40}$/.test(at)) return 'unknown';
    const dirty = execFileSync('git', ['status', '--porcelain'],
                               { cwd: ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim().length > 0;
    return dirty ? at + '-dirty' : at;
  } catch (_) { return 'unknown'; }
}
const COMMIT = gitCommit();

let html = fs.readFileSync(SRC, 'utf8');
const steps = [];
function step(label, fn) { fn(); steps.push(label); }

/* ── 1. split the app code out of the document ───────────────────────────── */
const OPEN = '<script>\nconst ALL_Q=';
const openAt = html.indexOf(OPEN);
if (openAt < 0) throw new Error('could not find the main <script> (expected it to open with const ALL_Q=)');
const codeFrom = openAt + '<script>\n'.length;
const closeAt = html.lastIndexOf('</script>');
if (closeAt < codeFrom) throw new Error('could not find the closing </script>');

let appCode = html.slice(codeFrom, closeAt);

/* Drop the two content constants. They are each exactly one line, and the
   regex is anchored to line start + `;` at line end so it cannot swallow any
   of the ~4900 lines of code that follow. */
step('strip the inline question bank', () => {
  const before = appCode.length;
  appCode = appCode.replace(/^const ALL_Q=\[[\s\S]*?\];$/m, '');
  if (appCode.length === before) throw new Error('ALL_Q line not removed');
});
step('strip the inline figure blob', () => {
  const before = appCode.length;
  appCode = appCode.replace(/^const IMGS=\{[\s\S]*?\};$/m, '');
  if (appCode.length === before) throw new Error('IMGS line not removed');
});

/* ── 2. the two places that genuinely needed data URLs ───────────────────── */
/* Figures now live at URLs, which <img src> takes happily but neither
   provider's chat API does — both want base64. So the AI path resolves them
   at send time. Only there: fetching and encoding 18 MB up front is exactly
   what we are getting away from, and an API call is rare next to a render.
   ONE call site now, not two. Each provider built its own wire shape around
   the same withFigures/withImages pair and so carried its own copy of this
   fragment; with the second provider gone there is one copy, and this guard
   moved with it rather than being loosened to "one or more" — the count is
   the point, because a silently-missed call site ships an 18 MB fetch. */
const AI_CALL = `(typeof IMGS!=='undefined'?IMGS[q&&q.id]:null)`;
step('AI path resolves figure URLs to base64 at send time', () => {
  const n = appCode.split(AI_CALL).length - 1;
  if (n !== 1) throw new Error(`vision call site expected in exactly 1 place, found ${n}`);
  appCode = appCode.split(AI_CALL).join('await figuresAsDataUrls(q)');
});

step('add the figure resolver', () => {
  const anchor = `/* ── figures ── */`;
  if (appCode.split(anchor).length - 1 !== 1) throw new Error('figures section anchor not found exactly once');
  appCode = appCode.replace(anchor,
`/* ── figures ── */
/* Display uses the URLs directly — the browser and the service worker cache
   them, which is the whole point of taking them out of the document. The
   Messages API cannot take a URL it has no access to, so only the AI path
   pays to base64 them, and only for the question actually being asked.
   Cached per question id, because a tutor conversation sends the same
   figures on every iteration of the agent loop.

   BOUNDED, BECAUSE BASE64 IS THE EXPENSIVE SHAPE. This held every figure of
   every question ever asked about, for the life of the tab, as base64 — which
   is a third larger again than the bytes on the wire. A fellow working through
   a chapter with Apex open touches dozens of questions in a sitting, and an
   iPad reclaims memory by killing the tab rather than by asking. The URLs cost
   nothing to re-resolve: the service worker has the figure, so a miss is a
   cache read, not a download. So the cache is small on purpose — an agent loop
   sends the same figures several times in a row, which is all it has to cover.

   Least-recently-used, which a Map gives almost for free: it iterates in
   insertion order, so re-inserting on a hit moves an entry to the back and the
   front is always the coldest. */
const FIG_CACHE_MAX_ENTRIES = 24;
const FIG_CACHE_MAX_BYTES   = 24 * 1024 * 1024;
/* A figure that never answers must not hold a turn open, and one that answers
   with something enormous must not be base64ed into memory to find out. The
   cap is well above the largest figure in the bank (the widest is under 400 KB)
   and well below anything that would hurt. */
const FIG_FETCH_TIMEOUT_MS  = 15000;
const FIG_MAX_BYTES         = 8 * 1024 * 1024;
const _figDataCache = new Map();
let _figCacheBytes = 0;
const _figBytes = v => v.reduce((n,s)=>n+(s?s.length:0),0);
function _figTrim(){
  while(_figDataCache.size > FIG_CACHE_MAX_ENTRIES || _figCacheBytes > FIG_CACHE_MAX_BYTES){
    const k = _figDataCache.keys().next().value;
    if(k===undefined) break;
    _figCacheBytes -= _figBytes(_figDataCache.get(k)||[]);
    _figDataCache.delete(k);
  }
  if(_figCacheBytes < 0) _figCacheBytes = 0;
}
async function figuresAsDataUrls(q){
  if(!q || !q.img) return null;
  const urls = (typeof IMGS!=='undefined' && IMGS[q.id]) || null;
  if(!urls || !urls.length) return null;
  if(_figDataCache.has(q.id)){
    const hit = _figDataCache.get(q.id);
    _figDataCache.delete(q.id); _figDataCache.set(q.id, hit);   // now the newest
    return hit;
  }
  const ctl = typeof AbortController!=='undefined' ? new AbortController() : null;
  const timer = ctl ? setTimeout(()=>{ try{ ctl.abort(); }catch(_){} }, FIG_FETCH_TIMEOUT_MS) : null;
  try{
    const out = await Promise.all(urls.map(async u=>{
      const r = await fetch(u, ctl ? {signal:ctl.signal} : undefined);
      if(!r.ok) throw new Error('figure '+r.status);
      /* Refused on the header where there is one, so an oversized figure is
         never read into memory at all; checked again on the blob, because
         content-length is absent on a chunked or service-worker response. */
      const len = +(r.headers.get('content-length')||0);
      if(len && len > FIG_MAX_BYTES) throw new Error('figure too large: '+len);
      const blob = await r.blob();
      if(blob.size > FIG_MAX_BYTES) throw new Error('figure too large: '+blob.size);
      return await new Promise((res,rej)=>{
        const fr = new FileReader();
        fr.onload = ()=>res(fr.result); fr.onerror = rej;
        fr.readAsDataURL(blob);
      });
    }));
    const bytes = _figBytes(out);
    /* One question whose figures exceed the whole budget is returned and not
       kept, rather than evicting everything else to store it and then being
       evicted itself on the next insert. */
    if(bytes <= FIG_CACHE_MAX_BYTES){
      _figDataCache.set(q.id, out);
      _figCacheBytes += bytes;
      _figTrim();
    }
    return out;
  }catch(_){
    return null;      // a figure that will not load must not take the chat down
  }finally{
    if(timer) clearTimeout(timer);
  }
}
`);
});

/* ── 3. the loader that replaces the inline payloads ─────────────────────── */
const LOADER = `<script>
/* Stage 1: content lives beside the app instead of inside it. Fetch it, put
   it on window, and only then inject app.js — a classic script, so all of its
   top-level declarations land in global scope exactly as they did when this
   was one file. The splash is already on screen and covers all of this. */
(async function(){
  /* Replaced at build time; see BUILD_ID in scripts/build-pwa.js. */
  var SHELL_BUILD_ID = '__BUILD_ID__';
  /* Provenance, not identity: this is never compared against anything and
     never gates a launch. It is here so that a deployed directory, opened
     three months later by someone who did not build it, names the commit to
     go and read. Put on window so it can be asked for from the console of a
     device that has no other way to say what it is running. */
  var SHELL_COMMIT = '__COMMIT__';
  try { window.SYSTOLE_BUILD = { build: SHELL_BUILD_ID, commit: SHELL_COMMIT }; } catch(_){}
  /* The heart's baked mesh (see "a copy baked at build time" in
     src/core/heart3d.js): fetched from the start, alongside the bank, and
     handed to the heart as window.HEART3D_MESH before app.js runs. Replaced at
     build time with its path under content/, or with nothing when the build
     carries no mesh. It is never a reason not to launch: a failed fetch, a
     sign-in page in its place, or a copy from other code all leave the heart
     to mesh itself as it always did, and a slow one is waited for at most five
     seconds, which is still less than meshing takes on an iPad. */
  var HEART_MESH_URL = '__HEART_MESH__';
  var heartMesh = HEART_MESH_URL
    ? fetch(HEART_MESH_URL).then(function(r){ return r.ok ? r.arrayBuffer() : null; })
        .then(function(b){ if(b) window.HEART3D_MESH = b; })
        .catch(function(){})
    : null;
  function fail(msg, err){
    console.error(msg, err||'');
    var sp = document.getElementById('splash');
    if(sp){
      var w = sp.querySelector('.sp-word'), s = sp.querySelector('.sp-sub');
      if(w) w.textContent = 'Could not load the question bank';
      if(s) s.textContent = msg;
    }
  }
  /* WHY IT FAILED, RATHER THAN A GUESS AT WHY. This said one sentence for
     every possible failure — "Open this over http, not as a file" — and that
     sentence is right for exactly one of them. A deployment whose content
     folder did not upload prints it too, and so does a sign-in page returned
     in place of the bank. Both happened; the second cost an evening, because
     the screen names a cause it has not checked and the obvious next move is
     to go looking for a file:// problem that is not there.

     The stage variable records how far the load got, which is the only thing
     that can tell these apart from inside the catch. Kept as a plain function
     so tests/verify-loader-pure.js can drive every branch without a browser.

     NO BACKTICKS IN HERE. This whole loader is a template literal in
     scripts/build-pwa.js, and one in a comment ends the string — which is how
     the first version of this paragraph broke the build script rather than
     the build. */
  function whyContentFailed(stage, status, proto){
    if(proto === 'file:')
      return 'Open this over http, not as a file — it needs to fetch its content.';
    if(stage === 'network')
      return 'Could not reach the server for content/questions.json.';
    if(stage === 'status')
      return status === 404
        ? 'content/questions.json is not on the server (404). If this was just deployed, the content folder did not make it into the upload.'
        : 'The server answered ' + status + ' for content/questions.json.';
    if(stage === 'parse')
      return 'content/questions.json loaded but is not the question bank — a sign-in page or an error page in its place will do this.';
    return 'Could not load content/questions.json.';
  }
  /* THE CODE-ONLY DEPLOY (build-pwa.js --no-content). Replaced at build time
     with true or false. Such a build ships no bank: the bank lives in this
     browser's IndexedDB, imported from the owner's own package
     (src/core/bankstore.js), so it is asked first; with none imported, the
     import screen takes the splash's place. A normal build is exactly as it
     was — false skips all of this. */
  var NO_CONTENT = __NO_CONTENT__;
  if(NO_CONTENT){
    var imported = null;
    try{ imported = (typeof BankStore !== 'undefined') ? await BankStore.load() : null; }catch(e){ console.error('bank store', e); }
    if(!imported) return showImport();
    window.ALL_Q = imported.questions;
    window.IMGS = imported.imgs;
    /* Not the split build's downloader: every figure is already on the
       device, so its card has nothing to offer. */
    window.SPLIT_BUILD = false;
    /* The package's bank block, which BankPack.validate checked on import,
       names the bank in the app (BANK in app/systole.html). A package made
       before the block existed has none, and the build's own is used. */
    window.SYSTOLE_BANK = { source: 'imported', questions: imported.questions.length, figures: imported.figures,
                            extras: Object.keys(imported.extras || {}).length,
                            bank: (imported.manifest && imported.manifest.bank) || null };
    /* THE NOTES CAME IN THE PACKAGE TOO. The app fetches its reference seed
       and each unit's figure file from content/ as it always has; in this
       build the host has none of them, so those two kinds of request are
       answered from the imported package and everything else goes to the
       network untouched. The app's own code does not change. */
    var extras = imported.extras || {};
    if(Object.keys(extras).length && typeof window.fetch === 'function'){
      var realFetch = window.fetch.bind(window);
      window.fetch = function(input, init){
        var u = typeof input === 'string' ? input : (input && input.url) || '';
        if(u.indexOf(location.origin + '/') === 0) u = u.slice(location.origin.length + 1);
        u = u.replace(/^[.]?[/]/, '').split('?')[0];
        var hit = u.indexOf('content/') === 0 ? extras[u.slice(8)] : null;
        if(hit) return Promise.resolve(new Response(hit, { status: 200, headers: { 'content-type': 'application/json' } }));
        return realFetch(input, init);
      };
    }
  }
  /* The package the picker hands over, read. The arrayBuffer method of a Blob came in Safari 14 and the floor is iPadOS 13.4, where calling it is a
     TypeError and this screen would say that the package could not be read, before the app could ever open; FileReader is on every Safari. */
  function packageBytes(file){
    if(typeof file.arrayBuffer === 'function') return file.arrayBuffer();
    return new Promise(function(ok, no){
      var r = new FileReader();
      r.onload = function(){ ok(r.result); };
      r.onerror = function(){ no(r.error || new Error('the file could not be read')); };
      r.readAsArrayBuffer(file);
    });
  }
  /* The import screen: its own layer over the splash, a file picker, and a
     line that says what happened in counts — never a word of the bank. On a
     good import the page reloads into the app. */
  function showImport(){
    var sp = document.getElementById('splash');
    if(sp) sp.style.display = 'none';
    var box = document.createElement('div');
    box.id = 'bankImport';
    box.setAttribute('role', 'dialog');
    box.style.cssText = 'position:fixed;top:0;right:0;bottom:0;left:0;z-index:2147483000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;background:#0b1512;color:#e8f2ee;font:16px/1.45 system-ui,-apple-system,sans-serif;text-align:center';
    box.innerHTML = '<div style="font-size:24px;font-weight:600">Import your study content</div>' +
      '<div style="max-width:30em;opacity:.8">This copy of Systole carries no question bank. Pick the package you made with tools/pack-content.js (systole-content-v1.zip). It stays on this device.</div>' +
      '<label style="padding:12px 20px;border-radius:12px;background:#1f8a6a;color:#fff;cursor:pointer">Choose file<input id="bankFile" type="file" accept=".zip,application/zip" style="display:none"></label>' +
      '<div id="bankStatus" aria-live="polite" style="min-height:3em;max-width:34em;opacity:.9"></div>';
    document.body.appendChild(box);
    var status = box.querySelector('#bankStatus');
    box.querySelector('#bankFile').addEventListener('change', async function(ev){
      var file = ev.target.files && ev.target.files[0];
      if(!file) return;
      try{
        status.textContent = 'Reading the package…';
        var zip = await ZipRead.read(await packageBytes(file));
        status.textContent = 'Checking ' + zip.files.length + ' files…';
        var verdict = BankPack.validate(zip.files);
        if(!verdict.ok){
          status.textContent = 'Not imported: ' + verdict.problemCount + ' problem(s). ' + verdict.problems.slice(0, 3).join('; ');
          return;
        }
        status.textContent = 'Storing ' + verdict.questions.length + ' questions and ' + verdict.figures.length + ' figures…';
        var saved = await BankStore.save(verdict);
        status.textContent = 'Imported ' + saved.questions + ' questions and ' + saved.figures + ' figures. Opening…';
        setTimeout(function(){ location.reload(); }, 400);
      }catch(e){
        console.error('import', e);
        status.textContent = 'Not imported: ' + (e && e.message ? e.message : 'the file could not be read') + '. Nothing was changed.';
      }
    });
  }
  var res = null, stage = 'network';
  if(!NO_CONTENT) try{
    res = await fetch('content/questions.json', {cache:'no-cache'});
    stage = 'status';
    if(!res.ok) throw new Error('HTTP '+res.status);
    stage = 'parse';
    var qs = await res.json();
    window.ALL_Q = qs;
    /* id → array of figure URLs. Same shape the app already expected, so
       buildFigures() and everything downstream is untouched. */
    var imgs = {};
    for(var i=0;i<qs.length;i++){
      var q = qs[i];
      if(q.figs && q.figs.length) imgs[q.id] = q.figs.map(function(f){ return 'content/figures/'+f; });
    }
    window.IMGS = imgs;
    /* Which build this is, stated rather than inferred. The offline downloader
       is only meaningful here — in the single file every figure is a data: URI
       already in memory, and a button offering to fetch them would be a lie. */
    window.SPLIT_BUILD = true;
  }catch(err){
    return fail(whyContentFailed(stage, res && res.status, location.protocol), err);
  }
  /* THE SHELL AND THE CODE HAVE TO BE FROM THE SAME BUILD, and until this ran
     nothing checked. sw.js serves the shell cache-first and refreshes it in the
     background, per request — so a deploy landing between the request for
     index.html and the request for app.js leaves a launch running one build's
     HTML against the other build's code, and the mixed pair persists in the
     cache until something replaces it. Nothing crashes; the app just behaves
     like neither version.

     Both files carry the same stamp, generated over the shell digest and the
     content digest together, so any change to either moves it. A disagreement
     means the pair is mixed, and one reload is enough: the worker has since
     settled on one build and will serve both halves of it.

     GUARDED, because a reload that does not fix it must not become a loop.
     sessionStorage rather than a variable, for the same reason the update
     reload below uses it — the reload discards variables. Second time through,
     the fellow is told rather than spun. */
  /* THE DECISION ITSELF, lifted out of the branch it used to live in, so that
     tests/verify-swupdate-pure.js can drive every pairing without a browser
     and without a build. Same move, and the same reason, as
     whyContentFailed() below: the mechanics around it (sessionStorage,
     location.reload) need a page, but WHICH of the three answers is right for
     a given pair is arithmetic, and arithmetic should not need a service
     worker and a served directory to check. */
  function pairVerdict(shellId, appId, alreadyTried){
    /* BOTH HAVE TO BE PRESENT before equality means anything. Written as a
       a bare appId === shellId comparison this answered 'run' to two absent
       stamps (NO BACKTICKS IN HERE: this block is inside the LOADER template
       literal, and a backtick in a comment ends it),
       which is this repository's most-repeated defect wearing a new hat: a
       comparison that passes hardest when nothing is there to compare. It is
       unreachable from the shipped loader — build-pwa.js throws if the
       shell's placeholder was not substituted, and appId is normalised to
       null — but an unreachable branch that answers 'run' is the wrong
       unreachable branch to have. */
    if(!shellId || !appId) return alreadyTried ? 'tell' : 'reload';
    if(appId === shellId) return 'run';
    return alreadyTried ? 'tell' : 'reload';
  }
  /* Inspect the response before executing it. A post-execution check lets
     a rejected build boot and dismiss the warning splash. */
  function appBuildId(text){
    var m = /^var APP_BUILD_ID='([a-f0-9]{16})';/.exec(text);
    return m ? m[1] : null;
  }
  var codeResponse = null, appText = null;
  try{
    codeResponse = await fetch('app.js');
    if(!codeResponse.ok) throw new Error('HTTP ' + codeResponse.status);
    appText = await codeResponse.text();
  }catch(err){
    return fail('The application code failed to load.', err);
  }
  var appId = appBuildId(appText);
  appText = null; codeResponse = null;
  var alreadyTried = true;
  try{ alreadyTried = !!sessionStorage.getItem('accsap-mixed-build'); }catch(_){}
  var verdict = pairVerdict(SHELL_BUILD_ID, appId, alreadyTried);
  var mixedMessage = 'This app updated while it was opening. Close it completely and open it again.';
  if(verdict === 'tell'){
    return fail(mixedMessage, new Error('build mismatch: shell ' + SHELL_BUILD_ID + ', app ' + appId));
  }
  if(verdict === 'reload'){
    try{ sessionStorage.setItem('accsap-mixed-build','1'); }catch(_){ return fail(mixedMessage); }
    location.reload();
    return;
  }
  try{ sessionStorage.removeItem('accsap-mixed-build'); }catch(_){}

  /* STOPS HERE WHEN app.js DOES NOT LOAD. It used to be a trailing
     .catch(function(err){ fail(...) }) with nothing else, so the splash showed
     the error and execution carried straight on into the service-worker
     registration below — installing a worker whose whole job is to cache a
     shell that never ran. The first attempt at this put a return inside that
     callback, which reads like the content-fetch path above but is not the
     same thing at all: it returns from the CALLBACK, the awaited promise then
     resolves normally, and the registration runs exactly as before.
     tests/verify-pwa.js caught it by blocking app.js at the network and
     counting registrations, which is the only reason this is a try/catch and
     not a plausible-looking one-liner. */
  if(heartMesh) await Promise.race([heartMesh, new Promise(function(r){ setTimeout(r, 5000); })]);
  try{
    await new Promise(function(resolve, reject){
      var s = document.createElement('script');
      s.src = 'app.js'; s.integrity = '__APP_INTEGRITY__'; s.onload = resolve; s.onerror = reject;
      document.body.appendChild(s);
    });
  }catch(err){
    return fail('The application code failed to load.', err);
  }


  if('serviceWorker' in navigator){
    /* THE UPDATE THAT ARRIVES UNDER A RUNNING APP. sw.js calls skipWaiting on
       install and clients.claim on activate, so a new worker takes control of
       THIS page — which is still running the app.js it parsed at launch. From
       that moment the worker serves new content to old code: a renamed figure
       path 404s, a changed questions.json shape is read by a parser that
       predates it. On an iPad a home-screen app is rarely killed, so that
       state can persist for weeks.

       Before the shell and figure caches were versioned separately, sw.js was
       byte-identical across code changes and the browser never saw an update
       at all — so this was unreachable. Fixing the versioning is what made it
       reachable, which is the honest reason it is being fixed now.

       One reload, guarded by a flag that lives for this tab only: if the new
       code somehow triggers another controllerchange, the flag is already set
       and the page will not loop. sessionStorage rather than a variable
       because the reload itself discards variables. */
    var hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', function(){
      /* controllerchange ALSO fires on the very first install, when there was
         no controller to be stale — reloading there would be a pointless
         flash on first launch, and worse, it would spend the one-shot guard
         below so a genuine update later in the same tab would be ignored. */
      if(!hadController) { hadController = true; return; }
      try{
        if(sessionStorage.getItem('accsap12.swreloaded')) return;
        sessionStorage.setItem('accsap12.swreloaded','1');
      }catch(_){ return; }   // no sessionStorage means no loop guard, so do not reload
      location.reload();
    });
    try{ await navigator.serviceWorker.register('sw.js'); }catch(_){}
  }
})();
</script>`;

step('swap the inline payloads for the content loader', () => {
  /* The code-only deploy's loader needs the package reader, the checker and
     the store before app.js exists — they run on the import screen, which is
     shown INSTEAD of app.js. A normal build carries none of it. */
  const bankModules = NO_CONTENT
    ? '<script>\n' + ['zipread.js', 'bankpack.js', 'bankstore.js']
        .map(f => fs.readFileSync(path.join(ROOT, 'src', 'core', f), 'utf8')).join('\n') + '\n</script>\n'
    : '';
  html = html.slice(0, openAt) + bankModules + LOADER + html.slice(closeAt + '</script>'.length);
});

step('link the manifest and the iOS icon', () => {
  const anchor = '</head>';
  if (html.split(anchor).length - 1 !== 1) throw new Error('</head> not found exactly once');
  html = html.replace(anchor,
`<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="icons/icon-192.png">
</head>`);
});

/* ── 3.5. the splash heart's image, pulled the same way ──────────────────── */
/* The single-file build inlines the heart photograph as a data: URI directly
   in the splash markup, because paint-before-parse is the whole reason the
   splash exists and nothing should make it wait. That is fine at 27 MB; it is
   not fine against the shell budget. Base64 of an already-compressed WebP does
   not gzip, so inlining puts its full ~57 KB onto the transferred shell — a
   fifth of the 280 KB budget for one decorative image. So here it comes back
   out, the same move extract-content.js makes for the question bank — except
   this lives in index.html itself (the splash predates the <script>ALL_Q=…
   split entirely), so it is extracted from `html`, not `appCode`.

   The static parts of the splash — ground, wordmark, ECG sweep — still paint
   instantly either way. Only the heart itself arrives a beat later here, which
   is exactly the trade the Lottie pair made before it.

   NAMED BY ITS OWN DIGEST, as the heart mesh is (splitHeartMesh). The worker
   serves content/ cache-first, so under a fixed name a new picture reached a
   device only by renaming the content bucket, and that deleted every figure
   the fellow had downloaded (contentVersion below). A new picture is a new
   name now, so contentVersion leaves it out. A plain function of the bytes,
   so tests/verify-swupdate-pure.js can hold contentVersion to the names this
   gives, not to names the test makes up. */
function splashHeartName(bytes) {
  return 'heart-' + crypto.createHash('sha256').update(bytes).digest('hex').slice(0, 12) + '.webp';
}
const splashAssets = [];
step('pull the heart image out of the splash', () => {
  const re = /(<img class="sp-heart-img" data-splash-heart="img" alt="" decoding="sync" src=")data:image\/webp;base64,([A-Za-z0-9+/=]+)(">)/;
  const m = re.exec(html);
  if (!m) throw new Error('splash heart <img> with an inline data: URI not found');
  const bytes = Buffer.from(m[2], 'base64');
  if (bytes.slice(0, 4).toString('ascii') !== 'RIFF' || bytes.slice(8, 12).toString('ascii') !== 'WEBP') {
    throw new Error('the splash heart data: URI did not decode to a WebP');
  }
  const name = splashHeartName(bytes);
  const url = 'content/splash-heart/' + name;
  splashAssets.push([name, bytes]);
  html = html.replace(m[0], m[1] + url + m[3]);

  /* AND THE HERO'S COPY, WHICH IS THE ONE THAT IS EASY TO MISS. The build
     fills the splash's <img> and the hero's in buildHome() from the same
     asset (assets/hero-heart/heart.webp, two slots in app/systole.html), so
     the two hearts can never be different images, and each is a 57 KB base64
     string. The hero's lives in appCode, not html, and pulling
     only the splash copy left the split build shipping the image twice: the
     shell went from 229 KB gzipped to 276 KB against a 280 KB budget, which
     is how this was noticed. Both copies point at the one file. */
  const heroRe = /(<img data-hero-heart="img" src=")data:image\/webp;base64,[A-Za-z0-9+/=]+(")/;
  if (!heroRe.test(appCode)) throw new Error('the hero heart <img> with an inline data: URI was not found in the app code');
  appCode = appCode.replace(heroRe, (mm, a, b) => a + url + b);

  const atlasRe = /(<img class="atlas-anatomy" data-atlas-heart="img" src=")data:image\/webp;base64,([A-Za-z0-9+/=]+)(")/;
  const atlas = atlasRe.exec(appCode);
  if (!atlas) throw new Error('the Atlas anatomy image was not found');
  const atlasBytes = Buffer.from(atlas[2], 'base64');
  if (atlasBytes.slice(0,4).toString('ascii') !== 'RIFF' || atlasBytes.slice(8,12).toString('ascii') !== 'WEBP') throw new Error('invalid Atlas WebP');
  const atlasName = splashHeartName(atlasBytes);
  splashAssets.push([atlasName, atlasBytes]);
  appCode = appCode.replace(atlas[0], atlas[1] + 'content/splash-heart/' + atlasName + atlas[3]);

  /* Neither copy may survive as base64. Checked rather than assumed: this is
     a size regression that no test screen would show and no feature would
     break — it would just be slower, forever. */
  const leftover = (html + appCode).match(/data:image\/webp;base64,/g);
  if (leftover) throw new Error(`${leftover.length} inline WebP data: URI(s) survived into the split build`);
});

// Public teaching media ships separately, with content-addressed names. The
// single-file export keeps its embedded copies; the PWA precaches these assets.
const echoAssets = [];
step('split public echo teaching images', () => {
  appCode = appCode.replace(/(window\.ECHO_MEDIA = \{)([\s\S]*?)(\};)/, (all, start, body, end) =>
    start + body.replace(/data:image\/jpeg;base64,([A-Za-z0-9+/=]+)/g, (_, b64) => {
      const bytes = Buffer.from(b64, 'base64');
      if (bytes[0] !== 255 || bytes[1] !== 216) throw new Error('echo teaching image is not JPEG');
      const name = 'echo-' + crypto.createHash('sha256').update(bytes).digest('hex').slice(0, 12) + '.jpg';
      echoAssets.push([name, bytes]);
      return 'echo/' + name;
    }) + end);
  if (echoAssets.length !== 2) throw new Error('expected both public echo teaching images');
});

/* ── 3.6 the reference seed ───────────────────────────────────────────────
   The build bakes the reference notes in as a seed (the REF_SEED slot,
   scripts/ref-seed.js) so the app opens with
   the library already populated. That is nothing against the single file and
   too much for the shell's size budget (tests/verify-pwa.js). Out it comes, and a
   loader appended to app.js applies it once the code that owns REF exists.
   `let` at script top level lives in the global lexical scope, so the loader
   can see REF and refSeedApply directly without either being on window. */
let refSeed = null;
step('pull the reference seed out of the app code', () => {
  const re = /\/\*REF_SEED_START\*\/([\s\S]*?)\/\*REF_SEED_END\*\//;
  const m = re.exec(appCode);
  if (!m) throw new Error('REF_SEED markers not found — was this built by scripts/assemble-app.js, which fills the REF_SEED slot?');
  JSON.parse(m[1]);   // fail loudly here, not silently at runtime
  refSeed = m[1];
  appCode = appCode.replace(re, '[]');
  appCode += `
/* ── the library arrives after the first paint ─────────────────────────────
   In the single-file build REF is inline, so the home screen is painted with
   the library already in hand. Here it is fetched, and the first paint happens
   without it — which silently cost the home screen its centrepiece: no notes
   means no pearl, so the card simply was not there, and nothing ever asked for
   it again. Filling the binding is not enough; something has to repaint.

   Not a blanket repaint. render() remounts the hero, which restarts an ECG
   canvas and a WebGL heart, and doing that for nothing is worse than the bug.
   So it repaints only when the library actually changed what is on screen, and
   never while a question is up. */
function refLatePaint(){
  if(typeof render !== 'function' || typeof S === 'undefined') return;
  if(S.screen === 'refs'){ render(); return; }
  if(S.screen !== 'home') return;
  var card = document.getElementById('pearlCard');
  var wantPearl = typeof pearlAll === 'function' && pearlAll().length > 0;
  /* Two ways the library can have changed home: there is no pearl and there
     should be one, or a pearl is showing whose figure had not downloaded when
     it was painted. */
  var missingFig = !!card && typeof pearlCurrent !== 'undefined' && pearlCurrent &&
                   pearlCurrent.figKey && !document.getElementById('pearlFig');
  if((!card && wantPearl) || missingFig) render();
}
/* ── reference seed, fetched (see build-pwa.js) ───────────────────────────── */
/* REF_SEED_READY settles once the seed is applied or has failed — never left
   pending — so the note figures, which wait on it, cannot be stranded. */
var REF_SEED_READY = (function(){
  if(typeof REF === 'undefined' || typeof refSeedApply !== 'function') return Promise.resolve();
  return fetch('content/refs-seed.json').then(function(r){ return r.json(); }).then(function(seed){
    REF = refSeedApply(REF, seed);
    if(typeof invalidateIndex === 'function') invalidateIndex();
    refLatePaint();
  }).catch(function(){ /* an unseeded library still works, and still imports */ });
})();
`;
});

/* ── 3.7 the reference figures ────────────────────────────────────────────
   The build embeds every figure a reference note cites (the REF_IMGS slot,
   scripts/ref-images.js) — a few
   megabytes raw, base64'd, which is nothing against the single file and fatal
   to the shell's size budget. Same move as the reference seed: pull it out,
   fetch it, apply it once the binding it fills exists. */
/* ONE FILE PER UNIT, NOT ONE FOR THE SHELF. This used to write every figure
   into a single content/refs-images.json. That file grows with every unit
   added, and Cloudflare Pages will not take a file over 25,000,000 bytes: the
   arrhythmias unit took it to 25.7 MiB and a deploy broke, and even after its
   figures were cropped the shelf as a whole had room for about one more unit.
   Split by the first segment of the refimg:// key — the unit folder under
   content/refs-images/, so hf/049_FIG….jpg lands in hf.json — each unit now
   has the ceiling to itself, and adding a unit never grows another unit's
   file. The pagesLimitReport guard below still checks every one of them.

   Kept as a plain function of the parsed map so tests/verify-loader-pure.js
   can drive it without a build. A key with no folder goes to "loose"; a folder
   name that is not URL-safe is made so, and two that collapse to the same safe
   name simply share a file, which costs nothing.

   AND A UNIT THAT OUTGROWS ONE FILE CONTINUES IN THE NEXT. One file per unit
   moved the ceiling to the unit, and a unit can reach it too: the Braunwald
   heart-failure unit's file was ~21.7 MB against 25,000,000 bytes, room for a
   handful more figures. So a unit's figures, in key order, fill "unit" up to
   `budget` bytes of JSON and carry on in "unit.2", "unit.3", …. The dot
   cannot occur in a unit name (the name is made of [A-Za-z0-9_-]), so a
   continuation can never be mistaken for another unit, and a unit under the
   budget keeps exactly the file name it always had — nothing already cached
   on a device changes URL. A single figure larger than the budget still gets
   a file to itself; pagesLimitReport is what refuses one over the host's
   ceiling. The budget is a parameter so the suite can drive it small. */
function splitRefImages(imgs, budget = 12 * 1000 * 1000) {
  const byUnit = {};
  for (const key of Object.keys(imgs).sort()) {
    const slash = key.indexOf('/');
    const unit = slash > 0 ? key.slice(0, slash).replace(/[^A-Za-z0-9_-]/g, '_') : 'loose';
    (byUnit[unit] || (byUnit[unit] = [])).push(key);
  }
  const parts = {};
  for (const unit of Object.keys(byUnit)) {
    let n = 1, name = unit, bytes = 2;
    for (const key of byUnit[unit]) {
      const size = JSON.stringify(key).length + JSON.stringify(imgs[key]).length + 2;
      if (parts[name] && bytes + size > budget) { n++; name = unit + '.' + n; bytes = 2; }
      (parts[name] || (parts[name] = {}))[key] = imgs[key];
      bytes += size;
    }
  }
  return parts;
}
let refImgParts = null;
step('pull the reference figures out of the app code, one file per unit', () => {
  const re = /\/\*REF_IMGS_START\*\/([\s\S]*?)\/\*REF_IMGS_END\*\//;
  const m = re.exec(appCode);
  if (!m) return;   // no note cites a figure — nothing to pull out
  const all = JSON.parse(m[1]);   // fail loudly here, not silently at runtime
  refImgParts = splitRefImages(all);
  if (!Object.keys(refImgParts).length) { refImgParts = null; return; }
  const urls = Object.keys(refImgParts).sort().map(u => 'content/refs-images/' + u + '.json');
  appCode = appCode.replace(re, '{}');
  /* After the home screen, one unit at a time: scripts/ref-images-loader.js. */
  appCode += require('./ref-images-loader.js').REF_IMG_LOADER.replace('__PARTS__', () => JSON.stringify(urls));
});

/* THE HEART'S BAKED MESH comes out of app.js the same way. The build embeds it
   (the HEART_MESH slot, scripts/heart-bake.js) as one line of base64 beside
   heart3d.js — 3.3 MB, which the shell budget
   (280 KB gzipped for index.html + app.js, tests/verify-pwa.js) could never
   hold. It becomes a binary file the loader fetches in parallel with the bank.

   NAMED BY ITS OWN DIGEST. The service worker serves content/ cache-first
   and keeps it across code deploys, which is right for the bank and wrong
   for anything derived from code: a mesh under a fixed name would be served
   from cache after heart3d.js changed. A new mesh is a new name, so an old one
   can never answer for it. (heart3d.js checks its key as well.)

   A plain function of the app code, so tests/verify-heartbake-pure.js can
   drive it without a build. */
/* The preload links for the lifted faces, right after the charset
   declaration (which must stay first). Upright faces only. A named function
   so tests/verify-loader-pure.js can lift it out and hold it to that.
   crossorigin is not decoration: a font is always fetched in CORS mode, and a
   preload without it does not match, so the face is downloaded twice. */
function preloadFaces(html, names) {
  const anchor = '<meta charset="UTF-8">\n';
  if (html.split(anchor).length - 1 !== 1) throw new Error('<meta charset="UTF-8"> not found exactly once');
  const upright = names.filter(n => !/-italic\.woff2$/.test(n));
  if (upright.length !== 3) throw new Error(`expected 3 upright faces to preload, found ${upright.length}`);
  const links = upright.map(n => `<link rel="preload" href="fonts/${n}" as="font" type="font/woff2" crossorigin>\n`).join('');
  return html.replace(anchor, anchor + links);
}

function splitHeartMesh(code) {
  const re = /window\.HEART3D_MESH_B64='([A-Za-z0-9+/=]*)';/g;
  const hits = [...code.matchAll(re)];
  if (!hits.length) return null;
  if (hits.length > 1) throw new Error(`build-pwa: ${hits.length} baked heart meshes in app.js, expected one`);
  const bin = Buffer.from(hits[0][1], 'base64');
  const name = 'content/heart-mesh-' + crypto.createHash('sha256').update(bin).digest('hex').slice(0, 12) + '.bin';
  return { code: code.replace(re, () => 'window.HEART3D_MESH_B64=null;'), bin, name };
}
let heartMesh = null;
step('move the heart\'s baked mesh out of the app code', () => {
  heartMesh = splitHeartMesh(appCode);
  if (heartMesh) appCode = heartMesh.code;
});

/* ── 3.74. the figure viewer's library ──────────────────────────────────
   PhotoSwipe (app/vendor/photoswipe) is 54 KB of minified code, 19 KB of it
   gzipped, and the shell was at 278 of its 280 KB when it came. It is needed
   the first time a figure opens and not before, so it leaves app.js for a file
   of its own, named by its content, which the service worker precaches with the
   shell: the viewer works offline from the first launch, and the shell's budget
   does not pay for it. What stays in app.js names the file (PSW_SRC), and
   figLib() loads it on demand. Lifted before the comment stripping below, so
   the library reaches the device byte for byte, its MIT notice included. */
let psw = null;
step('lift the figure viewer\'s library out of the app code', () => {
  const lib = fs.readFileSync(path.join(ROOT, 'app', 'vendor', 'photoswipe', 'photoswipe.umd.min.js'), 'utf8');
  const at = appCode.indexOf(lib);
  if (at < 0 || appCode.indexOf(lib, at + 1) >= 0) throw new Error('PhotoSwipe is not in the app code exactly once');
  const name = 'photoswipe-' + crypto.createHash('sha256').update(lib).digest('hex').slice(0, 12) + '.js';
  psw = { name: 'vendor/' + name, bytes: Buffer.from(lib, 'utf8') };
  /* Its stylesheet too: 2 KB of the shell's gzipped budget for rules nothing
     uses until a figure opens. It leaves the page's style block whole, before
     the stylesheet step below rewrites that block, and figLib() links it back
     with the script. */
  /* With Systole's own dress for the viewer (app/css/figviewer.css), slotted straight after it: neither is drawn until a figure opens. */
  const css = fs.readFileSync(path.join(ROOT, 'app', 'css', 'photoswipe.css'), 'utf8') + fs.readFileSync(path.join(ROOT, 'app', 'css', 'figviewer.css'), 'utf8');
  const cat = html.indexOf(css);
  if (cat < 0 || html.indexOf(css, cat + 1) >= 0) throw new Error('PhotoSwipe\'s stylesheet and the viewer\'s are not in the page together exactly once');
  psw.css = 'vendor/photoswipe-' + crypto.createHash('sha256').update(css).digest('hex').slice(0, 12) + '.css';
  psw.cssBytes = Buffer.from(css, 'utf8');
  html = html.slice(0, cat) + html.slice(cat + css.length);
  appCode = appCode.slice(0, at) + `window.PSW_SRC=${JSON.stringify(psw.name)};window.PSW_CSS=${JSON.stringify(psw.css)};` + appCode.slice(at + lib.length);
});

/* ── 3.745. the pen's library ───────────────────────────────────────────
   perfect-freehand (app/vendor/perfect-freehand) is 2 KB gzipped, and the shell
   was at 279 of its 280 KB when it came. It is needed when ink is first put on
   a canvas, so it goes the way the figure viewer's library went: the block that
   carries it, the function that gives it an `exports` and all, leaves app.js
   for vendor/, precached with the shell; what stays names the file (PF_SRC) and
   inkLib() loads it when the first canvas is made. It has no notice of its own
   to keep, so its licence ships beside it (below). Lifted before the comment
   stripping, so the file the app loads holds the library byte for byte. */
step('lift the pen\'s library out of the app code', () => {
  const lib = fs.readFileSync(path.join(ROOT, 'app', 'vendor', 'perfect-freehand', 'index.js'), 'utf8');
  const block = '(function(){var exports={};\n' + lib + '\n;window.PerfectFreehand=exports;})();';
  const at = appCode.indexOf(block);
  if (at < 0 || appCode.indexOf(block, at + 1) >= 0) throw new Error('perfect-freehand is not in the app code exactly once, in its wrapper');
  psw.pf = 'vendor/perfect-freehand-' + crypto.createHash('sha256').update(block).digest('hex').slice(0, 12) + '.js';
  psw.pfBytes = Buffer.from(block, 'utf8');
  appCode = appCode.slice(0, at) + `window.PF_SRC=${JSON.stringify(psw.pf)};` + appCode.slice(at + block.length);
});

/* ── 3.746. the Practice Lab ────────────────────────────────────────────
   The Lab's eight modules (src/lab/*.js) are about 40 KB of the shell gzipped,
   and nothing reads them until the Lab screen opens: mountPractice() is their one
   caller. The licensed build stood at 288 KB against the 280 KB budget with them
   in. They leave app.js as one file, in the order the page slots them, precached
   with the shell, so the Lab still opens offline from the first launch; what
   stays names the file (LAB_SRC), and mountPractice() loads it the first time
   the Lab is drawn. Physio, RhythmsExtra and FSRS, which the modules read as they
   load, stay in app.js and run first. */
const LAB_FILES = ['heartsounds', 'tracings', 'strips', 'heartmap', 'drill', 'progress', 'items', 'ui'];
step('lift the Practice Lab out of the app code', () => {
  const block = LAB_FILES.map(f => fs.readFileSync(path.join(ROOT, 'src', 'lab', f + '.js'), 'utf8')).join('\n');
  const at = appCode.indexOf(block);
  if (at < 0 || appCode.indexOf(block, at + 1) >= 0) throw new Error('the Lab\'s modules are not in the app code exactly once, in the page\'s order');
  psw.lab = 'vendor/lab-' + crypto.createHash('sha256').update(block).digest('hex').slice(0, 12) + '.js';
  /* Without their comments, as the modules that stay are shipped (step 3.75), and still a script that compiles. */
  const lean = require('./strip-comments.js').strip(block);
  new (require('vm').Script)(lean, { filename: psw.lab });
  psw.labBytes = Buffer.from(lean, 'utf8');
  appCode = appCode.slice(0, at) + `window.LAB_SRC=${JSON.stringify(psw.lab)};` + appCode.slice(at + block.length);
});

/* ── 3.75. the comments in src/'s modules ────────────────────────────────
   The shell budget below was set on the reasoning that comments are close to
   free once compressed. Measured, they are half of what src/ gzips to — 76 of
   149 KB at 7947642 — and the shell had crept to 287 KB against 280 with no
   single change to blame. They stay in src/ and in the single-file build;
   the split build ships each module that app.js carries verbatim through
   scripts/strip-comments.js, which checks every one still compiles. */
let strippedModules = null;
step('ship src/\'s modules without their comments', () => {
  const { stripEmbedded } = require('./strip-comments.js');
  const listSrc = dir => fs.readdirSync(dir, { withFileTypes: true }).flatMap(e =>
    e.isDirectory() ? (e.name === 'worker' ? [] : listSrc(path.join(dir, e.name)))
                    : /\.js$/.test(e.name) ? [path.join(dir, e.name)] : []);
  const mods = listSrc(path.join(ROOT, 'src')).sort()
    .map(f => [path.relative(ROOT, f).split(path.sep).join('/'), fs.readFileSync(f, 'utf8')])
    .filter(([name]) => !(psw.labBytes && name.startsWith('src/lab/')));  // lifted to vendor/ (3.746), stripped there
  strippedModules = stripEmbedded(appCode, mods);
  appCode = strippedModules.code;
  console.log(`  comments out of ${strippedModules.stripped.length} src/ modules` +
    (strippedModules.skipped.length ? `; left as they are (not verbatim in app.js): ${strippedModules.skipped.join(', ')}` : ''));
  if (!strippedModules.stripped.includes('src/core/heart3d.js')) {
    throw new Error('the heart\'s module was not found verbatim in app.js — a chain step edited it after its mesh was baked');
  }
});

// App-shell handlers have grown alongside src modules. Strip their comments
// too, and compact horizontal whitespace outside literals. Keep line breaks
// for automatic semicolon insertion; source and the transfer budget stay intact.
step('ship application handlers without comments', () => {
  const lean = require('./strip-comments.js').strip(appCode, true);
  new (require('vm').Script)(lean, { filename: 'app.js' });
  appCode = lean;
});

/* ── 3.8. the fonts ───────────────────────────────────────────────────────
   Four woff2 faces are inlined as base64 in the single-file build — 250 KB of
   the 802 KB shell, and correctly so there: one file that works offline cannot
   reference a sibling. In the split build that reasoning inverts. A font is a
   static, immutable, separately-cacheable asset; leaving it as base64 makes
   the browser parse a quarter-megabyte of text before it can apply a single
   rule, and re-download all four whenever one byte of CSS changes.

   Out they come. The shell drops to ~560 KB, the CSS parses sooner, and the
   service worker precaches them best-effort — best-effort rather than
   required, because every face has a real fallback stack behind it and a font
   that failed to cache should cost the fellow a typeface, not an install. */
const fontAssets = [];
step('lift the base64 fonts out of the stylesheet', () => {
  const FACE = /@font-face\{([^}]*?)src:url\(data:font\/woff2;base64,([A-Za-z0-9+/=]+)\)([^}]*)\}/g;
  const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  let found = 0;
  html = html.replace(FACE, (whole, head, b64, tail) => {
    const fam = (/font-family:\s*'([^']+)'/.exec(head) || [, 'font'])[1];
    const ital = /font-style:\s*italic/.test(head);
    const name = slug(fam) + (ital ? '-italic' : '') + '.woff2';
    fontAssets.push([name, Buffer.from(b64, 'base64')]);
    found++;
    return `@font-face{${head}src:url(fonts/${name})${tail}}`;
  });
  /* The Lottie player carries an @font-face template of its own, in a JS
     string. It has no data: URL, so it is not matched — and if this ever
     stops finding the four real faces, that is a silently unstyled app. */
  if (found !== 4) throw new Error(`expected 4 inlined font faces, found ${found}`);
});

/* Keep documentation in source and the standalone build. It need not ride on every split-shell download. */
step('ship stylesheet rules without whitespace-delimited documentation', () => {
  const { stripCssDocs } = require('./css-docs.js');
  html = html.replace(/(<style\b[^>]*>)([\s\S]*?)(<\/style>)/gi,
    (_, open, css, close) => open + stripCssDocs(css, true) + close);
});

/* PRELOADED, SO THE FIRST LAYOUT HAS THEM. Lifted out, the faces are only
   requested once the parser has read the 170 KB stylesheet and style finds
   text that uses them, and with font-display:swap the first layout does not
   wait: it asks the operating system for the fallbacks (system-ui, Georgia,
   monospace) and lays out again when the faces arrive. Traced at --cpu 4, that
   was 11 platform font lookups and 32-35 ms inside a 27-object layout here;
   on the owner's laptop the same layout was 194 ms. Preloaded, 1 lookup and
   4-7 ms. The italic face is used by one rule and is left to load on demand.
   Right after the charset declaration, which must stay first. */
step('preload the upright faces', () => { html = preloadFaces(html, fontAssets.map(([n]) => n)); });

/* ── 3.9. the head, told the truth about itself ───────────────────────────
   Two lines in the head are written for the single-file build and are wrong
   the moment it is split. The comment claims the typefaces are embedded and
   that the file requests nothing from the network; neither is true here. And
   `apple-mobile-web-app-capable` is the vendor-prefixed spelling — iOS still
   honours it, but the standard name is what every other browser reads, and
   this build's whole purpose is to be installed from Safari. */
step('correct the head for a build that has a network', () => {
  const note = /<!-- Typefaces are embedded[\s\S]*?-->/;
  if (!note.test(html)) throw new Error('the typeface note was not found in the head');
  html = html.replace(note,
`<!-- The typefaces (DM Sans, DM Serif Display, JetBrains Mono — SIL Open Font
     License) are in fonts/, and the question bank and figures are in content/.
     The service worker caches all of it on first visit, so after one load this
     opens identically on a plane or a hospital wifi. -->`);

  const cap = '<meta name="apple-mobile-web-app-capable" content="yes">';
  if (html.split(cap).length - 1 !== 1) throw new Error('the iOS capability meta was not found exactly once');
  html = html.replace(cap, '<meta name="mobile-web-app-capable" content="yes">\n' + cap);

  /* The policy goes in the shell, not in app.js, because a <meta> policy only
     applies to the document that carries it and only if it arrives before the
     content it governs. See scripts/csp.js for what it does and does not
     claim — it contains an injection, it does not prevent one. */
  if (html.includes('Content-Security-Policy')) throw new Error('the shell already carries a CSP');
  html = html.replace(cap, cap + '\n' + CSP.META);
});

/* ── 4. write it all out ─────────────────────────────────────────────────── */
fs.rmSync(DIST, { recursive: true, force: true });
fs.mkdirSync(path.join(DIST, 'icons'), { recursive: true });
/* contentManifest and SRC_DIGEST are read at the top of this file, where the
   freshness check needs them; the build stamp below needs the same digest and
   is computed before either file is written. */

/* ── the build stamp ─────────────────────────────────────────────────────────
   Computed over the shell and the content TOGETHER, so it moves when either
   does — that is the whole point: it answers "are these two files from the same
   deploy?", which neither digest answers alone. Taken over the UNSTAMPED bytes,
   because stamping changes them; deterministic either way, since the
   placeholder is a constant. */
/* The scanned heart ships beside the app (copied to heart-scan/ below); this
   is how the app learns it is there. Before the digest, so the build id
   covers it. */
appCode = "window.HEART_SCAN_BASE='heart-scan/';\n" + appCode;
const shellDigest = crypto.createHash('sha256')
  .update(html).update(appCode).digest('hex').slice(0, 16);
const BUILD_ID = crypto.createHash('sha256')
  .update(shellDigest).update(String(contentManifest.sourceDigest)).digest('hex').slice(0, 16);

if (html.indexOf('__BUILD_ID__') < 0) throw new Error('the loader lost its build-stamp placeholder');
html = html.replace('__BUILD_ID__', BUILD_ID);
if (html.indexOf('__BUILD_ID__') >= 0) throw new Error('more than one build-stamp placeholder in the loader');
/* The same both-directions check as the stamp above, and for the same reason:
   a placeholder that silently fails to substitute ships the literal
   __COMMIT__ to the device, and a second copy means one of them is stale. */
/* The same both-directions check again: a placeholder left in would send the
   loader to fetch a file literally named __HEART_MESH__. */
if (html.indexOf('__HEART_MESH__') < 0) throw new Error('the loader lost its heart-mesh placeholder');
html = html.replace('__HEART_MESH__', heartMesh ? heartMesh.name : '');
if (html.indexOf('__HEART_MESH__') >= 0) throw new Error('more than one heart-mesh placeholder in the loader');
if (html.indexOf('__NO_CONTENT__') < 0) throw new Error('the loader lost its no-content placeholder');
html = html.replace('__NO_CONTENT__', NO_CONTENT ? 'true' : 'false');
if (html.indexOf('__NO_CONTENT__') >= 0) throw new Error('more than one no-content placeholder in the loader');
if (html.indexOf('__COMMIT__') < 0) throw new Error('the loader lost its commit placeholder');
html = html.replace('__COMMIT__', COMMIT);
if (html.indexOf('__COMMIT__') >= 0) throw new Error('more than one commit placeholder in the loader');
/* A var at the top level of a classic script is a global, which is what the
   loader's typeof check reads. */
appCode = `var APP_BUILD_ID='${BUILD_ID}';\nvar APP_COMMIT='${COMMIT}';\n` + appCode;
/* SYMMETRIC WITH THE SHELL'S TWO PLACEHOLDER CHECKS ABOVE, and newly load-
   bearing: the loader now treats an unstamped app.js as a mismatched pair, so
   a build that failed to stamp one would ship an app that refuses to start.
   Cheap to assert, and the failure belongs here rather than on a tablet. */
if (!/^var APP_BUILD_ID='[0-9a-f]{16}';\n/.test(appCode)) {
  throw new Error('app.js did not receive its build stamp');
}

/* Bind execution to these exact code bytes, so a deploy between preflight
   and the script request cannot run a different response with this shell. */
const APP_INTEGRITY = 'sha256-' + crypto.createHash('sha256').update(appCode).digest('base64');
if (html.split('__APP_INTEGRITY__').length !== 2) throw new Error('the loader lost its unique app integrity placeholder');
html = html.replace('__APP_INTEGRITY__', APP_INTEGRITY);

fs.writeFileSync(path.join(DIST, 'index.html'), html);
fs.writeFileSync(path.join(DIST, 'app.js'), appCode);

/* content/ is the build's INPUT directory as well as the deployed one, and a
   blind recursive copy shipped 18 MB the app never asks for: the per-figure
   visual atlas the reference figures were cut from (14 MB), the markdown the
   seed was baked from, and the loose figure files that were base64'd into
   refs-images.json. Dead weight anywhere; worse on the iPad route, where this
   folder is uploaded to a host and synced to a tablet.

   So only what the shipped code actually fetches is copied. The list is short
   and checked against the built code below, because a folder silently dropped
   here is a feature that 404s at runtime rather than a build that fails. */
const SHIPPED = ['questions.json', 'manifest.json', 'figures'];
step('copy only the content the app asks for', () => {
  fs.mkdirSync(path.join(DIST, 'content'), { recursive: true });
  for (const name of SHIPPED) {
    const from = path.join(CONTENT, name);
    if (!fs.existsSync(from)) throw new Error(`content/${name} is missing`);
    fs.cpSync(from, path.join(DIST, 'content', name), { recursive: true });
  }
});

/* THE BANK IS NOT SHIPPABLE AS THE EXPORT WROTE IT. The export keys six
   questions wrong — scripts/answer-keys.js says which, why, and on what
   evidence — and a wrong key is silent: it marks a correct answer wrong and
   teaches the distractor as the fact.

   THIS STEP USED TO APPLY THEM AGAIN HERE, and the comment justifying it
   opened "content/questions.json is the licensed export". That was true once
   and is not now: extract-content.js reads build/systole.html, which the build
   has ALREADY corrected (assemble-app applies scripts/answer-keys.js), so the
   extracted bank arrives carrying them. Applying the list a second time hit
   the corrections' own `was` assertion (keys-patch's, then) and stopped the
   build:

       [CON_16] the export now keys C, not A as recorded here.

   C is what the correction changes it TO. The guard was right and the pipeline
   was wrong. It went unseen because extract and pwabuild had never run
   back-to-back — `npm run pwa` by hand read a content/ directory left over
   from before those corrections existed.

   SO THIS VERIFIES RATHER THAN MUTATES, which is idempotent by construction
   and cannot be run twice into a contradiction. It also closes what the apply
   was covering by accident: the cross-check below proves the two builds AGREE,
   and two builds that both lost the corrections agree perfectly. This asserts
   the corrections are actually present in what ships.

   The flags are applied rather than asserted because applyContentFlags is
   already idempotent — it leaves a question the export flagged itself alone
   and reports it as such — and it is the only thing that puts them in the
   split build if extraction ever drops one.

   BOTH BELONG TO ACCSAP 12 ALONE (scripts/which-bank.js). The bank's manifest says
   which bank it is; for any other, shippedFixes() changes nothing and says so. */
const { bankOf, shippedFixes } = require('./which-bank.js');
step('the ACCSAP corrections are present in what ships, if it is the ACCSAP bank', () => {
  const p = path.join(DIST, 'content', 'questions.json');
  const bank = JSON.parse(fs.readFileSync(p, 'utf8'));
  const lines = shippedFixes(bank, bankOf(contentManifest));
  fs.writeFileSync(p, JSON.stringify(bank));
  lines.forEach(a => console.log('      ✓ ' + a));
});

/* And the check that makes the class of bug impossible rather than this one
   instance of it: every answer key the split build ships must equal the key the
   single-file build carries. Any future step that corrects the bank in one
   build and not the other fails here instead of on a ward round. */
step('every answer key matches the single-file build', () => {
  const shipped = JSON.parse(fs.readFileSync(path.join(DIST, 'content', 'questions.json'), 'utf8'));
  /* Re-read SRC rather than use `html`: by this point the split has already
     lifted ALL_Q out of the working copy, which is the entire point of it. */
  const m = /\nconst ALL_Q=(\[[\s\S]*?\]);\n/.exec(fs.readFileSync(SRC, 'utf8'));
  if (!m) throw new Error('could not find "const ALL_Q=" in the single-file build');
  const embedded = new Map(JSON.parse(m[1]).map(q => [q.id, q.ci]));
  const drift = shipped.filter(q => embedded.has(q.id) && embedded.get(q.id) !== q.ci);
  if (drift.length) {
    throw new Error(`${drift.length} answer key(s) differ between the two builds: ` +
      drift.map(q => `${q.id} (split ${'ABCDEFGH'[q.ci]}, single-file ${'ABCDEFGH'[embedded.get(q.id)]})`).join(', '));
  }
  console.log(`      ✓ ${shipped.length} keys agree across both builds`);
});


fs.mkdirSync(path.join(DIST, 'vendor'), { recursive: true });
fs.writeFileSync(path.join(DIST, psw.name), psw.bytes);
fs.writeFileSync(path.join(DIST, psw.css), psw.cssBytes);
/* PhotoSwipe's MIT licence travels with the copy of it that ships. */
fs.copyFileSync(path.join(ROOT, 'docs', 'vendor', 'photoswipe', 'LICENSE'), path.join(DIST, 'vendor', 'photoswipe-LICENSE.txt'));
fs.writeFileSync(path.join(DIST, psw.pf), psw.pfBytes);
fs.writeFileSync(path.join(DIST, psw.lab), psw.labBytes);
/* perfect-freehand's too: it carries no notice in the file, so the licence is the notice. */
fs.copyFileSync(path.join(ROOT, 'docs', 'vendor', 'perfect-freehand', 'LICENSE'), path.join(DIST, 'vendor', 'perfect-freehand-LICENSE.txt'));

const echoDir = path.join(DIST, 'echo');
fs.mkdirSync(echoDir, { recursive: true });
for (const [name, bytes] of echoAssets) fs.writeFileSync(path.join(echoDir, name), bytes);

/* The scanned heart (assets/heart-scan, CC BY 4.0, credit in its manifest)
   ships as files beside the app and is fetched after the first paint, so it
   costs the shell nothing; HEART_SCAN_BASE tells the app it is here. */
/* The same five the service worker keeps (NICE_TO_HAVE, written out there because its template is read as text). */
const SCAN_FILES = ['heart-scan.json', 'heart-scan.bin', 'base.webp', 'normal.webp', 'mr.webp'];
const scanDir = path.join(DIST, 'heart-scan');
fs.mkdirSync(scanDir, { recursive: true });
for (const n of SCAN_FILES) fs.copyFileSync(path.join(ROOT, 'assets', 'heart-scan', n), path.join(scanDir, n));

const splashDir = path.join(DIST, 'content', 'splash-heart');
fs.mkdirSync(splashDir, { recursive: true });
for (const [name, body] of splashAssets) fs.writeFileSync(path.join(splashDir, name), body);

/* THE WORKER. Pages ignores a functions/ directory on dashboard direct upload —
   which is how this is deployed, as a zip dragged from an iPad — but it does
   honour a _worker.js at the root of the upload. So the Worker ships as a file
   in dist/ like everything else, and the same drag-and-drop that publishes the
   site publishes the API with it. In advanced mode it owns every request, so it
   is also what serves all of the above; see src/worker/apex.js. */
const WORKER_SRC = path.join(ROOT, 'src', 'worker', 'apex.js');
step('ship the Worker that holds the Gemini key', () => {
  if (!fs.existsSync(WORKER_SRC)) throw new Error('src/worker/apex.js is missing');
  const src = fs.readFileSync(WORKER_SRC, 'utf8');
  if (!/env\.ASSETS\.fetch/.test(src)) {
    throw new Error('the Worker has no ASSETS passthrough — that would 404 the whole site');
  }
  /* The Worker owns every request, so it — not dist/_headers, which Pages
     ignores whenever a _worker.js exists — is what actually sets the policy on
     the deployed site. Asserted rather than substituted: this file ships and is
     imported verbatim, and a placeholder left unreplaced would be a valid
     worker serving an inert policy. Drift fails the build here. */
  if (!src.includes(CSP.HEADER_POLICY)) {
    throw new Error('the Worker\'s Content-Security-Policy no longer matches scripts/csp.js\n' +
                    `  expected  ${CSP.HEADER_POLICY}`);
  }
  fs.writeFileSync(path.join(DIST, '_worker.js'), src);
});

const fontDir = path.join(DIST, 'fonts');
fs.mkdirSync(fontDir, { recursive: true });
for (const [name, body] of fontAssets) fs.writeFileSync(path.join(fontDir, name), body);

if (refSeed) fs.writeFileSync(path.join(DIST, 'content', 'refs-seed.json'), refSeed);
if (heartMesh) fs.writeFileSync(path.join(DIST, heartMesh.name), heartMesh.bin);
if (refImgParts) {
  const dir = path.join(DIST, 'content', 'refs-images');
  fs.mkdirSync(dir, { recursive: true });
  for (const [unit, imgs] of Object.entries(refImgParts)) fs.writeFileSync(path.join(dir, unit + '.json'), JSON.stringify(imgs));
}

const manifest = {
  name: 'Systole — Cardiology Board Review',
  short_name: 'Systole',
  description: 'Cardiology board review: spaced repetition, a WebGL rhythm lab, and Apex, a grounded AI tutor.',
  start_url: '.',
  scope: '.',
  display: 'standalone',
  orientation: 'any',
  background_color: '#0A1628',
  theme_color: '#0A1628',
  icons: [
    { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
    { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
    { src: 'icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
  ],
};
fs.writeFileSync(path.join(DIST, 'manifest.webmanifest'), JSON.stringify(manifest, null, 2));

/* Every content path the shipped code names must exist on disk. This is the
   safety net under the selective copy above: add a fetch without adding the
   file it wants and the build stops here, rather than the app 404ing on a
   tablet with no console to read. */
step('every content path the code names is on disk', () => {
  const code = html + appCode;
  const wanted = new Set();
  for (const m of code.matchAll(/['"`](content\/[A-Za-z0-9_.-]+)/g)) wanted.add(m[1]);
  /* The code-only deploy names the bank's path for a normal build's sake and
     never fetches it (NO_CONTENT gates the fetch); it is meant to be absent. */
  const absentByDesign = NO_CONTENT
    ? new Set(['content/questions.json', 'content/figures', 'content/refs-seed.json', 'content/refs-images']) : new Set();
  const missing = [...wanted].filter(rel => !absentByDesign.has(rel) && !fs.existsSync(path.join(DIST, rel)));
  if (missing.length) throw new Error(`the code fetches ${missing.join(', ')}, which was not copied`);
});

/* THE CONTENT CACHE IS KEYED ON THE CONTENT THAT SHIPS. It was keyed on
   content/manifest.json's sourceDigest, and that is a digest of the whole
   single-file build (extract-content.js), code and CSS as well as the bank:
   staleContent() above makes it match the build being split. So a stylesheet
   fix renamed accsap-content-*, activate() deleted the old bucket, and every
   figure the fellow had downloaded went with it.

   This hashes what build-pwa.js wrote under dist/content/ instead, every
   file's path and bytes in path order, and must run after the last write
   there. Three files are left out. manifest.json records the build (its
   digest, the commit, the time), not content, and the app never fetches it.
   The heart mesh and the splash heart are each named by a digest of their
   own bytes (splitHeartMesh, and the splash step above), so a new one is a
   new URL and needs no version. The mesh is baked from heart3d.js, which is
   code, and the splash picture comes in with the shell, so hashing either
   would let a change that is not content evict the figures again. The old
   file stays in the bucket until the content next changes. Only those two
   names are left out: anything else under content/ is served cache-first
   under a fixed name, so it is in here or a change to it would never reach
   a device.

   staleContent() still pairs content/ with its build; this only decides when
   a device's copy is out of date. tests/verify-swupdate-pure.js drives it
   over two synthetic builds that differ only in code. */
function contentVersion(dir) {
  const files = [];
  (function walk(d) {
    for (const ent of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, ent.name);
      if (ent.isDirectory()) walk(p);
      else files.push(path.relative(dir, p).split(path.sep).join('/'));
    }
  })(dir);
  const h = crypto.createHash('sha256');
  for (const rel of files.sort()) {
    if (rel === 'manifest.json' || /^heart-mesh-[0-9a-f]+\.bin$/.test(rel) || /^splash-heart\/heart-[0-9a-f]{12}\.webp$/.test(rel)) continue;
    const bytes = fs.readFileSync(path.join(dir, rel));
    h.update(rel + '\0' + bytes.length + '\0').update(bytes);
  }
  return h.digest('hex').slice(0, 16);
}

/* THE SHELL NEEDS A VERSION OF ITS OWN. Both cache names were keyed on the
   content digest, and with content/ left over from an earlier extraction (as
   it usually was before staleContent() refused one) every change to the
   app's own code produced a byte-identical sw.js. The browser saw no new
   worker, never ran install, never re-primed the shell cache, and an installed
   app went on serving the old code; the only route to an update was the
   background refresh in the fetch handler, which lands on the launch AFTER
   next. Two relaunches to see a fix is indistinguishable from a fix that did
   not ship.

   Keyed separately, not both on one version. Rekeying the FIGURE cache on a
   code change would throw away the 408 figures the fellow pressed a button to
   download — 19 MB re-fetched because a stylesheet moved. Figures change when
   the content changes; the shell changes when the shell changes. */
const SW = `/* Systole service worker.
   Shell is precached so a cold launch is instant and works offline. Figures
   are cache-first at runtime rather than precached: there are 408 of them and
   18 MB, and precaching that on install would stall the first launch for the
   sake of questions you may never open. iOS can still evict this cache under
   pressure, so every miss falls through to the network rather than assuming
   what was cached once is cached forever. */
const CONTENT_V = '${contentVersion(path.join(DIST, 'content'))}';
const SHELL_V   = '${shellDigest}';
/* The same stamp index.html and app.js carry, so the three can be compared
   from the outside — by a test, or by anyone reading a deployed directory. */
const BUILD_ID  = '${BUILD_ID}';
/* And the commit they were built from. Deliberately NOT part of any cache
   key: rekeying the shell on a commit id would evict the caches for a change
   that did not alter a byte the browser runs. */
const COMMIT    = '${COMMIT}';
const SHELL   = 'accsap-shell-'   + SHELL_V;
/* EVERYTHING UNDER /content/ LIVES HERE, not just the figures, and the name
   changed with the scope. It used to be FIGS and only /content/figures/ was
   routed into it; refs-images.json (14.4 MB) and refs-seed.json (0.7 MB) are
   fetched at runtime like any other same-origin URL and so fell through to the
   SHELL bucket. activate() deletes every cache that is not the CURRENT shell,
   and SHELL_V is a digest of the shell code — so a CSS tweak with no content
   change at all evicted 15.1 MB, and the next launch had to pull it down again
   before reference figures worked offline. Keyed by CONTENT_V, these now
   survive any number of code deploys and are evicted only when the content
   they were built from actually changes. */
const CONTENT = 'accsap-content-' + CONTENT_V;
/* Split deliberately. cache.addAll() is all-or-nothing: one 404 rejects the
   whole call, the install event fails, the worker never activates, and the app
   silently loses offline support entirely. That is exactly what happened when
   the icons were generated by a separate script that had not been run — a
   missing decoration disabled the headline feature.

   So: the files the app genuinely cannot start without are precached
   atomically and any failure is a real failure. Everything else is cached
   best-effort, one request at a time, and a miss is shrugged off. */
const PRECACHE  = ['.', 'index.html', 'app.js', 'manifest.webmanifest', ${JSON.stringify(psw.name)}, ${JSON.stringify(psw.css)}, ${JSON.stringify(psw.pf)}, ${JSON.stringify(psw.lab)}, ${JSON.stringify(echoAssets.map(([n]) => 'echo/' + n)).slice(1, -1)}${NO_CONTENT ? '' : ", 'content/questions.json'"}];
/* Which bucket a precached URL belongs in. questions.json is precached because
   the app cannot start without it, and content-versioned because that is what
   it is — so install writes it to CONTENT while the shell files go to SHELL.
   Without this it would land in SHELL, be evicted by the next code deploy, and
   be re-fetched into CONTENT on first use: self-healing, but a 1.7 MB download
   nobody asked for. */
const isContent = u => u.indexOf('content/') === 0 || u.indexOf('/content/') > -1;
const NICE_TO_HAVE = ['icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png',
                      ${JSON.stringify(fontAssets.map(([n]) => 'fonts/' + n)).slice(1, -1)},
                      'heart-scan/heart-scan.json', 'heart-scan/heart-scan.bin', 'heart-scan/base.webp', 'heart-scan/normal.webp', 'heart-scan/mr.webp'];

/* INSTALL CHECKS WHAT IT IS STORING, because addAll does not. The note further
   down about authenticating proxies — Access answering 200 OK with a sign-in
   page for any URL — was acted on in the fetch handler and nowhere else, and
   install was the path that actually mattered. cache.addAll() keeps whatever
   comes back: one lapsed session during install and the sign-in page IS app.js
   in the precache, permanently, and the device launches offline into a blank
   screen. That is not hypothetical; it is what this worker was doing.

   So every critical URL is fetched and passed through the same keepable() the
   fetch handler uses. If any one of them fails the check the install REJECTS —
   no partial shell, nothing poisoned — and the browser tries again on the next
   launch, by which time the session is usually back. */
self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(SHELL);
    const cc = await caches.open(CONTENT);
    const fresh = await Promise.all(PRECACHE.map(async u => {
      const req = new Request(u, { cache: 'reload' });
      let res; try { res = await fetch(req); } catch (_) { return [u, null]; }
      return [u, keepable(req, res) ? res : null];
    }));
    const bad = fresh.filter(([, res]) => !res).map(([u]) => u);
    if (bad.length) throw new Error('precache refused: ' + bad.join(', '));
    await Promise.all(fresh.map(([u, res]) => (isContent(u) ? cc : c).put(new Request(u), res)));
    await Promise.all(NICE_TO_HAVE.map(u => c.add(u).catch(() => {})));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(ks => Promise.all(ks.filter(k => k !== SHELL && k !== CONTENT).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  /* The API is never cached and never intercepted. Non-GET already falls
     through above, but the model list is a GET, and a cached model list would
     outlive the key that produced it. */
  if (url.pathname.startsWith('/api/apex/')) return;

  /* SIGNING IN AGAIN GOES TO THE NETWORK. Every launch is answered from the
     cache, so once the Access session lapses (24 hours) Access never sees a
     navigation it could answer with its sign-in page: the shell opens, and
     every figure the cache does not already hold comes back as that page and
     shows as nothing. The app asks with ?signin when it needs Access to see a
     request (signinLapsed() and its "Sign in again" bar in app/systole.html),
     and such a request is never answered here. */
  if (url.searchParams.has('signin')) return;

  /* Was /content/figures/ only. Widened to all of /content/ so the two large
     JSON files stop being shell. keepable() already tells the two kinds apart:
     a figure must come back as an image, and anything else must not come back
     as text/html — which is what an expired Cloudflare Access session looks
     like when it answers 200 OK with a sign-in page. */
  if (url.pathname.includes('/content/')) {
    e.respondWith(caches.open(CONTENT).then(async c => {
      const hit = await c.match(req);
      if (hit) return hit;
      const res = await fetch(req);
      /* A figure is an image or it is not kept. See keepable() below.
         waitUntil, not a bare call: respondWith's promise resolves the
         instant this function returns res, and once it does the browser is
         free to terminate the worker — iOS Safari especially aggressively —
         with nothing else telling it work is still in flight. c.put() is a
         promise that keeps running after res is returned; without waitUntil
         wrapping it, the fellow sees the figure once, the worker is killed
         before the write lands, and it is never actually offline. */
      if (keepable(req, res)) e.waitUntil(c.put(req, res.clone()));
      return res;
    }));
    return;
  }
  // shell: cache first, but refresh in the background so an update lands
  e.respondWith(caches.open(SHELL).then(async c => {
    /* ignoreSearch, because the cached key is a bare path and the URL that
       comes back from an Access redirect is not — it carries the parameters
       Access appended. Without this a launch after re-authenticating misses
       every shell entry it actually has. */
    const hit = await c.match(req, { ignoreSearch: true });
    /* Same waitUntil reasoning as the figure handler above: this write must
       outlive respondWith's own promise, which resolves as soon as the
       response (fresh or cached) is handed back — often before c.put() has
       actually finished. */
    const net = fetch(req).then(res => { if (keepable(req, res)) e.waitUntil(c.put(req, res.clone())); return res; }).catch(() => hit);
    /* A NAVIGATION MUST NEVER RESOLVE TO undefined. Returning hit || net looks
       safe and is not: offline, net's catch resolves to the same missing hit,
       so respondWith gets undefined and Safari shows its cannot-connect page —
       the app "not opening" rather than opening from cache. Any navigation
       that misses falls back to the cached shell, which is what a single-page
       app wants for every route anyway. */
    if (hit) {
      /* net is handed to the event here, while respondWith's promise is still
         pending, and not only by the waitUntil inside it. That one runs when
         the network answers, and by then a cache hit has long been returned,
         the promise has settled, and nothing is keeping the event alive:
         waitUntil throws InvalidStateError ("already finished and no extend
         lifetime promises are outstanding" in Chromium, "no longer being
         dispatched" in WebKit), the catch above swallows it, and the write is
         left to run with nothing holding the worker up — which is the very
         thing the waitUntil was there to prevent. With net registered, the
         event is alive when the answer comes and that call is legal. */
      e.waitUntil(net);
      return hit;
    }
    const res = await net;
    if (res) return res;
    if (req.mode === 'navigate') {
      const shell = await c.match('index.html', { ignoreSearch: true }) || await c.match('.', { ignoreSearch: true });
      if (shell) return shell;
    }
    return Response.error();
  }));
});

/* AN AUTHENTICATING PROXY DOES NOT ANSWER WITH AN ERROR. Cloudflare Access with
   a lapsed session, a corporate SSO gateway, a hotel captive portal: every one
   of them replies 200 OK with an HTML sign-in page, for whatever URL you asked
   for. res.ok was therefore never enough to decide something was worth keeping.

   The app's own figure downloader already knew this — it content-type checks
   before it stores anything. The service worker did not, and the service worker
   is the worse place to get it wrong: it caches app.js. One lapsed session while
   the shell was being refreshed and the sign-in page becomes app.js in the
   precache, permanently, on a device that then launches offline into a blank
   screen with no way to ask for help.

   So an HTML answer is only kept for something that asked for HTML, and a
   figure is only kept if it is actually an image. The response is still
   RETURNED either way — that is the network's business, and the app has its own
   error handling — it is just never written down. */
function keepable(req, res) {
  if (!res || !res.ok || res.type === 'opaque') return false;
  // A followed Access redirect is HTML even when the requested shell is HTML.
  // Keep Pages' same-origin canonical redirects, but never cache another origin.
  if (res.url && new URL(res.url).origin !== new URL(req.url).origin) return false;
  const ct = (res.headers.get('content-type') || '').toLowerCase();
  const p = new URL(req.url).pathname;
  if (p.includes('/content/figures/')) return ct.indexOf('image/') === 0;
  if (ct.indexOf('text/html') !== 0) return true;
  return p.endsWith('/') || p.endsWith('.html');
}
`;
fs.writeFileSync(path.join(DIST, 'sw.js'), SW);

/* ── NO FILE THE HOST WILL REFUSE ─────────────────────────────────────────────
   Cloudflare Pages will not take a single asset over "25 MiB" — and the
   number it enforces is 25,000,000 bytes, not 25 x 1024 x 1024. The first
   version of this guard took the label at its word (26,214,400) and passed a
   refs-images.json of 23.9 MiB, which the dashboard upload then refused as
   "larger than the file size limit of 25 MiB": 23.9 MiB is 25.06 million
   bytes. So the ceiling is the smaller reading, which satisfies both. Nothing here
   knew that, and docs/IPAD.md's "5.4 MB for the largest against 25 MB" had
   gone stale by a factor of four: an arrhythmias unit took refs-images.json
   to 25.7 MiB, the build printed its usual green, and the deployed app opened
   on "Could not load the question bank — the application code failed to
   load." The splash is right that app.js did not arrive and silent on why,
   and nothing on the laptop had said a word.

   So the finished tree is measured, every file in it, after the last write —
   and a file over the ceiling fails the build here, naming itself, instead of
   failing the deploy somewhere nobody is looking. Kept as a plain function of
   (path, bytes) pairs so tests/verify-loader-pure.js can drive it without a
   build. The warning line is not a second limit: it only says how close the
   largest file is, because a unit's figure file grows with its figures and the
   next overrun should be seen coming. (refs-images.json, the file that tripped
   this, is now split one file per unit — see splitRefImages.) */
const PAGES_FILE_LIMIT = 25 * 1000 * 1000;   // bytes; see above — NOT 25 MiB
function pagesLimitReport(files, limit) {
  const over = files.filter(f => f.bytes > limit)
    .map(f => f.rel + ' is ' + f.bytes.toLocaleString('en-US') + ' bytes (' + (f.bytes / 1048576).toFixed(1) + ' MiB)');
  let largest = null;
  for (const f of files) if (!largest || f.bytes > largest.bytes) largest = f;
  return { over, largest };
}
/* THE CODE-ONLY DEPLOY'S OTHER HALF. Every check above ran on the real bank
   and the real notes, here; now they are packed into the one file the iPad
   imports — the bank as it SHIPS (dist's copy, with its flags applied, not
   content/'s) plus the reference seed and every unit's figure file — and
   taken out of what is uploaded. The package is written under source/,
   gitignored and refused by the leak guard. */
if (NO_CONTENT) step('pack the bank and the notes for the device, and take them out of the upload', () => {
  const dc = path.join(DIST, 'content');
  const extras = {};
  if (fs.existsSync(path.join(dc, 'refs-seed.json'))) extras['refs-seed.json'] = fs.readFileSync(path.join(dc, 'refs-seed.json'));
  const ri = path.join(dc, 'refs-images');
  if (fs.existsSync(ri)) for (const f of fs.readdirSync(ri).filter(f => f.endsWith('.json')).sort()) extras['refs-images/' + f] = fs.readFileSync(path.join(ri, f));
  const argAt = process.argv.indexOf('--package');
  const out = path.resolve(argAt > -1 && process.argv[argAt + 1] ? process.argv[argAt + 1] : path.join(ROOT, 'source', 'systole-content-v1.zip'));
  const r = require('../tools/pack-content.js').pack(dc, out, extras);
  for (const name of SHIPPED.concat(['refs-seed.json', 'refs-images'])) fs.rmSync(path.join(dc, name), { recursive: true, force: true });
  console.log(`      ✓ packed ${r.questions} questions, ${r.figures} figures and ${r.extras} note file(s) → ${path.relative(ROOT, out)}`);
  console.log('      ✓ dist/content carries none of them — import the package on the device');
});

const distFiles = [];
(function walk(dir) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p);
    else distFiles.push({ rel: path.relative(DIST, p).split(path.sep).join('/'), bytes: fs.statSync(p).size });
  }
})(DIST);
const hostCheck = pagesLimitReport(distFiles, PAGES_FILE_LIMIT);
if (hostCheck.over.length) {
  console.error('\n  build-pwa: Cloudflare Pages refuses any file over 25,000,000 bytes, and this dist/ has '
    + hostCheck.over.join('; ') + '.\n  Nothing in dist/ is safe to deploy. For a content/refs-images/<unit>.json, re-run '
    + 'tools/add-unit.py with a lower --quality or --max-width, or crop the figures.');
  process.exit(1);
}

const mb = b => (b / 1048576).toFixed(2) + ' MB';
const kb = b => (b / 1024).toFixed(0) + ' KB';
const shellBytes = fs.statSync(path.join(DIST, 'index.html')).size
                 + fs.statSync(path.join(DIST, 'app.js')).size;
/* The shell budget is denominated in transferred bytes, so the build prints
   the transferred figure rather than leaving it to be discovered by the check
   that enforces it. Gzip at a pinned level: deterministic, and an upper bound
   on what a device gets — Cloudflare serves brotli to anything that accepts
   it, which is smaller again. See the budget note in tests/verify-pwa.js. */
const gzipOf = f => require('zlib')
  .gzipSync(fs.readFileSync(path.join(DIST, f)), { level: 6 }).length;
const shellWire = gzipOf('index.html') + gzipOf('app.js');
console.log('Stage 1 PWA build\n');
steps.forEach(s => console.log('  ✓ ' + s));
console.log('');
console.log(`  index.html           ${kb(fs.statSync(path.join(DIST, 'index.html')).size)}`);
console.log(`  app.js               ${kb(fs.statSync(path.join(DIST, 'app.js')).size)}`);
console.log(`  shell total          ${kb(shellBytes)}   (was ${mb(fs.statSync(SRC).size)} in one file)`);
console.log(`  shell transferred    ${kb(shellWire)} gzipped   (the budget: 288 KB)`);
console.log(`  content/             ${mb(contentManifest.figureBytes)} of figures + questions.json`);
console.log(`  content/splash-heart ${splashAssets.map(([n,b])=>`${n} ${(b.length/1024).toFixed(0)}KB`).join(', ')}`);
console.log(`  largest file         ${hostCheck.largest.rel} ${(hostCheck.largest.bytes / 1e6).toFixed(2)} MB   (the host's ceiling: 25.00 MB, decimal)`);
console.log(`  build                ${BUILD_ID}   from commit ${COMMIT}`);
console.log(`\n  written to           ${DIST}`);
/* Icons are drawn by a headless browser, which lives in the global node_modules
   here. Resolving that ourselves means `node scripts/build-pwa.js` produces a
   complete, installable PWA rather than one that needs a second command nobody
   remembers — and whose absence used to break offline entirely. */
try {
  const globalRoot = require('child_process').execSync('npm root -g', { encoding: 'utf8' }).trim();
  const r = require('child_process').spawnSync(process.execPath, [path.join(__dirname, 'make-icons.js')], {
    encoding: 'utf8',
    env: { ...process.env, NODE_PATH: [process.env.NODE_PATH, globalRoot].filter(Boolean).join(path.delimiter) },
  });
  const made = fs.existsSync(path.join(DIST, 'icons', 'icon-192.png'));
  console.log(made ? '\n  icons                generated'
                   : '\n  icons                NOT generated — run: node scripts/make-icons.js\n' +
                     '                       (the app still works offline; the install icon will be missing)');
  if (!made && r.stderr) console.log('    ' + r.stderr.split('\n')[0]);
} catch (err) {
  console.log('\n  icons                skipped (' + err.message.split('\n')[0] + ')');
}
